const add = css => { const s = document.createElement('style'); s.textContent = css; (document.head || document.documentElement).appendChild(s); };
add('ytd-reel-shelf-renderer, ytd-rich-shelf-renderer[is-shorts], ytd-mini-guide-entry-renderer[aria-label="Shorts"], ytm-shorts-lockup-view-model, ytm-shorts-lockup-view-model-v2, grid-shelf-view-model { display: none !important; }');
add('ytd-guide-entry-renderer:has(a[title="Shorts"]), ytd-video-renderer:has(a[href^="/shorts/"]), ytd-rich-item-renderer:has(a[href^="/shorts/"]), ytd-rich-section-renderer:has(ytd-rich-shelf-renderer[is-shorts]) { display: none !important; }');
const redirect = () => {
	if (location.pathname.startsWith('/shorts/')) {
		const id = location.pathname.split('/')[2];
		if (id) location.replace('/watch?v=' + id);
	}
};
redirect();
window.addEventListener('yt-navigate-finish', redirect);
