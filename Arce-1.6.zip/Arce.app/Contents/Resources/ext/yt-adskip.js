const add = css => { const s = document.createElement('style'); s.textContent = css; (document.head || document.documentElement).appendChild(s); };
add('ytd-ad-slot-renderer, ytd-in-feed-ad-layout-renderer, ytd-promoted-sparkles-web-renderer, ytd-display-ad-renderer, ytd-companion-slot-renderer, ytd-action-companion-ad-renderer, ytd-banner-promo-renderer, ytd-statement-banner-renderer, ytd-promoted-video-renderer, ytd-player-legacy-desktop-watch-ads-renderer, ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-ads"], #player-ads, #masthead-ad, ytd-merch-shelf-renderer, .ytp-ad-overlay-container, .ytp-ad-message-container, .ytp-featured-product { display: none !important; }');
add('ytd-rich-item-renderer:has(ytd-ad-slot-renderer), ytd-rich-section-renderer:has(ytd-statement-banner-renderer) { display: none !important; }');

add('ytd-enforcement-message-view-model, tp-yt-paper-dialog:has(ytd-enforcement-message-view-model) { display: none !important; }');

// If YouTube shows its "ad blockers aren't allowed" box, close it and keep the video going.
const unblock = () => {
	const box = document.querySelector('ytd-enforcement-message-view-model');
	if (!box) return;
	const dialog = box.closest('tp-yt-paper-dialog');
	if (dialog) dialog.remove();
	document.querySelectorAll('tp-yt-iron-overlay-backdrop').forEach(b => b.remove());
	const v = document.querySelector('#movie_player video');
	if (v && v.paused) v.play().catch(() => {});
};

let saved = null;
setInterval(() => {
	const player = document.querySelector('#movie_player, .html5-video-player');
	const video = player && player.querySelector('video');
	if (!video) return;
	const ad = player.classList.contains('ad-showing') || player.classList.contains('ad-interrupting');
	if (ad) {
		const skip = player.querySelector('.ytp-skip-ad-button, .ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-ad-skip-button-slot button, .videoAdUiSkipButton');
		if (skip) skip.click();
		if (!saved) saved = { muted: video.muted, rate: video.playbackRate === 16 ? 1 : video.playbackRate };
		// Fast-forward and mute instead of seeking, so the real video (sometimes stitched into the same stream) is never skipped.
		video.muted = true;
		video.playbackRate = 16;
	} else if (saved) {
		video.muted = saved.muted;
		video.playbackRate = saved.rate;
		saved = null;
	}
	unblock();
}, 200);
