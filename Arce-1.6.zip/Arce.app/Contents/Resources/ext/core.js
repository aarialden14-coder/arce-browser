(() => {
	if (window.__arceCore) return;
	window.__arceCore = true;
	const post = m => { try { webkit.messageHandlers.arcePage.postMessage(m); } catch (e) {} };

	// Tell Arce when this page plays sound (tab speaker icon + auto-pausing the music player).
	let last = null;
	const check = () => {
		const playing = [...document.querySelectorAll('video, audio')].some(m => !m.paused && !m.ended && !m.muted && m.volume > 0 && m.readyState > 2 && (!isFinite(m.duration) || m.duration > 4));
		if (playing !== last) { last = playing; post({ type: 'media', playing }); }
	};
	['play', 'playing', 'pause', 'ended', 'volumechange', 'emptied'].forEach(ev => document.addEventListener(ev, e => {
		if (ev === 'play' && window.__arceMuted && e.target && 'muted' in e.target) e.target.muted = true;
		setTimeout(check, 60);
	}, true));
	window.addEventListener('pagehide', () => { if (last) post({ type: 'media', playing: false }); });

	if (window.top !== window) return;
	const icon = () => {
		const links = [...document.querySelectorAll('link[rel~="icon"], link[rel="shortcut icon"], link[rel="apple-touch-icon"]')];
		const score = l => { const s = parseInt((l.getAttribute('sizes') || '').split('x')[0]) || 16; return Math.abs(s - 32) + (l.rel.includes('apple') ? 10 : 0); };
		links.sort((a, b) => score(a) - score(b));
		const href = links.length ? links[0].href : (location.protocol.startsWith('http') ? location.origin + '/favicon.ico' : '');
		if (href) post({ type: 'icon', href });
	};
	if (document.readyState === 'complete') icon(); else window.addEventListener('load', icon);
	setTimeout(icon, 2500);
})();
