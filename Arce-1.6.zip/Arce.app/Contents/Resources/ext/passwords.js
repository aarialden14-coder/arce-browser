(() => {
	if (window.__arcePw || !/^https?:$/.test(location.protocol)) return;
	window.__arcePw = true;
	const ask = m => { try { return webkit.messageHandlers.arcePass.postMessage(m); } catch (e) { return Promise.resolve(null); } };
	const post = m => { try { webkit.messageHandlers.arcePage.postMessage(m); } catch (e) {} };
	const visible = el => el && el.offsetParent !== null && !el.disabled;
	const isUserField = i => i.tagName === 'INPUT' && /^(text|email|tel|)$/i.test(i.type) && visible(i);

	const userFieldFor = pw => {
		const scope = pw.form || pw.closest('form') || document;
		const inputs = [...scope.querySelectorAll('input')].filter(isUserField);
		const before = inputs.filter(i => i.compareDocumentPosition(pw) & Node.DOCUMENT_POSITION_FOLLOWING);
		return before.pop() || inputs[0] || null;
	};
	const passwordFor = field => {
		const scope = field.form || field.closest('form') || document;
		return [...scope.querySelectorAll('input[type="password"]')].find(visible) || null;
	};

	// Offer to save the login when a form with a password is sent.
	let lastSent = 0;
	const capture = () => {
		const pw = [...document.querySelectorAll('input[type="password"]')].find(p => p.value && p.value.length > 1);
		if (!pw || Date.now() - lastSent < 2000) return;
		lastSent = Date.now();
		const uf = userFieldFor(pw);
		post({ type: 'pwSave', user: uf && uf.value ? uf.value : '', pass: pw.value });
	};
	document.addEventListener('submit', capture, true);
	document.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target && e.target.type === 'password') capture(); }, true);
	document.addEventListener('click', e => {
		const b = e.target.closest && e.target.closest('button, input[type="submit"], [role="button"]');
		if (b && document.querySelector('input[type="password"]')) setTimeout(capture, 0);
	}, true);
	// Remember the username typed on step one of two-step logins (like Google).
	document.addEventListener('change', e => {
		const t = e.target;
		if (t && isUserField(t) && t.value && /user|mail|login|identifier|account|name/i.test((t.name || '') + (t.id || '') + (t.autocomplete || '') + (t.type || ''))) post({ type: 'pwUser', user: t.value });
	}, true);

	// Autofill chip under login fields.
	let accounts = null, host = null, shadow = null, current = null;
	const setValue = (el, v) => {
		const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
		setter.call(el, v);
		el.dispatchEvent(new Event('input', { bubbles: true }));
		el.dispatchEvent(new Event('change', { bubbles: true }));
	};
	const hide = () => { if (host) host.style.display = 'none'; current = null; };
	const show = async field => {
		if (accounts === null) accounts = (await ask({ cmd: 'list' })) || [];
		if (!accounts.length) return;
		if (!host) {
			host = document.createElement('div');
			host.style.cssText = 'position:fixed;z-index:2147483647;display:none';
			shadow = host.attachShadow({ mode: 'closed' });
			document.documentElement.appendChild(host);
		}
		current = field;
		const r = field.getBoundingClientRect();
		host.style.left = Math.max(4, r.left) + 'px';
		host.style.top = (r.bottom + 6) + 'px';
		host.style.display = 'block';
		shadow.innerHTML = `<style>.b{background:#18181d;border:1px solid rgba(255,255,255,.1);border-radius:10px;padding:4px;box-shadow:0 10px 30px rgba(0,0,0,.4);font:13px -apple-system,system-ui;color:#ececf1;min-width:220px}.h{font-size:11px;color:#8f8f9b;padding:4px 8px 2px}.a{display:flex;align-items:center;gap:8px;padding:7px 8px;border-radius:7px;cursor:pointer}.a:hover{background:rgba(255,59,78,.18)}.k{width:22px;height:22px;border-radius:6px;background:rgba(255,255,255,.08);display:flex;align-items:center;justify-content:center;font-size:12px}</style><div class="b"><div class="h">Saved in Arce</div>${accounts.map((a, i) => `<div class="a" data-i="${i}"><span class="k">🔑</span><span></span></div>`).join('')}</div>`;
		shadow.querySelectorAll('.a').forEach((row, i) => {
			row.lastChild.textContent = accounts[i].user || '(no username)';
			row.addEventListener('mousedown', async e => {
				e.preventDefault();
				const f = current;
				const user = accounts[i].user;
				const res = await ask({ cmd: 'get', user });
				if (!res || !f) return;
				const pw = f.type === 'password' ? f : passwordFor(f);
				const uf = f.type === 'password' ? userFieldFor(f) : f;
				if (uf && user) setValue(uf, user);
				if (pw && res.pass) setValue(pw, res.pass);
				hide();
			});
		});
	};
	document.addEventListener('focusin', e => {
		const t = e.target;
		if (!t || t.tagName !== 'INPUT') return;
		if (t.type === 'password' || (isUserField(t) && (passwordFor(t) || /user|mail|login|identifier/i.test((t.name || '') + (t.id || '') + (t.autocomplete || ''))))) show(t);
	}, true);
	document.addEventListener('focusout', () => setTimeout(() => { if (!document.activeElement || document.activeElement.tagName !== 'INPUT') hide(); }, 150), true);
	window.addEventListener('scroll', hide, { passive: true });
})();
