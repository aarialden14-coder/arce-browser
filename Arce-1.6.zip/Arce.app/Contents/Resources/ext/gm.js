function __arceGlob(p) {
	const esc = s => s.replace(/[.+?^${}()|[\]\\]/g, '\\$&');
	if (p === '<all_urls>' || p === '*') return /^(https?|file):\/\//;
	const m = p.match(/^(\*|https?|file):\/\/([^/]*)(\/.*)?$/);
	if (m) {
		const scheme = m[1] === '*' ? 'https?' : m[1];
		const host = m[2];
		const path = m[3] || '/*';
		const hostRe = host === '*' ? '[^/]*' : host.startsWith('*.') ? '([^/]+\\.)?' + esc(host.slice(2)) : esc(host).replace(/\*/g, '[^/]*');
		return new RegExp('^' + scheme + '://' + hostRe + '(:\\d+)?' + esc(path).replace(/\*/g, '.*') + '$');
	}
	return new RegExp('^' + esc(p).replace(/\*/g, '.*') + '$');
}
function __arceMatches(info) {
	const href = location.href;
	const test = p => {
		if (p.length > 2 && p.startsWith('/') && p.endsWith('/')) { try { return new RegExp(p.slice(1, -1)).test(href); } catch (e) { return false; } }
		try { return __arceGlob(p).test(href); } catch (e) { return false; }
	};
	if ((info.exclude || []).some(test)) return false;
	return (info.match || []).some(test);
}
const GM_info = { script: { name: __ARCE_INFO.name, version: __ARCE_INFO.version }, scriptHandler: 'Arce', version: '1.0' };
const __gmKey = k => '__arce_gm_' + __ARCE_INFO.id + '_' + k;
const GM_getValue = (k, d) => { try { const v = localStorage.getItem(__gmKey(k)); return v === null ? d : JSON.parse(v); } catch (e) { return d; } };
const GM_setValue = (k, v) => { try { localStorage.setItem(__gmKey(k), JSON.stringify(v)); } catch (e) {} };
const GM_deleteValue = k => { try { localStorage.removeItem(__gmKey(k)); } catch (e) {} };
const GM_listValues = () => { try { return Object.keys(localStorage).filter(x => x.startsWith(__gmKey(''))).map(x => x.slice(__gmKey('').length)); } catch (e) { return []; } };
const GM_addStyle = css => { const s = document.createElement('style'); s.textContent = css; (document.head || document.documentElement).appendChild(s); return s; };
const GM_addElement = (parent, tag, attrs) => { if (typeof parent === 'string') { attrs = tag; tag = parent; parent = document.head || document.documentElement; } const el = document.createElement(tag); Object.assign(el, attrs || {}); parent.appendChild(el); return el; };
const GM_openInTab = url => window.open(url, '_blank');
const GM_setClipboard = t => { try { navigator.clipboard.writeText(String(t)); } catch (e) {} };
const GM_notification = o => console.log('[Arce userscript]', typeof o === 'string' ? o : o && o.text);
const GM_registerMenuCommand = () => 0;
const GM_unregisterMenuCommand = () => {};
const GM_getResourceText = () => '';
const GM_getResourceURL = () => '';
const GM_xmlhttpRequest = o => {
	const ctrl = new AbortController();
	fetch(o.url, { method: o.method || 'GET', headers: o.headers, body: o.data, signal: ctrl.signal, credentials: o.anonymous ? 'omit' : 'include' }).then(async r => {
		const text = await r.text();
		let response = text;
		if (o.responseType === 'json') { try { response = JSON.parse(text); } catch (e) { response = null; } }
		const resp = { status: r.status, statusText: r.statusText, responseText: text, response, finalUrl: r.url, readyState: 4, responseHeaders: [...r.headers].map(([k, v]) => k + ': ' + v).join('\r\n') };
		o.onload && o.onload(resp);
		o.onloadend && o.onloadend(resp);
	}).catch(e => { o.onerror && o.onerror({ error: String(e) }); o.onloadend && o.onloadend({ error: String(e) }); });
	return { abort: () => ctrl.abort() };
};
const GM = {
	info: GM_info, getValue: async (k, d) => GM_getValue(k, d), setValue: async (k, v) => GM_setValue(k, v), deleteValue: async k => GM_deleteValue(k),
	listValues: async () => GM_listValues(), addStyle: GM_addStyle, addElement: GM_addElement, openInTab: GM_openInTab, setClipboard: GM_setClipboard,
	notification: GM_notification, xmlHttpRequest: GM_xmlhttpRequest, registerMenuCommand: GM_registerMenuCommand,
};
const unsafeWindow = window;
