setInterval(() => {
	const bonus = document.querySelector('.community-points-summary .claimable-bonus__icon, button[aria-label="Claim Bonus"]');
	if (bonus) (bonus.closest('button') || bonus).click();
}, 4000);
