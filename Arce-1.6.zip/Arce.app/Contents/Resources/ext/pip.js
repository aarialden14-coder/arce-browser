if (!document.pictureInPictureEnabled && !HTMLVideoElement.prototype.webkitSetPresentationMode) return;
const toggle = v => {
	if (!v) return;
	if (document.pictureInPictureElement) { document.exitPictureInPicture().catch(() => {}); return; }
	if (v.requestPictureInPicture) v.requestPictureInPicture().catch(() => v.webkitSetPresentationMode && v.webkitSetPresentationMode('picture-in-picture'));
	else v.webkitSetPresentationMode('picture-in-picture');
};
const btn = document.createElement('button');
btn.title = 'Picture in Picture (Option-P)';
btn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2.5" y="4.5" width="19" height="15" rx="2"/><rect x="12" y="11" width="7" height="6" rx="1" fill="currentColor"/></svg>';
btn.style.cssText = 'position:fixed;z-index:2147483646;display:none;align-items:center;justify-content:center;width:32px;height:28px;border:0;border-radius:7px;background:rgba(10,10,12,.78);color:#fff;cursor:pointer;opacity:.9;padding:0';
let current = null, hideTimer = null;
btn.addEventListener('click', e => { e.preventDefault(); e.stopPropagation(); toggle(current); });
btn.addEventListener('mousedown', e => e.stopPropagation(), true);
document.documentElement.appendChild(btn);
let lastMove = 0;
document.addEventListener('mousemove', e => {
	const now = Date.now();
	if (now - lastMove < 120) return;
	lastMove = now;
	if (e.target === btn || btn.contains(e.target)) return;
	const v = document.elementsFromPoint(e.clientX, e.clientY).find(el => el.tagName === 'VIDEO');
	if (!v || v.offsetWidth < 240) { if (!hideTimer) hideTimer = setTimeout(() => { btn.style.display = 'none'; hideTimer = null; }, 1200); return; }
	clearTimeout(hideTimer);
	hideTimer = null;
	current = v;
	const r = v.getBoundingClientRect();
	btn.style.left = (r.right - 44) + 'px';
	btn.style.top = (r.top + 10) + 'px';
	btn.style.display = 'flex';
}, { passive: true });
document.addEventListener('keydown', e => {
	if (e.altKey && e.code === 'KeyP') {
		const v = [...document.querySelectorAll('video')].sort((a, b) => b.offsetWidth * b.offsetHeight - a.offsetWidth * a.offsetHeight)[0];
		if (v) { toggle(v); e.preventDefault(); }
	}
}, true);
