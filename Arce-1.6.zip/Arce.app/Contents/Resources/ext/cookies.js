if (/(^|\.)(youtube\.com|google\.[a-z.]+|youtube-nocookie\.com)$/.test(location.hostname)) return;
const SELECTORS = ['#onetrust-banner-sdk', '#onetrust-consent-sdk', '.onetrust-pc-dark-filter', '#CybotCookiebotDialog', '#CybotCookiebotDialogBodyUnderlay', '.fc-consent-root', '.qc-cmp2-container', '#qc-cmp2-container', '#didomi-host', '#usercentrics-root', '#truste-consent-track', '#consent_blackbar', '.cc-window', '.cc-banner', '#cookie-law-info-bar', '#cookie-notice', '.cookie-notice-container', '#cmpbox', '#cmpbox2', '.cmpboxBG', '[id^="sp_message_container"]', '#gdpr-consent-tool-wrapper', '.evidon-banner', '#iubenda-cs-banner', '.osano-cm-window', '.cky-consent-container', '.cky-overlay', '#BorlabsCookieBox', '.moove-gdpr-info-bar-container', '#hs-eu-cookie-confirmation', '.cookie-consent-banner', '#cookieConsent', '#cookie-consent', '#cookiebanner', '#cookieBanner', '.cookie-banner', '.cookies-banner', '#gdpr-banner', '#klaro', '.klaro', '#ccc', '.truste_overlay', '.truste_box_overlay', '#cookiescript_injected', '.cookie-popup', '#cookie-popup', '.js-consent-banner', '#consent-banner', '.consent-banner'];
const style = document.createElement('style');
style.textContent = SELECTORS.join(',') + '{display:none!important;visibility:hidden!important}';
(document.head || document.documentElement).appendChild(style);
const unlock = () => {
	if (!document.querySelector(SELECTORS.join(','))) return;
	for (const el of [document.documentElement, document.body]) {
		if (!el) continue;
		const cs = getComputedStyle(el);
		if (cs.overflow === 'hidden' || cs.overflowY === 'hidden') { el.style.setProperty('overflow', 'auto', 'important'); el.style.setProperty('overflow-y', 'auto', 'important'); }
		if (cs.position === 'fixed' && el === document.body) el.style.setProperty('position', 'static', 'important');
	}
	document.documentElement.classList.remove('sp-message-open', 'didomi-popup-open');
	document.body && document.body.classList.remove('didomi-popup-open', 'modal-open', 'no-scroll');
};
[800, 2000, 4000, 8000].forEach(t => setTimeout(unlock, t));
