['copy', 'cut', 'paste', 'contextmenu', 'selectstart', 'dragstart'].forEach(ev => {
	window.addEventListener(ev, e => e.stopImmediatePropagation(), true);
	document.addEventListener(ev, e => e.stopImmediatePropagation(), true);
});
const s = document.createElement('style');
s.textContent = '*{-webkit-user-select:text!important;user-select:text!important}';
(document.head || document.documentElement).appendChild(s);
