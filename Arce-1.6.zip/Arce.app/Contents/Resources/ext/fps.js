if (window.top !== window) return;
const el = document.createElement('div');
el.style.cssText = 'position:fixed;top:8px;right:8px;z-index:2147483647;font:700 12px ui-monospace,Menlo,monospace;color:#7CFC9A;background:rgba(0,0,0,.62);padding:3px 8px;border-radius:6px;pointer-events:none;letter-spacing:.3px';
el.textContent = '-- FPS';
document.documentElement.appendChild(el);
let frames = 0, last = performance.now();
const loop = now => {
	frames++;
	if (now - last >= 500) {
		const fps = Math.round(frames * 1000 / (now - last));
		el.textContent = fps + ' FPS';
		el.style.color = fps >= 55 ? '#7CFC9A' : fps >= 30 ? '#ffd166' : '#ff5c6c';
		frames = 0;
		last = now;
	}
	requestAnimationFrame(loop);
};
requestAnimationFrame(loop);
