if (window.top !== window) return;
const b = document.createElement('button');
b.title = 'Back to top';
b.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M6 15l6-6 6 6"/></svg>';
b.style.cssText = 'position:fixed;right:18px;bottom:18px;z-index:2147483646;width:38px;height:38px;border-radius:10px;border:0;background:rgba(10,10,12,.8);color:#fff;cursor:pointer;display:none;align-items:center;justify-content:center;padding:0;box-shadow:0 4px 18px rgba(0,0,0,.35)';
b.onclick = () => window.scrollTo({ top: 0, behavior: 'smooth' });
document.documentElement.appendChild(b);
let t = 0;
window.addEventListener('scroll', () => {
	if (t) return;
	t = requestAnimationFrame(() => { b.style.display = window.scrollY > 1400 ? 'flex' : 'none'; t = 0; });
}, { passive: true });
