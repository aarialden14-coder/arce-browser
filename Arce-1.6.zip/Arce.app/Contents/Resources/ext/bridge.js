(() => {
	// Lets Arce's own pages (arce://…) talk to the app without exposing anything to websites.
	if (location.protocol !== 'arce:' || window.__arceBridge) return;
	window.__arceBridge = true;
	window.addEventListener('message', async e => {
		const d = e.data;
		if (!d || !d.__arceCall) return;
		let result = null, error = null;
		try { result = await webkit.messageHandlers.arceInternal.postMessage({ cmd: d.cmd, args: d.args || {} }); } catch (err) { error = String(err); }
		window.postMessage({ __arceReply: d.id, result, error }, '*');
	});
})();
