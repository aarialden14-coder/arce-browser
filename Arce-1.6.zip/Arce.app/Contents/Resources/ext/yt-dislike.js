const cache = {};
const fmt = n => n >= 1e6 ? (n / 1e6).toFixed(1).replace(/\.0$/, '') + 'M' : n >= 1e3 ? (n / 1e3).toFixed(1).replace(/\.0$/, '') + 'K' : String(n);

function place(text) {
	const btn = document.querySelector('ytd-watch-metadata dislike-button-view-model button, ytd-watch-metadata #segmented-dislike-button button, #top-level-buttons-computed dislike-button-view-model button');
	if (!btn) return;
	let span = btn.querySelector('.arce-dislikes');
	if (!span) {
		span = document.createElement('span');
		span.className = 'arce-dislikes';
		span.style.cssText = 'margin-left:6px;font-weight:500;font-size:14px;line-height:1';
		btn.appendChild(span);
		btn.style.width = 'auto';
		btn.style.paddingRight = '14px';
	}
	if (span.textContent !== text) span.textContent = text;
}

setInterval(async () => {
	if (location.pathname !== '/watch') return;
	const id = new URL(location.href).searchParams.get('v');
	if (!id) return;
	if (cache[id] === undefined) {
		cache[id] = null;
		try {
			const r = await fetch('https://returnyoutubedislikeapi.com/votes?videoId=' + encodeURIComponent(id));
			if (r.ok) cache[id] = fmt((await r.json()).dislikes || 0);
		} catch (e) {}
	}
	if (cache[id]) place(cache[id]);
}, 1200);
