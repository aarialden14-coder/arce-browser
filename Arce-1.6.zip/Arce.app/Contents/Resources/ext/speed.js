let badge = null;
const show = (v, text) => {
	if (!badge) {
		badge = document.createElement('div');
		badge.style.cssText = 'position:fixed;z-index:2147483647;background:rgba(10,10,12,.85);color:#fff;font:700 14px -apple-system,sans-serif;padding:6px 10px;border-radius:8px;pointer-events:none;transition:opacity .25s';
		document.documentElement.appendChild(badge);
	}
	const r = v.getBoundingClientRect();
	badge.style.left = Math.max(8, r.left + 12) + 'px';
	badge.style.top = Math.max(8, r.top + 12) + 'px';
	badge.textContent = text;
	badge.style.opacity = '1';
	clearTimeout(badge._t);
	badge._t = setTimeout(() => badge.style.opacity = '0', 900);
};
const target = () => {
	const vids = [...document.querySelectorAll('video')].filter(v => v.readyState > 0 && v.offsetWidth > 120);
	return vids.find(v => !v.paused) || vids.sort((a, b) => b.offsetWidth * b.offsetHeight - a.offsetWidth * a.offsetHeight)[0];
};
document.addEventListener('keydown', e => {
	if (e.metaKey || e.ctrlKey || e.altKey) return;
	const t = e.target;
	if (t && (t.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName))) return;
	const k = e.key.toLowerCase();
	if (!['s', 'd', 'r'].includes(k)) return;
	const v = target();
	if (!v || v.paused) return;
	let rate = v.playbackRate;
	if (k === 's') rate = Math.max(0.25, Math.round((rate - 0.25) * 100) / 100);
	if (k === 'd') rate = Math.min(16, Math.round((rate + 0.25) * 100) / 100);
	if (k === 'r') rate = 1;
	v.playbackRate = rate;
	show(v, rate.toFixed(2).replace(/0$/, '') + 'x');
	e.preventDefault();
	e.stopPropagation();
}, true);
