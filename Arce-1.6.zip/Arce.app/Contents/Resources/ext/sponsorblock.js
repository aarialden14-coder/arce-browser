const CATEGORIES = ['sponsor', 'selfpromo', 'interaction'];
const LABELS = { sponsor: 'sponsor', selfpromo: 'self-promotion', interaction: 'subscribe reminder' };
let segments = [], current = null;
const done = new Set();

const videoId = () => {
	const u = new URL(location.href);
	if (u.pathname.startsWith('/shorts/')) return u.pathname.split('/')[2] || null;
	return u.pathname === '/watch' ? u.searchParams.get('v') : null;
};

async function load(id) {
	segments = [];
	done.clear();
	try {
		const r = await fetch('https://sponsor.ajay.app/api/skipSegments?videoID=' + encodeURIComponent(id) + '&categories=' + encodeURIComponent(JSON.stringify(CATEGORIES)));
		if (!r.ok) return;
		const data = await r.json();
		if (videoId() === id) segments = data.map(s => ({ start: s.segment[0], end: s.segment[1], cat: s.category, id: s.UUID }));
	} catch (e) {}
}

function toast(text) {
	const player = document.querySelector('#movie_player');
	if (!player) return;
	let el = player.querySelector('.arce-sb');
	if (!el) {
		el = document.createElement('div');
		el.className = 'arce-sb';
		el.style.cssText = 'position:absolute;left:14px;bottom:64px;z-index:60;background:rgba(10,10,12,.85);color:#fff;font:600 13px -apple-system,Roboto,sans-serif;padding:7px 12px;border-radius:8px;pointer-events:none;transition:opacity .3s';
		player.appendChild(el);
	}
	el.textContent = text;
	el.style.opacity = '1';
	clearTimeout(el._t);
	el._t = setTimeout(() => el.style.opacity = '0', 2200);
}

setInterval(() => {
	const id = videoId();
	if (id !== current) { current = id; if (id) load(id); else segments = []; }
	if (!segments.length) return;
	const player = document.querySelector('#movie_player');
	if (player && player.classList.contains('ad-showing')) return;
	const v = player && player.querySelector('video');
	if (!v || v.paused) return;
	const t = v.currentTime;
	for (const s of segments) {
		if (t >= s.start && t < s.end - 0.4 && !done.has(s.id)) {
			done.add(s.id);
			v.currentTime = s.end;
			toast('Skipped ' + (LABELS[s.cat] || s.cat));
			break;
		}
	}
}, 300);
