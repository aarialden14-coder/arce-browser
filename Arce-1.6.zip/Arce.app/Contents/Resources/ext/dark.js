if (location.protocol === 'arce:' || window.top !== window) return;
if (/(^|\.)(youtube\.com|twitch\.tv|discord\.com|github\.com|reddit\.com|x\.com|netflix\.com|spotify\.com)$/.test(location.hostname)) return;
const style = document.createElement('style');
style.textContent = 'html.arce-dark{filter:invert(.92) hue-rotate(180deg)!important;background:#fff!important}html.arce-dark img,html.arce-dark video,html.arce-dark picture,html.arce-dark canvas,html.arce-dark iframe,html.arce-dark embed,html.arce-dark object,html.arce-dark svg image,html.arce-dark [style*="background-image"]{filter:invert(1) hue-rotate(180deg)!important}';
const parse = c => { const m = c && c.match(/rgba?\(([^)]+)\)/); if (!m) return null; const p = m[1].split(',').map(x => parseFloat(x)); return { r: p[0], g: p[1], b: p[2], a: p.length > 3 ? p[3] : 1 }; };
const lum = c => (0.2126 * c.r + 0.7152 * c.g + 0.0722 * c.b) / 255;
const isLight = () => {
	const meta = document.querySelector('meta[name="color-scheme"]');
	for (const el of [document.body, document.documentElement]) {
		if (!el) continue;
		const c = parse(getComputedStyle(el).backgroundColor);
		if (c && c.a > 0.5) return lum(c) > 0.62;
	}
	if (meta && /dark/.test(meta.content) && matchMedia('(prefers-color-scheme: dark)').matches) return false;
	const t = parse(getComputedStyle(document.body || document.documentElement).color);
	return !(t && lum(t) > 0.6);
};
let decided = false;
const decide = () => {
	if (decided || !document.body) return;
	decided = true;
	if (isLight()) {
		(document.head || document.documentElement).appendChild(style);
		document.documentElement.classList.add('arce-dark');
	}
};
if (document.readyState !== 'loading') decide(); else document.addEventListener('DOMContentLoaded', () => setTimeout(decide, 30));
window.addEventListener('load', decide);
