setInterval(() => {
	const p = document.getElementById('movie_player');
	if (!p || !p.getAvailableQualityLevels) return;
	const key = location.href;
	if (p.__arceHD === key) return;
	const levels = (p.getAvailableQualityLevels() || []).filter(l => l !== 'auto');
	if (!levels.length) return;
	const best = levels[0];
	try {
		if (p.setPlaybackQualityRange) p.setPlaybackQualityRange(best, best);
		if (p.setPlaybackQuality) p.setPlaybackQuality(best);
	} catch (e) {}
	p.__arceHD = key;
}, 1500);
