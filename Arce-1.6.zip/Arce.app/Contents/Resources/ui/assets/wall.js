// Arce wallpapers: animated built-ins plus your own pictures and live (video) wallpapers.
window.ArceWall = (() => {
	const BUILTIN = {
		midnight: { name: 'Midnight', thumb: 'radial-gradient(circle at 25% 25%,rgba(90,70,180,.55),transparent 55%),radial-gradient(circle at 80% 70%,rgba(40,90,160,.45),transparent 55%),#0b0b10' },
		starfield: { name: 'Warp Speed', thumb: 'radial-gradient(1px 1px at 20% 30%,#fff,transparent),radial-gradient(1px 1px at 70% 60%,#fff,transparent),radial-gradient(1.5px 1.5px at 40% 75%,#fff,transparent),radial-gradient(1px 1px at 85% 20%,#fff,transparent),radial-gradient(circle at 50% 50%,#2a3b7a 0%,#05060f 60%)' },
		matrix: { name: 'Code Rain', thumb: 'repeating-linear-gradient(90deg,rgba(0,255,120,.0) 0 6px,rgba(0,255,120,.45) 6px 8px,transparent 8px 15px),linear-gradient(180deg,#03140a,#000)' },
		particles: { name: 'Network', thumb: 'radial-gradient(2px 2px at 25% 35%,#fff,transparent),radial-gradient(2px 2px at 60% 55%,#fff,transparent),radial-gradient(2px 2px at 80% 25%,#fff,transparent),radial-gradient(2px 2px at 40% 80%,#fff,transparent),radial-gradient(circle at 30% 30%,#3b1d5c,#0a0a10 70%)' },
		ember: { name: 'Ember', thumb: 'radial-gradient(circle at 20% 20%,#ff3b4e,transparent 55%),radial-gradient(circle at 85% 40%,#ff8a3d,transparent 50%),radial-gradient(circle at 50% 100%,#5b1a6e,#0b0b0e 70%)' },
		aurora: { name: 'Aurora', thumb: 'radial-gradient(circle at 20% 20%,#2bd4e0,transparent 55%),radial-gradient(circle at 85% 40%,#3ecf8e,transparent 50%),radial-gradient(circle at 50% 100%,#3b2d8f,#0b0b0e 70%)' },
		nebula: { name: 'Nebula', thumb: 'radial-gradient(circle at 20% 20%,#9b7bff,transparent 55%),radial-gradient(circle at 85% 40%,#ff5fa2,transparent 50%),radial-gradient(circle at 50% 100%,#1d2a6e,#0b0b0e 70%)' },
		none: { name: 'Plain', thumb: '#121216' },
	};
	const BLOBS = { midnight: ['#3a2a8a', '#1d4f8f', '#5a1f5f'], ember: ['#ff3b4e', '#ff8a3d', '#5b1a6e'], aurora: ['#2bd4e0', '#3ecf8e', '#3b2d8f'], nebula: ['#9b7bff', '#ff5fa2', '#1d2a6e'] };

	let styleAdded = false;
	function addStyle() {
		if (styleAdded) return;
		styleAdded = true;
		const s = document.createElement('style');
		s.textContent = `
.aw{position:absolute;inset:0;overflow:hidden;background-color:var(--bg,#09090c);pointer-events:none}
.aw .media{position:absolute;inset:0}
.aw .media.blurred{inset:-40px}
.aw video,.aw .img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;background-size:cover;background-position:center}
.aw canvas{position:absolute;inset:0;width:100%;height:100%}
.aw .dim{position:absolute;inset:0}
.aw .blob{position:absolute;border-radius:50%;filter:blur(90px);opacity:.6;animation:awfloat 20s ease-in-out infinite alternate}
@keyframes awfloat{0%{transform:translate(0,0) scale(1)}50%{transform:translate(70px,-50px) scale(1.12)}100%{transform:translate(-40px,30px) scale(.95)}}
.aw .sky{position:absolute;inset:0;background:linear-gradient(180deg,#0a0115 0%,#2a0838 38%,#7a1460 52%,#ff2e88 58%,#120320 58.2%,#07010d 100%)}
.aw .sun{position:absolute;left:50%;top:22%;width:min(42vw,420px);aspect-ratio:1;transform:translateX(-50%);border-radius:50%;background:linear-gradient(180deg,#ffe066 0%,#ff8a3d 40%,#ff2e88 75%);-webkit-mask:linear-gradient(180deg,#000 52%,transparent 52%,transparent 56%,#000 56%,#000 63%,transparent 63%,transparent 67%,#000 67%,#000 72%,transparent 72%,transparent 77%,#000 77%,#000 81%,transparent 81%,transparent 86%,#000 86%);box-shadow:0 0 120px rgba(255,46,136,.55);animation:awsun 6s ease-in-out infinite alternate}
@keyframes awsun{to{filter:brightness(1.15) saturate(1.2)}}
.aw .floor{position:absolute;left:-50%;right:-50%;top:58%;bottom:-40%;transform:perspective(320px) rotateX(62deg);transform-origin:top;background-image:linear-gradient(rgba(255,46,136,.85) 2px,transparent 2px),linear-gradient(90deg,rgba(43,212,224,.75) 2px,transparent 2px);background-size:70px 70px;animation:awgrid 1.6s linear infinite;-webkit-mask:linear-gradient(180deg,transparent,#000 30%)}
@keyframes awgrid{to{background-position:0 70px}}
.aw .stars{position:absolute;inset:0 0 45% 0;background-image:radial-gradient(1px 1px at 10% 20%,#fff,transparent),radial-gradient(1px 1px at 30% 70%,#fff,transparent),radial-gradient(1.5px 1.5px at 55% 30%,#fff,transparent),radial-gradient(1px 1px at 75% 15%,#fff,transparent),radial-gradient(1px 1px at 90% 60%,#fff,transparent),radial-gradient(1.5px 1.5px at 20% 50%,#fff,transparent),radial-gradient(1px 1px at 65% 80%,#fff,transparent);opacity:.7;animation:awtwinkle 4s ease-in-out infinite alternate}
@keyframes awtwinkle{to{opacity:.35}}
.aw.paused *{animation-play-state:paused!important}`;
		document.head.appendChild(s);
	}

	function canvasLoop(canvas, setup, draw, state) {
		const ctx = canvas.getContext('2d');
		let w = 0, h = 0, data = null, raf = 0, last = 0;
		const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
		const resize = () => {
			const r = canvas.getBoundingClientRect();
			w = Math.max(1, r.width); h = Math.max(1, r.height);
			canvas.width = w * dpr; canvas.height = h * dpr;
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
			data = setup(w, h, ctx);
		};
		const ro = new ResizeObserver(resize);
		ro.observe(canvas);
		resize();
		const frame = t => {
			raf = requestAnimationFrame(frame);
			if (state.paused || document.hidden || t - last < 1000 / 40) return;
			const dt = Math.min(0.1, (t - last) / 1000);
			last = t;
			draw(ctx, w, h, data, dt, state);
		};
		raf = requestAnimationFrame(frame);
		return () => { cancelAnimationFrame(raf); ro.disconnect(); };
	}

	const CANVAS = {
		starfield: (accent) => ({
			setup: (w, h) => Array.from({ length: 420 }, () => ({ x: (Math.random() - 0.5) * w, y: (Math.random() - 0.5) * h, z: Math.random() * w })),
			draw: (ctx, w, h, stars, dt) => {
				ctx.fillStyle = 'rgba(5,6,15,.45)';
				ctx.fillRect(0, 0, w, h);
				for (const s of stars) {
					const pz = s.z;
					s.z -= w * 0.35 * dt;
					if (s.z < 1) { s.x = (Math.random() - 0.5) * w; s.y = (Math.random() - 0.5) * h; s.z = w; continue; }
					const k = 128 / s.z, pk = 128 / pz;
					const x = w / 2 + s.x * k, y = h / 2 + s.y * k;
					const px = w / 2 + s.x * pk, py = h / 2 + s.y * pk;
					const a = Math.min(1, 1.4 - s.z / w);
					ctx.strokeStyle = Math.random() < 0.02 ? accent : `rgba(220,230,255,${a})`;
					ctx.lineWidth = Math.max(0.6, 2.2 * (1 - s.z / w));
					ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(x, y); ctx.stroke();
				}
			},
		}),
		matrix: (accent) => ({
			setup: (w, h, ctx) => { ctx.fillStyle = '#000'; ctx.fillRect(0, 0, w, h); const cols = Math.ceil(w / 16); return { cols: Array.from({ length: cols }, () => Math.random() * -h / 16), acc: 0 }; },
			draw: (ctx, w, h, d, dt) => {
				d.acc += dt;
				if (d.acc < 0.05) return;
				d.acc = 0;
				ctx.fillStyle = 'rgba(0,0,0,.09)';
				ctx.fillRect(0, 0, w, h);
				ctx.font = '15px ui-monospace, Menlo, monospace';
				const chars = 'アイウエオカキクケコサシスセソ0123456789ABCDEF<>/{}*+=';
				d.cols.forEach((y, i) => {
					const c = chars[(Math.random() * chars.length) | 0];
					ctx.fillStyle = Math.random() < 0.08 ? '#fff' : accent;
					ctx.fillText(c, i * 16, y * 16);
					d.cols[i] = y * 16 > h && Math.random() > 0.975 ? 0 : y + 1;
				});
			},
		}),
		particles: (accent) => ({
			setup: (w, h) => {
				const mouse = { x: -999, y: -999 };
				window.addEventListener('mousemove', e => { mouse.x = e.clientX; mouse.y = e.clientY; }, { passive: true });
				return { mouse, pts: Array.from({ length: Math.min(110, Math.round(w * h / 9000)) }, () => ({ x: Math.random() * w, y: Math.random() * h, vx: (Math.random() - 0.5) * 30, vy: (Math.random() - 0.5) * 30 })) };
			},
			draw: (ctx, w, h, d, dt) => {
				const g = ctx.createRadialGradient(w * 0.3, h * 0.3, 0, w * 0.3, h * 0.3, Math.max(w, h));
				g.addColorStop(0, '#22123a'); g.addColorStop(1, '#09090c');
				ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
				const pts = d.pts;
				for (const p of pts) {
					p.x += p.vx * dt; p.y += p.vy * dt;
					if (p.x < 0 || p.x > w) p.vx *= -1;
					if (p.y < 0 || p.y > h) p.vy *= -1;
					const dx = p.x - d.mouse.x, dy = p.y - d.mouse.y, dist = Math.hypot(dx, dy);
					if (dist < 120 && dist > 0) { p.x += dx / dist * 60 * dt; p.y += dy / dist * 60 * dt; }
				}
				ctx.lineWidth = 1;
				for (let i = 0; i < pts.length; i++) for (let j = i + 1; j < pts.length; j++) {
					const a = pts[i], b = pts[j], dd = Math.hypot(a.x - b.x, a.y - b.y);
					if (dd < 130) { ctx.strokeStyle = accent + Math.round((1 - dd / 130) * 120).toString(16).padStart(2, '0'); ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); }
				}
				ctx.fillStyle = '#fff';
				for (const p of pts) { ctx.beginPath(); ctx.arc(p.x, p.y, 1.6, 0, 6.3); ctx.fill(); }
			},
		}),
	};

	// info: { key, kind: 'builtin'|'video'|'image', url, dim, blur }
	function mount(el, info, opts = {}) {
		addStyle();
		el.innerHTML = '';
		const root = document.createElement('div');
		root.className = 'aw';
		const media = document.createElement('div');
		media.className = 'media' + (info.blur > 0 ? ' blurred' : '');
		if (info.blur > 0) media.style.filter = `blur(${info.blur}px)`;
		root.appendChild(media);
		const dim = document.createElement('div');
		dim.className = 'dim';
		dim.style.background = `rgba(0,0,0,${Math.max(0, Math.min(0.9, info.dim ?? 0.35)) + (opts.extraDim || 0)})`;
		if (opts.scrim) dim.style.background = opts.scrim(info.dim ?? 0.35);
		root.appendChild(dim);
		el.appendChild(root);

		const state = { paused: !!opts.paused };
		let stop = () => {};
		const accent = opts.accent || '#ff3b4e';
		let video = null;

		if (info.poster) {
			// Show a still frame instantly so there's never a black flash while the video wakes up.
			root.style.backgroundImage = `url("${info.poster}")`;
			root.style.backgroundSize = 'cover';
			root.style.backgroundPosition = 'center';
		}
		if (info.kind === 'video' && info.url) {
			video = document.createElement('video');
			if (info.poster) video.poster = info.poster;
			Object.assign(video, { src: info.url, muted: true, loop: true, autoplay: true, playsInline: true, defaultMuted: true });
			video.setAttribute('muted', '');
			video.setAttribute('playsinline', '');
			media.appendChild(video);
			if (!state.paused) video.play().catch(() => {});
		} else if (info.kind === 'image' && info.url) {
			const img = document.createElement('div');
			img.className = 'img';
			img.style.backgroundImage = `url("${info.url}")`;
			media.appendChild(img);
		} else {
			const key = BUILTIN[info.key] ? info.key : 'midnight';
			if (BLOBS[key]) {
				BLOBS[key].forEach((c, i) => {
					const b = document.createElement('div');
					b.className = 'blob';
					const size = [560, 480, 640][i];
					if (key === 'midnight') b.style.opacity = '.42';
					b.style.cssText += `;background:${c};width:${size}px;height:${size}px;${['left:-140px;top:-160px', 'right:-120px;top:18%', 'left:28%;bottom:-280px'][i]};animation-delay:${-i * 7}s`;
					media.appendChild(b);
				});
			} else if (CANVAS[key]) {
				const c = document.createElement('canvas');
				media.appendChild(c);
				const def = CANVAS[key](accent);
				stop = canvasLoop(c, def.setup, def.draw, state);
			} else {
				media.style.background = 'radial-gradient(circle at 30% 20%,#1c1c24,#0b0b0e 70%)';
			}
		}
		root.classList.toggle('paused', state.paused);
		return {
			pause(p) {
				state.paused = !!p;
				root.classList.toggle('paused', state.paused);
				if (video) { if (p) video.pause(); else video.play().catch(() => {}); }
			},
			destroy() { stop(); if (video) { video.pause(); video.removeAttribute('src'); video.load(); } el.innerHTML = ''; },
		};
	}

	return { BUILTIN, mount };
})();
