// Arce sound effects: soft, short "glass and wood" taps synthesized live (no sound files).
window.ArceSFX = (() => {
	let ctx = null, master = null, on = true, hover = false, volume = 0.35, lastHover = 0, last = {};

	const ac = () => {
		if (!ctx) {
			ctx = new (window.AudioContext || window.webkitAudioContext)();
			master = ctx.createGain();
			master.gain.value = volume;
			// Gentle low-pass so nothing ever sounds harsh or buzzy.
			const soften = ctx.createBiquadFilter();
			soften.type = 'lowpass';
			soften.frequency.value = 5200;
			master.connect(soften);
			soften.connect(ctx.destination);
		}
		if (ctx.state === 'suspended') ctx.resume();
		return ctx;
	};

	// A soft mallet note: a sine with a quiet overtone and a quick, smooth decay.
	function note(freq, { delay = 0, decay = 0.18, gain = 0.12, bright = 0.25 } = {}) {
		const c = ac(), t = c.currentTime + delay + 0.005;
		const g = c.createGain();
		g.gain.setValueAtTime(0, t);
		g.gain.linearRampToValueAtTime(gain, t + 0.006);
		g.gain.exponentialRampToValueAtTime(0.0001, t + decay);
		g.connect(master);
		const o = c.createOscillator();
		o.type = 'sine';
		o.frequency.value = freq;
		o.connect(g);
		o.start(t);
		o.stop(t + decay + 0.05);
		if (bright > 0) {
			const g2 = c.createGain();
			g2.gain.setValueAtTime(0, t);
			g2.gain.linearRampToValueAtTime(gain * bright, t + 0.003);
			g2.gain.exponentialRampToValueAtTime(0.0001, t + decay * 0.35);
			g2.connect(master);
			const o2 = c.createOscillator();
			o2.type = 'sine';
			o2.frequency.value = freq * 3.01;
			o2.connect(g2);
			o2.start(t);
			o2.stop(t + decay);
		}
	}

	const sounds = {
		hover: () => note(2400, { decay: 0.03, gain: 0.012, bright: 0 }),
		click: () => note(1320, { decay: 0.05, gain: 0.05, bright: 0.15 }),
		select: () => note(1046, { decay: 0.07, gain: 0.06, bright: 0.2 }),
		open: () => { note(784, { decay: 0.12, gain: 0.07 }); note(1175, { decay: 0.16, gain: 0.06, delay: 0.05 }); },
		close: () => { note(1046, { decay: 0.08, gain: 0.05 }); note(784, { decay: 0.12, gain: 0.045, delay: 0.045 }); },
		on: () => { note(1046, { decay: 0.08, gain: 0.06 }); note(1568, { decay: 0.12, gain: 0.05, delay: 0.05 }); },
		off: () => { note(1175, { decay: 0.08, gain: 0.05 }); note(880, { decay: 0.12, gain: 0.045, delay: 0.05 }); },
		play: () => [659, 988, 1319].forEach((f, i) => note(f, { decay: 0.25, gain: 0.045, delay: i * 0.04 })),
		pause: () => [1319, 988].forEach((f, i) => note(f, { decay: 0.16, gain: 0.04, delay: i * 0.04 })),
		game: () => [523, 659, 784, 1046].forEach((f, i) => note(f, { decay: 0.3, gain: 0.05, delay: i * 0.06, bright: 0.35 })),
		gameOff: () => [1046, 784, 523].forEach((f, i) => note(f, { decay: 0.2, gain: 0.04, delay: i * 0.05 })),
		whoosh: () => note(880, { decay: 0.09, gain: 0.035, bright: 0 }),
		download: () => note(988, { decay: 0.14, gain: 0.05 }),
		done: () => [1046, 1319, 1568, 2093].forEach((f, i) => note(f, { decay: 0.45, gain: 0.04, delay: i * 0.07, bright: 0.3 })),
		error: () => { note(330, { decay: 0.14, gain: 0.07, bright: 0 }); note(262, { decay: 0.2, gain: 0.07, delay: 0.09, bright: 0 }); },
	};

	return {
		play(name) {
			if (!on || !sounds[name]) return;
			const now = performance.now();
			if (name === 'hover') {
				if (!hover || now - lastHover < 60) return;
				lastHover = now;
			} else if (last[name] && now - last[name] < 40) return;
			last[name] = now;
			try { sounds[name](); } catch (e) {}
		},
		set(o) {
			if ('on' in o) on = !!o.on;
			if ('hover' in o) hover = !!o.hover;
			if ('volume' in o && o.volume != null) { volume = Math.max(0, Math.min(1, +o.volume)); if (master) master.gain.value = volume; }
		},
	};
})();
