// Arce color themes, shared by the browser UI and Arce's own pages.
window.ArceThemes = (() => {
	const T = {
		midnight: { name: 'Midnight', accent: 'crimson', bg: '#0b0b0e', page: '#121216', card: '#18181d', card2: '#1f1f25', text: '#ececf1', muted: '#8d8d99', faint: '#5d5d68', tint: '255,255,255' },
		oled: { name: 'OLED Black', accent: 'white', bg: '#000000', page: '#060607', card: '#0e0e10', card2: '#151518', text: '#f2f2f5', muted: '#8a8a94', faint: '#55555e', tint: '255,255,255' },
		graphite: { name: 'Graphite', accent: 'blue', bg: '#1b1c1f', page: '#222327', card: '#2a2b30', card2: '#323339', text: '#e8eaed', muted: '#9aa0a6', faint: '#6b7077', tint: '255,255,255' },
		nord: { name: 'Nord', accent: 'cyan', bg: '#242933', page: '#2e3440', card: '#353c4a', card2: '#3e4656', text: '#eceff4', muted: '#a3adbf', faint: '#6f7a8f', tint: '216,222,233' },
		dracula: { name: 'Dracula', accent: 'purple', bg: '#1e1f29', page: '#282a36', card: '#30323f', card2: '#393b4b', text: '#f8f8f2', muted: '#a9abc0', faint: '#6d6f87', tint: '248,248,242' },
		ocean: { name: 'Ocean', accent: 'cyan', bg: '#07121f', page: '#0c1b2c', card: '#11243a', card2: '#173049', text: '#e6f1ff', muted: '#8aa4c3', faint: '#56708f', tint: '200,225,255' },
		forest: { name: 'Forest', accent: 'green', bg: '#0b130e', page: '#111c15', card: '#16251b', card2: '#1d3023', text: '#e8f3ea', muted: '#90a897', faint: '#5d7363', tint: '220,245,225' },
		sunset: { name: 'Sunset', accent: 'orange', bg: '#1a0d12', page: '#23121a', card: '#2d1621', card2: '#3a1c2a', text: '#fde8ee', muted: '#c39aa9', faint: '#8a6573', tint: '255,225,235' },
		neon: { name: 'Neon', accent: 'pink', bg: '#08070f', page: '#100e1c', card: '#16132a', card2: '#1e1a38', text: '#f1ecff', muted: '#9b93c4', faint: '#635b8c', tint: '230,220,255' },
	};
	function apply(name) {
		const t = T[name] || T.midnight, r = document.documentElement.style;
		r.setProperty('--bg', t.bg);
		r.setProperty('--page', t.page);
		r.setProperty('--card', t.card);
		r.setProperty('--card2', t.card2);
		r.setProperty('--text', t.text);
		r.setProperty('--muted', t.muted);
		r.setProperty('--faint', t.faint);
		r.setProperty('--panel', `rgba(${t.tint},.05)`);
		r.setProperty('--hover', `rgba(${t.tint},.075)`);
		r.setProperty('--active', `rgba(${t.tint},.115)`);
		r.setProperty('--line', `rgba(${t.tint},.075)`);
		return t;
	}
	return { T, apply };
})();
