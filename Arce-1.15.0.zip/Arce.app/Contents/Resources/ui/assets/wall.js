// Arce wallpapers: animated built-ins plus your own pictures and live (video) wallpapers.
window.ArceWall = (() => {
	const BUILTIN = {
		midnight: { name: 'Midnight', thumb: 'radial-gradient(circle at 25% 25%,rgba(90,70,180,.55),transparent 55%),radial-gradient(circle at 80% 70%,rgba(40,90,160,.45),transparent 55%),#0b0b10' },
		starfield: { name: 'Warp Speed', thumb: 'radial-gradient(1px 1px at 20% 30%,#fff,transparent),radial-gradient(1px 1px at 70% 60%,#fff,transparent),radial-gradient(1.5px 1.5px at 40% 75%,#fff,transparent),radial-gradient(1px 1px at 85% 20%,#fff,transparent),radial-gradient(circle at 50% 50%,#2a3b7a 0%,#05060f 60%)' },
		matrix: { name: 'Code Rain', thumb: 'repeating-linear-gradient(90deg,rgba(0,255,120,.0) 0 6px,rgba(0,255,120,.45) 6px 8px,transparent 8px 15px),linear-gradient(180deg,#03140a,#000)' },
		particles: { name: 'Network', thumb: 'radial-gradient(2px 2px at 25% 35%,#fff,transparent),radial-gradient(2px 2px at 60% 55%,#fff,transparent),radial-gradient(2px 2px at 80% 25%,#fff,transparent),radial-gradient(2px 2px at 40% 80%,#fff,transparent),radial-gradient(circle at 30% 30%,#3b1d5c,#0a0a10 70%)' },
		ember: { name: 'Ember', thumb: 'radial-gradient(circle at 20% 20%,#ff3b4e,transparent 55%),radial-gradient(circle at 85% 40%,#ff8a3d,transparent 50%),radial-gradient(circle at 50% 100%,#5b1a6e,#0b0b0e 70%)' },
		aurora: { name: 'Aurora', thumb: 'radial-gradient(circle at 20% 20%,#2bd4e0,transparent 55%),radial-gradient(circle at 85% 40%,#3ecf8e,transparent 50%),radial-gradient(circle at 50% 100%,#3b2d8f,#0b0b0e 70%)' },
		nebula: { name: 'Nebula', thumb: 'radial-gradient(circle at 20% 20%,#9b7bff,transparent 55%),radial-gradient(circle at 85% 40%,#ff5fa2,transparent 50%),radial-gradient(circle at 50% 100%,#1d2a6e,#0b0b0e 70%)' },
		rain: { name: 'Rainy Window', thumb: 'radial-gradient(18px 18px at 25% 70%,rgba(242,180,92,.45),transparent),radial-gradient(22px 22px at 70% 60%,rgba(143,179,217,.4),transparent),radial-gradient(14px 14px at 55% 82%,rgba(217,122,92,.4),transparent),repeating-linear-gradient(100deg,transparent 0 9px,rgba(220,230,245,.12) 9px 10px),linear-gradient(180deg,#0c1016,#151a22)' },
		contours: { name: 'Contours', thumb: 'repeating-radial-gradient(circle at 35% 45%,transparent 0 7px,rgba(225,228,232,.22) 7px 8px),repeating-radial-gradient(circle at 75% 70%,transparent 0 9px,rgba(225,228,232,.16) 9px 10px),#0f1113' },
		snow: { name: 'Snowfall', thumb: 'radial-gradient(2px 2px at 20% 25%,#fff,transparent),radial-gradient(1.5px 1.5px at 60% 40%,#fff,transparent),radial-gradient(2.5px 2.5px at 80% 15%,#fff,transparent),radial-gradient(1.5px 1.5px at 35% 60%,#fff,transparent),linear-gradient(180deg,#0a1222 0%,#16233a 70%,#0c1424 82%,#0c1424)' },
		fireflies: { name: 'Fireflies', thumb: 'radial-gradient(5px 5px at 30% 45%,rgba(236,246,150,.9),transparent),radial-gradient(4px 4px at 65% 60%,rgba(236,246,150,.8),transparent),radial-gradient(6px 6px at 80% 35%,rgba(236,246,150,.7),transparent),linear-gradient(180deg,#060b0a,#0d1a14)' },
		ridges: { name: 'Ridgelines', thumb: 'repeating-linear-gradient(180deg,transparent 0 7px,rgba(232,232,236,.5) 7px 8px),linear-gradient(90deg,#0d0d0f 18%,transparent 18% 82%,#0d0d0f 82%),#0d0d0f' },
		pixelcity: { name: 'Pixel City', thumb: 'linear-gradient(180deg,transparent 55%,#140e24 55%),repeating-linear-gradient(90deg,#1d1433 0 18px,transparent 18px 22px,#1d1433 22px 30px,transparent 30px 34px) 0 40%/100% 60% no-repeat,linear-gradient(180deg,#120c26,#4a2752)' },
		film: { name: 'Film Grain', thumb: 'radial-gradient(circle at 30% 35%,rgba(255,59,78,.35),transparent 60%),radial-gradient(circle at 75% 70%,rgba(58,74,92,.6),transparent 60%),#121214' },
		none: { name: 'Plain', thumb: '#121216' },
	};
	const BLOBS = { midnight: ['#3a2a8a', '#1d4f8f', '#5a1f5f'], ember: ['#ff3b4e', '#ff8a3d', '#5b1a6e'], aurora: ['#2bd4e0', '#3ecf8e', '#3b2d8f'], nebula: ['#9b7bff', '#ff5fa2', '#1d2a6e'] };

	let styleAdded = false;
	function addStyle() {
		if (styleAdded) return;
		styleAdded = true;
		const s = document.createElement('style');
		s.textContent = `
.aw{position:absolute;inset:0;overflow:hidden;background-color:var(--bg,#09090c);pointer-events:none}
.aw .media{position:absolute;inset:0}
.aw .media.blurred{inset:-40px}
.aw video,.aw .img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;background-size:cover;background-position:center}
.aw canvas{position:absolute;inset:0;width:100%;height:100%}
.aw .dim{position:absolute;inset:0}
.aw .blob{position:absolute;border-radius:50%;filter:blur(90px);opacity:.6;animation:awfloat 20s ease-in-out infinite alternate}
@keyframes awfloat{0%{transform:translate(0,0) scale(1)}50%{transform:translate(70px,-50px) scale(1.12)}100%{transform:translate(-40px,30px) scale(.95)}}
.aw .sky{position:absolute;inset:0;background:linear-gradient(180deg,#0a0115 0%,#2a0838 38%,#7a1460 52%,#ff2e88 58%,#120320 58.2%,#07010d 100%)}
.aw .sun{position:absolute;left:50%;top:22%;width:min(42vw,420px);aspect-ratio:1;transform:translateX(-50%);border-radius:50%;background:linear-gradient(180deg,#ffe066 0%,#ff8a3d 40%,#ff2e88 75%);-webkit-mask:linear-gradient(180deg,#000 52%,transparent 52%,transparent 56%,#000 56%,#000 63%,transparent 63%,transparent 67%,#000 67%,#000 72%,transparent 72%,transparent 77%,#000 77%,#000 81%,transparent 81%,transparent 86%,#000 86%);box-shadow:0 0 120px rgba(255,46,136,.55);animation:awsun 6s ease-in-out infinite alternate}
@keyframes awsun{to{filter:brightness(1.15) saturate(1.2)}}
.aw .floor{position:absolute;left:-50%;right:-50%;top:58%;bottom:-40%;transform:perspective(320px) rotateX(62deg);transform-origin:top;background-image:linear-gradient(rgba(255,46,136,.85) 2px,transparent 2px),linear-gradient(90deg,rgba(43,212,224,.75) 2px,transparent 2px);background-size:70px 70px;animation:awgrid 1.6s linear infinite;-webkit-mask:linear-gradient(180deg,transparent,#000 30%)}
@keyframes awgrid{to{background-position:0 70px}}
.aw .stars{position:absolute;inset:0 0 45% 0;background-image:radial-gradient(1px 1px at 10% 20%,#fff,transparent),radial-gradient(1px 1px at 30% 70%,#fff,transparent),radial-gradient(1.5px 1.5px at 55% 30%,#fff,transparent),radial-gradient(1px 1px at 75% 15%,#fff,transparent),radial-gradient(1px 1px at 90% 60%,#fff,transparent),radial-gradient(1.5px 1.5px at 20% 50%,#fff,transparent),radial-gradient(1px 1px at 65% 80%,#fff,transparent);opacity:.7;animation:awtwinkle 4s ease-in-out infinite alternate}
@keyframes awtwinkle{to{opacity:.35}}
.aw.paused *{animation-play-state:paused!important}`;
		document.head.appendChild(s);
	}

	function canvasLoop(canvas, setup, draw, state) {
		const ctx = canvas.getContext('2d');
		let w = 0, h = 0, data = null, raf = 0, last = 0;
		const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
		const resize = () => {
			const r = canvas.getBoundingClientRect();
			w = Math.max(1, r.width); h = Math.max(1, r.height);
			canvas.width = w * dpr; canvas.height = h * dpr;
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
			data = setup(w, h, ctx);
		};
		const ro = new ResizeObserver(resize);
		ro.observe(canvas);
		resize();
		const frame = t => {
			raf = requestAnimationFrame(frame);
			if (state.paused || document.hidden || t - last < 1000 / 40) return;
			const dt = Math.min(0.1, (t - last) / 1000);
			last = t;
			draw(ctx, w, h, data, dt, state);
		};
		raf = requestAnimationFrame(frame);
		return () => { cancelAnimationFrame(raf); ro.disconnect(); };
	}

	// Smooth value noise for the hand-drawn looking scenes.
	const perm = new Uint8Array(512);
	{ const p = Array.from({ length: 256 }, (_, i) => i); for (let i = 255; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0; [p[i], p[j]] = [p[j], p[i]]; } for (let i = 0; i < 512; i++) perm[i] = p[i & 255]; }
	const fade = t => t * t * (3 - 2 * t);
	const hash = (x, y, z) => perm[(perm[(perm[x & 255] + y) & 255] + z) & 255] / 255;
	function noise3(x, y, z) {
		const X = Math.floor(x), Y = Math.floor(y), Z = Math.floor(z), fx = fade(x - X), fy = fade(y - Y), fz = fade(z - Z);
		const l = (a, b, t) => a + (b - a) * t;
		const c = (dx, dy, dz) => hash(X + dx, Y + dy, Z + dz);
		return l(l(l(c(0, 0, 0), c(1, 0, 0), fx), l(c(0, 1, 0), c(1, 1, 0), fx), fy), l(l(c(0, 0, 1), c(1, 0, 1), fx), l(c(0, 1, 1), c(1, 1, 1), fx), fy), fz);
	}

	const CANVAS = {
		// --- Calm, hand-made looking scenes ---
		rain: (accent) => ({
			setup: (w, h) => {
				// Out-of-focus city lights behind wet glass, drawn once.
				const bg = document.createElement('canvas');
				bg.width = w; bg.height = h;
				const b = bg.getContext('2d');
				const g = b.createLinearGradient(0, 0, 0, h);
				g.addColorStop(0, '#0c1016'); g.addColorStop(1, '#151a22');
				b.fillStyle = g; b.fillRect(0, 0, w, h);
				// Soft bokeh (radial gradients, so it looks the same in every browser engine).
				const tones = [[242, 180, 92], [232, 214, 168], [143, 179, 217], [217, 122, 92], [210, 210, 210]];
				for (let i = 0; i < 54; i++) {
					const [r, gg, bb] = tones[(Math.random() * tones.length) | 0], x = Math.random() * w, y = h * (0.3 + Math.random() * 0.65), rad = 14 + Math.random() * 46, a = 0.18 + Math.random() * 0.4;
					const rg = b.createRadialGradient(x, y, 0, x, y, rad);
					rg.addColorStop(0, `rgba(${r},${gg},${bb},${a})`); rg.addColorStop(0.55, `rgba(${r},${gg},${bb},${a * 0.6})`); rg.addColorStop(1, `rgba(${r},${gg},${bb},0)`);
					b.fillStyle = rg; b.fillRect(x - rad, y - rad, rad * 2, rad * 2);
				}
				const drops = Array.from({ length: Math.round(w * h / 5200) }, () => ({ x: Math.random() * w, y: Math.random() * h, l: 8 + Math.random() * 18, v: 380 + Math.random() * 420, a: 0.16 + Math.random() * 0.3 }));
				const beads = Array.from({ length: 70 }, () => ({ x: Math.random() * w, y: Math.random() * h, r: 1 + Math.random() * 2.6, v: Math.random() < 0.3 ? 8 + Math.random() * 40 : 0 }));
				return { bg, drops, beads };
			},
			draw: (ctx, w, h, d, dt) => {
				ctx.drawImage(d.bg, 0, 0, w, h);
				ctx.lineCap = 'round';
				for (const p of d.drops) {
					p.y += p.v * dt; p.x -= p.v * dt * 0.08;
					if (p.y > h) { p.y = -p.l; p.x = Math.random() * w * 1.1; }
					ctx.strokeStyle = `rgba(210,220,235,${p.a})`; ctx.lineWidth = 1;
					ctx.beginPath(); ctx.moveTo(p.x, p.y); ctx.lineTo(p.x + p.l * 0.08, p.y - p.l); ctx.stroke();
				}
				for (const b of d.beads) {
					b.y += b.v * dt;
					if (b.y > h + 5) { b.y = -5; b.x = Math.random() * w; }
					ctx.fillStyle = 'rgba(220,230,245,.18)'; ctx.beginPath(); ctx.arc(b.x, b.y, b.r, 0, 6.3); ctx.fill();
					ctx.fillStyle = 'rgba(255,255,255,.35)'; ctx.beginPath(); ctx.arc(b.x - b.r * 0.3, b.y - b.r * 0.3, b.r * 0.35, 0, 6.3); ctx.fill();
				}
			},
		}),
		contours: (accent) => ({
			setup: () => ({ t: Math.random() * 100, acc: 0 }),
			draw: (ctx, w, h, d, dt) => {
				// Topographic map lines that slowly shift, like a living hiking map.
				d.t += dt * 0.035; d.acc += dt;
				if (d.acc < 1 / 15) return;
				d.acc = 0;
				ctx.fillStyle = '#0f1113'; ctx.fillRect(0, 0, w, h);
				const cs = 16, cols = Math.ceil(w / cs) + 1, rows = Math.ceil(h / cs) + 1, f = new Float32Array(cols * rows);
				for (let j = 0; j < rows; j++) for (let i = 0; i < cols; i++) f[j * cols + i] = noise3(i * cs * 0.0042, j * cs * 0.0042, d.t) * 0.7 + noise3(i * cs * 0.011, j * cs * 0.011, d.t * 1.7 + 9) * 0.3;
				const levels = 14;
				for (let L = 1; L < levels; L++) {
					const iso = L / levels;
					ctx.strokeStyle = L % 5 === 0 ? accent + '88' : 'rgba(225,228,232,' + (L % 2 ? 0.11 : 0.18) + ')';
					ctx.lineWidth = L % 5 === 0 ? 1.3 : 1;
					ctx.beginPath();
					for (let j = 0; j < rows - 1; j++) for (let i = 0; i < cols - 1; i++) {
						const a = f[j * cols + i], b = f[j * cols + i + 1], c = f[(j + 1) * cols + i + 1], e = f[(j + 1) * cols + i];
						const idx = (a > iso) | ((b > iso) << 1) | ((c > iso) << 2) | ((e > iso) << 3);
						if (idx === 0 || idx === 15) continue;
						const x = i * cs, y = j * cs, lerp = (p, q) => (iso - p) / (q - p);
						const T = [x + cs * lerp(a, b), y], R = [x + cs, y + cs * lerp(b, c)], B = [x + cs * lerp(e, c), y + cs], Lp = [x, y + cs * lerp(a, e)];
						const seg = (p, q) => { ctx.moveTo(p[0], p[1]); ctx.lineTo(q[0], q[1]); };
						switch (idx) {
							case 1: case 14: seg(Lp, T); break; case 2: case 13: seg(T, R); break; case 3: case 12: seg(Lp, R); break;
							case 4: case 11: seg(R, B); break; case 6: case 9: seg(T, B); break; case 7: case 8: seg(Lp, B); break;
							case 5: seg(Lp, T); seg(R, B); break; case 10: seg(T, R); seg(Lp, B); break;
						}
					}
					ctx.stroke();
				}
			},
		}),
		snow: () => ({
			setup: (w, h) => ({ flakes: Array.from({ length: Math.round(w * h / 4200) }, () => { const z = Math.random(); return { x: Math.random() * w, y: Math.random() * h, z, r: 0.6 + z * 2.4, v: 12 + z * 46, s: Math.random() * 6.3 }; }), t: 0 }),
			draw: (ctx, w, h, d, dt) => {
				d.t += dt;
				const g = ctx.createLinearGradient(0, 0, 0, h);
				g.addColorStop(0, '#0a1222'); g.addColorStop(0.7, '#16233a'); g.addColorStop(1, '#25344d');
				ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
				// Distant pine ridge.
				ctx.fillStyle = '#0c1424';
				ctx.beginPath(); ctx.moveTo(0, h);
				for (let x = 0; x <= w; x += 14) ctx.lineTo(x, h * 0.82 - (Math.sin(x * 0.011) * 18 + Math.sin(x * 0.037) * 8 + ((x / 14) % 3 === 0 ? 14 : 0)));
				ctx.lineTo(w, h); ctx.fill();
				for (const f of d.flakes) {
					f.y += f.v * dt; f.x += Math.sin(d.t * 0.8 + f.s) * 10 * dt * (0.4 + f.z);
					if (f.y > h + 4) { f.y = -4; f.x = Math.random() * w; }
					ctx.fillStyle = `rgba(240,245,255,${0.35 + f.z * 0.55})`;
					ctx.beginPath(); ctx.arc(f.x, f.y, f.r, 0, 6.3); ctx.fill();
				}
			},
		}),
		fireflies: () => ({
			setup: (w, h) => {
				const glow = document.createElement('canvas');
				glow.width = glow.height = 64;
				const gc = glow.getContext('2d'), rg = gc.createRadialGradient(32, 32, 0, 32, 32, 32);
				rg.addColorStop(0, 'rgba(236,246,150,1)'); rg.addColorStop(0.18, 'rgba(214,236,110,.55)'); rg.addColorStop(1, 'rgba(180,220,90,0)');
				gc.fillStyle = rg; gc.fillRect(0, 0, 64, 64);
				return { glow, flies: Array.from({ length: 34 }, () => ({ x: Math.random() * w, y: h * (0.25 + Math.random() * 0.75), a: Math.random() * 6.3, s: 6 + Math.random() * 14, p: Math.random() * 6.3, k: 0.6 + Math.random() * 0.9 })) };
			},
			draw: (ctx, w, h, d, dt) => {
				const g = ctx.createLinearGradient(0, 0, 0, h);
				g.addColorStop(0, '#060b0a'); g.addColorStop(1, '#0d1a14');
				ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
				// Grass line.
				ctx.fillStyle = '#07100c';
				ctx.beginPath(); ctx.moveTo(0, h);
				for (let x = 0; x <= w; x += 6) ctx.lineTo(x, h - 24 - Math.abs(Math.sin(x * 0.7)) * 22 - Math.sin(x * 0.013) * 10);
				ctx.lineTo(w, h); ctx.fill();
				for (const f of d.flies) {
					f.a += (Math.random() - 0.5) * 1.6 * dt; f.p += dt * f.k;
					f.x += Math.cos(f.a) * f.s * dt; f.y += Math.sin(f.a) * f.s * dt * 0.6;
					if (f.x < -20) f.x = w + 20; if (f.x > w + 20) f.x = -20; if (f.y < h * 0.2) f.a = Math.PI / 2; if (f.y > h - 30) f.a = -Math.PI / 2;
					const lum = Math.max(0, Math.sin(f.p)) ** 2;
					if (lum < 0.02) continue;
					ctx.globalAlpha = lum; const sz = 18 + lum * 22;
					ctx.drawImage(d.glow, f.x - sz / 2, f.y - sz / 2, sz, sz);
				}
				ctx.globalAlpha = 1;
			},
		}),
		ridges: (accent) => ({
			setup: () => ({ t: 0 }),
			draw: (ctx, w, h, d, dt) => {
				// Stacked ridgelines, like an old pulsar chart.
				d.t += dt * 0.12;
				ctx.fillStyle = '#0d0d0f'; ctx.fillRect(0, 0, w, h);
				const n = 34, top = h * 0.16, gap = (h * 0.74) / n, mx = w * 0.18, ww = w - mx * 2;
				ctx.lineWidth = 1.2;
				for (let i = 0; i < n; i++) {
					const y0 = top + i * gap;
					ctx.beginPath(); ctx.moveTo(mx, y0);
					for (let x = 0; x <= ww; x += 5) {
						const u = x / ww, env = Math.exp(-((u - 0.5) ** 2) / 0.018);
						const v = noise3(u * 7, i * 0.37, d.t) * 0.7 + noise3(u * 19, i * 0.9, d.t * 1.3) * 0.3;
						ctx.lineTo(mx + x, y0 - env * v * gap * 4.2);
					}
					ctx.lineTo(mx + ww, y0);
					ctx.fillStyle = '#0d0d0f'; ctx.fill();
					ctx.strokeStyle = i === 22 ? accent : 'rgba(232,232,236,.62)';
					ctx.stroke();
				}
			},
		}),
		pixelcity: () => ({
			setup: (w, h) => {
				const S = 3, W = Math.ceil(w / S), H = Math.ceil(h / S);
				const sky = document.createElement('canvas'); sky.width = W; sky.height = H;
				const k = sky.getContext('2d'), g = k.createLinearGradient(0, 0, 0, H);
				g.addColorStop(0, '#120c26'); g.addColorStop(0.6, '#2a1a45'); g.addColorStop(1, '#4a2752');
				k.fillStyle = g; k.fillRect(0, 0, W, H);
				for (let i = 0; i < W * H / 260; i++) { k.fillStyle = Math.random() < 0.2 ? '#fff' : '#9a8fc0'; k.fillRect((Math.random() * W) | 0, (Math.random() * H * 0.55) | 0, 1, 1); }
				k.fillStyle = '#f3e9c6'; k.beginPath(); k.arc(W * 0.78, H * 0.18, 9, 0, 6.3); k.fill();
				k.fillStyle = '#2a1a45'; k.beginPath(); k.arc(W * 0.78 + 4, H * 0.18 - 2, 8, 0, 6.3); k.fill();
				const layers = [[0.42, '#1d1433', 0], [0.30, '#140e24', 1]].map(([hh, col, near]) => {
					const blds = [];
					for (let x = -10; x < W + 10;) { const bw = 8 + ((Math.random() * (near ? 22 : 16)) | 0), bh = (H * hh * (0.45 + Math.random() * 0.75)) | 0; blds.push({ x, bw, bh, win: [] }); x += bw + ((Math.random() * 3) | 0); }
					for (const b of blds) if (near) for (let yy = H - b.bh + 3; yy < H - 3; yy += 3) for (let xx = b.x + 2; xx < b.x + b.bw - 2; xx += 3) b.win.push({ x: xx, y: yy, on: Math.random() < 0.28 });
					return { col, blds, near };
				});
				return { S, W, H, sky, layers, buf: document.createElement('canvas'), plane: { x: -20, y: H * 0.3 }, acc: 0 };
			},
			draw: (ctx, w, h, d, dt) => {
				d.acc += dt;
				if (d.acc < 1 / 12) return;
				d.acc = 0;
				const { W, H } = d, buf = d.buf;
				if (buf.width !== W) { buf.width = W; buf.height = H; }
				const b = buf.getContext('2d');
				b.drawImage(d.sky, 0, 0);
				for (const L of d.layers) for (const bl of L.blds) {
					b.fillStyle = L.col; b.fillRect(bl.x, H - bl.bh, bl.bw, bl.bh);
					for (const wn of bl.win) { if (Math.random() < 0.002) wn.on = !wn.on; if (wn.on) { b.fillStyle = Math.random() < 0.003 ? '#fff6c8' : '#e9c46a'; b.fillRect(wn.x, wn.y, 1, 1); } }
				}
				d.plane.x += 0.35;
				if (d.plane.x > W + 20) { d.plane.x = -20; d.plane.y = H * (0.15 + Math.random() * 0.25); }
				if ((performance.now() / 500 | 0) % 2) { b.fillStyle = '#ff5a5a'; b.fillRect(d.plane.x | 0, d.plane.y | 0, 1, 1); }
				ctx.imageSmoothingEnabled = false;
				ctx.drawImage(buf, 0, 0, W * d.S, H * d.S);
			},
		}),
		film: (accent) => ({
			setup: () => {
				const grain = document.createElement('canvas');
				grain.width = grain.height = 160;
				const gc = grain.getContext('2d'), img = gc.createImageData(160, 160);
				for (let i = 0; i < img.data.length; i += 4) { const v = (Math.random() * 255) | 0; img.data[i] = img.data[i + 1] = img.data[i + 2] = v; img.data[i + 3] = 20; }
				gc.putImageData(img, 0, 0);
				return { grain, t: Math.random() * 50, acc: 0 };
			},
			draw: (ctx, w, h, d, dt) => {
				// A soft, slowly drifting gradient with film grain on top.
				d.t += dt * 0.05; d.acc += dt;
				if (d.acc < 1 / 20) return;
				d.acc = 0;
				ctx.fillStyle = '#121214'; ctx.fillRect(0, 0, w, h);
				const spots = [[accent, 0.55], ['#3a4a5c', 0.6], ['#5c4a3a', 0.45]];
				spots.forEach(([c, a], i) => {
					const x = w * (0.5 + 0.38 * Math.sin(d.t * (0.7 + i * 0.23) + i * 2)), y = h * (0.5 + 0.34 * Math.cos(d.t * (0.5 + i * 0.31) + i));
					const r = Math.max(w, h) * 0.55, g = ctx.createRadialGradient(x, y, 0, x, y, r);
					g.addColorStop(0, c + Math.round(a * 90).toString(16).padStart(2, '0')); g.addColorStop(1, c + '00');
					ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
				});
				ctx.fillStyle = ctx.createPattern(d.grain, 'repeat');
				ctx.save(); ctx.translate((Math.random() * 160) | 0, (Math.random() * 160) | 0); ctx.fillRect(-160, -160, w + 320, h + 320); ctx.restore();
			},
		}),

		starfield: (accent) => ({
			setup: (w, h) => Array.from({ length: 420 }, () => ({ x: (Math.random() - 0.5) * w, y: (Math.random() - 0.5) * h, z: Math.random() * w })),
			draw: (ctx, w, h, stars, dt) => {
				ctx.fillStyle = 'rgba(5,6,15,.45)';
				ctx.fillRect(0, 0, w, h);
				for (const s of stars) {
					const pz = s.z;
					s.z -= w * 0.35 * dt;
					if (s.z < 1) { s.x = (Math.random() - 0.5) * w; s.y = (Math.random() - 0.5) * h; s.z = w; continue; }
					const k = 128 / s.z, pk = 128 / pz;
					const x = w / 2 + s.x * k, y = h / 2 + s.y * k;
					const px = w / 2 + s.x * pk, py = h / 2 + s.y * pk;
					const a = Math.min(1, 1.4 - s.z / w);
					ctx.strokeStyle = Math.random() < 0.02 ? accent : `rgba(220,230,255,${a})`;
					ctx.lineWidth = Math.max(0.6, 2.2 * (1 - s.z / w));
					ctx.beginPath(); ctx.moveTo(px, py); ctx.lineTo(x, y); ctx.stroke();
				}
			},
		}),
		matrix: (accent) => ({
			setup: (w, h, ctx) => { ctx.fillStyle = '#000'; ctx.fillRect(0, 0, w, h); const cols = Math.ceil(w / 16); return { cols: Array.from({ length: cols }, () => Math.random() * -h / 16), acc: 0 }; },
			draw: (ctx, w, h, d, dt) => {
				d.acc += dt;
				if (d.acc < 0.05) return;
				d.acc = 0;
				ctx.fillStyle = 'rgba(0,0,0,.09)';
				ctx.fillRect(0, 0, w, h);
				ctx.font = '15px ui-monospace, Menlo, monospace';
				const chars = 'アイウエオカキクケコサシスセソ0123456789ABCDEF<>/{}*+=';
				d.cols.forEach((y, i) => {
					const c = chars[(Math.random() * chars.length) | 0];
					ctx.fillStyle = Math.random() < 0.08 ? '#fff' : accent;
					ctx.fillText(c, i * 16, y * 16);
					d.cols[i] = y * 16 > h && Math.random() > 0.975 ? 0 : y + 1;
				});
			},
		}),
		particles: (accent) => ({
			setup: (w, h) => {
				const mouse = { x: -999, y: -999 };
				window.addEventListener('mousemove', e => { mouse.x = e.clientX; mouse.y = e.clientY; }, { passive: true });
				return { mouse, pts: Array.from({ length: Math.min(110, Math.round(w * h / 9000)) }, () => ({ x: Math.random() * w, y: Math.random() * h, vx: (Math.random() - 0.5) * 30, vy: (Math.random() - 0.5) * 30 })) };
			},
			draw: (ctx, w, h, d, dt) => {
				const g = ctx.createRadialGradient(w * 0.3, h * 0.3, 0, w * 0.3, h * 0.3, Math.max(w, h));
				g.addColorStop(0, '#22123a'); g.addColorStop(1, '#09090c');
				ctx.fillStyle = g; ctx.fillRect(0, 0, w, h);
				const pts = d.pts;
				for (const p of pts) {
					p.x += p.vx * dt; p.y += p.vy * dt;
					if (p.x < 0 || p.x > w) p.vx *= -1;
					if (p.y < 0 || p.y > h) p.vy *= -1;
					const dx = p.x - d.mouse.x, dy = p.y - d.mouse.y, dist = Math.hypot(dx, dy);
					if (dist < 120 && dist > 0) { p.x += dx / dist * 60 * dt; p.y += dy / dist * 60 * dt; }
				}
				ctx.lineWidth = 1;
				for (let i = 0; i < pts.length; i++) for (let j = i + 1; j < pts.length; j++) {
					const a = pts[i], b = pts[j], dd = Math.hypot(a.x - b.x, a.y - b.y);
					if (dd < 130) { ctx.strokeStyle = accent + Math.round((1 - dd / 130) * 120).toString(16).padStart(2, '0'); ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke(); }
				}
				ctx.fillStyle = '#fff';
				for (const p of pts) { ctx.beginPath(); ctx.arc(p.x, p.y, 1.6, 0, 6.3); ctx.fill(); }
			},
		}),
	};

	// info: { key, kind: 'builtin'|'video'|'image', url, dim, blur }
	function mount(el, info, opts = {}) {
		addStyle();
		el.innerHTML = '';
		const root = document.createElement('div');
		root.className = 'aw';
		const media = document.createElement('div');
		media.className = 'media' + (info.blur > 0 ? ' blurred' : '');
		if (info.blur > 0) media.style.filter = `blur(${info.blur}px)`;
		root.appendChild(media);
		const dim = document.createElement('div');
		dim.className = 'dim';
		dim.style.background = `rgba(0,0,0,${Math.max(0, Math.min(0.9, info.dim ?? 0.35)) + (opts.extraDim || 0)})`;
		if (opts.scrim) dim.style.background = opts.scrim(info.dim ?? 0.35);
		root.appendChild(dim);
		el.appendChild(root);

		const state = { paused: !!opts.paused };
		let stop = () => {};
		const accent = opts.accent || '#ff3b4e';
		let video = null;

		if (info.poster) {
			// Show a still frame instantly so there's never a black flash while the video wakes up.
			root.style.backgroundImage = `url("${info.poster}")`;
			root.style.backgroundSize = 'cover';
			root.style.backgroundPosition = 'center';
		}
		if (info.kind === 'video' && info.url) {
			video = document.createElement('video');
			if (info.poster) video.poster = info.poster;
			Object.assign(video, { src: info.url, muted: true, loop: true, autoplay: true, playsInline: true, defaultMuted: true });
			video.setAttribute('muted', '');
			video.setAttribute('playsinline', '');
			media.appendChild(video);
			if (!state.paused) video.play().catch(() => {});
		} else if (info.kind === 'image' && info.url) {
			const img = document.createElement('div');
			img.className = 'img';
			img.style.backgroundImage = `url("${info.url}")`;
			media.appendChild(img);
		} else {
			const key = BUILTIN[info.key] ? info.key : 'midnight';
			if (BLOBS[key]) {
				BLOBS[key].forEach((c, i) => {
					const b = document.createElement('div');
					b.className = 'blob';
					const size = [560, 480, 640][i];
					if (key === 'midnight') b.style.opacity = '.42';
					b.style.cssText += `;background:${c};width:${size}px;height:${size}px;${['left:-140px;top:-160px', 'right:-120px;top:18%', 'left:28%;bottom:-280px'][i]};animation-delay:${-i * 7}s`;
					media.appendChild(b);
				});
			} else if (CANVAS[key]) {
				const c = document.createElement('canvas');
				media.appendChild(c);
				const def = CANVAS[key](accent);
				stop = canvasLoop(c, def.setup, def.draw, state);
			} else {
				media.style.background = 'radial-gradient(circle at 30% 20%,#1c1c24,#0b0b0e 70%)';
			}
		}
		root.classList.toggle('paused', state.paused);
		return {
			pause(p) {
				state.paused = !!p;
				root.classList.toggle('paused', state.paused);
				if (video) { if (p) video.pause(); else video.play().catch(() => {}); }
			},
			destroy() { stop(); if (video) { video.pause(); video.removeAttribute('src'); video.load(); } el.innerHTML = ''; },
		};
	}

	return { BUILTIN, mount };
})();
