// Arce Chat engine — runs in a hidden page. Friends, end-to-end encrypted messages and files over public Nostr relays.
(() => {
	const native = (cmd, args = {}) => window.webkit.messageHandlers.chatd.postMessage({ cmd, args });
	const NT = window.NT;
	const now = () => Math.floor(Date.now() / 1000);
	const rid = () => NT.bytesToHex(crypto.getRandomValues(new Uint8Array(8)));
	const DEFAULT_RELAYS = ['wss://relay.damus.io', 'wss://nos.lol', 'wss://relay.primal.net', 'wss://nostr.mom', 'wss://relay.nostr.net'];
	const DM = 4, TYPING = 20004, APP = 30078;
	const MAX_MSGS = 400;

	let S = null, sk = null, me = '', relays = [];
	const subs = new Map(), okWaits = new Map(), convKeys = {}, online = {}, typingUntil = {}, typingName = {};
	let activity = '', presenceTimer = null, lastTypingSent = {};

	/* ---------------- helpers ---------------- */

	const clean = (s, n = 24) => String(s || '').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, n);
	// Profile pictures: a small photo (data URL, under 24 KB) or initials on a colour.
	const cleanAvatar = a => { const out = { c: Math.max(0, Math.min(11, parseInt(a && a.c) || 0)) }; const img = a && a.img; if (typeof img === 'string' && img.length < 24000 && /^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(img)) out.img = img; return out; };
	const b64ToBytes = b64 => { const s = atob(b64); const out = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i); return out; };
	const bytesToB64 = bytes => { let s = ''; for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000)); return btoa(s); };
	const convKey = pk => convKeys[pk] || (convKeys[pk] = NT.nip44.getConversationKey(sk, pk));
	const isHex64 = s => /^[0-9a-f]{64}$/.test(s);
	// A conversation is a friend's key, or "g:<id>" for a group.
	const isGroup = cid => typeof cid === 'string' && cid.startsWith('g:');
	const groupOf = cid => isGroup(cid) ? (S.groups || {})[cid.slice(2)] : null;
	const recOf = cid => isGroup(cid) ? groupOf(cid) : S.friends[cid];
	const canTalk = cid => { if (isGroup(cid)) return !!groupOf(cid); const f = S.friends[cid]; return !!f && f.state === 'friend'; };
	const membersOf = cid => isGroup(cid) ? (groupOf(cid) || { members: [] }).members.map(x => x.pk).filter(pk => pk !== me && !(S.blocked || []).includes(pk)) : [cid];
	const nameOf = (pk, g) => { if (pk === me) return S.name; const f = S.friends[pk]; if (f && f.state === 'friend') return f.name; const m = g && g.members.find(x => x.pk === pk); return m ? m.name : 'Someone'; };
	async function sendTo(cid, payload, kind) {
		const g = groupOf(cid);
		if (g) payload = Object.assign({ g: g.id }, payload);
		const res = await Promise.all(membersOf(cid).map(pk => sendDM(pk, payload, kind)));
		return res.some(Boolean);
	}
	const cleanGroup = g => {
		if (!g || typeof g !== 'object' || !/^[0-9a-f]{16}$/.test(g.id || '')) return null;
		const members = (Array.isArray(g.members) ? g.members : []).filter(x => x && isHex64(x.pk || '')).slice(0, 50).map(x => ({ pk: x.pk, name: clean(x.name) || 'Someone', avatar: cleanAvatar(x.avatar) }));
		return { id: g.id, name: clean(g.name, 40) || 'Group', admin: isHex64(g.admin || '') ? g.admin : '', icon: '', members };
	};
	const groupWire = g => ({ id: g.id, name: g.name, admin: g.admin, icon: g.icon, members: [{ pk: me, name: S.name, avatar: S.avatar }].concat(g.members.filter(x => x.pk !== me)) });
	const cleanRe = re => re && typeof re === 'object' && re.id ? { id: clean(re.id, 32), text: String(re.text || '').slice(0, 140), name: clean(re.name) } : null;

	let saveT = null;
	const save = () => { clearTimeout(saveT); saveT = setTimeout(() => native('save', { data: JSON.stringify(S) }), 500); };
	let emitT = null;
	const changed = () => { clearTimeout(emitT); emitT = setTimeout(() => native('event', { unread: unreadTotal(), ready: !!sk }), 120); };

	function remember(id) {
		if (!S.seen) S.seen = [];
		S.seen.push(id);
		if (S.seen.length > 3000) S.seen.splice(0, S.seen.length - 3000);
	}

	/* ---------------- relays ---------------- */

	class Relay {
		constructor(url) { this.url = url; this.ws = null; this.open = false; this.queue = []; this.backoff = 1500; this.connect(); }
		connect() {
			try { this.ws = new WebSocket(this.url); } catch (e) { this.retry(); return; }
			this.ws.onopen = () => {
				this.open = true;
				this.backoff = 1500;
				for (const [id, s] of subs) this.raw(['REQ', id, ...s.filters]);
				for (const m of this.queue.splice(0)) this.raw(m);
				changed();
				scheduleRetry();
			};
			this.ws.onclose = () => { this.open = false; this.retry(); changed(); };
			this.ws.onerror = () => {};
			this.ws.onmessage = e => { let m; try { m = JSON.parse(e.data); } catch (err) { return; } onRelayMessage(this, m); };
		}
		retry() { clearTimeout(this.rt); this.rt = setTimeout(() => this.connect(), this.backoff); this.backoff = Math.min(this.backoff * 2, 60000); }
		raw(m) { try { this.ws.send(JSON.stringify(m)); } catch (e) {} }
		send(m) { if (this.open && this.ws && this.ws.readyState === 1) this.raw(m); else if (m[0] === 'EVENT') { this.queue.push(m); if (this.queue.length > 200) this.queue.shift(); } }
		kick() { if (!this.open) { clearTimeout(this.rt); this.backoff = 1500; try { this.ws && this.ws.close(); } catch (e) {} this.connect(); } }
	}

	function onRelayMessage(relay, m) {
		if (m[0] === 'EVENT') {
			const s = subs.get(m[1]), ev = m[2];
			if (!s || !ev || typeof ev.id !== 'string' || s.seen.has(ev.id)) return;
			if (!NT.verifyEvent(ev)) return;
			s.seen.add(ev.id);
			if (s.seen.size > 5000) s.seen.clear();
			try { s.onEvent(ev); } catch (e) { console.warn(e); }
		} else if (m[0] === 'EOSE') {
			const s = subs.get(m[1]);
			if (s) { s.eose.add(relay.url); if (s.onEose) s.onEose(); }
		} else if (m[0] === 'OK') {
			const w = okWaits.get(m[1]);
			if (w && m[2]) { okWaits.delete(m[1]); w(true); }
		}
	}

	function subscribe(id, filters, onEvent, onEose) {
		subs.set(id, { filters, onEvent, onEose, seen: new Set(), eose: new Set() });
		for (const r of relays) if (r.open) r.raw(['REQ', id, ...filters]);
	}
	function unsubscribe(id) {
		if (!subs.has(id)) return;
		subs.delete(id);
		for (const r of relays) if (r.open) r.raw(['CLOSE', id]);
	}
	function publish(template) {
		const ev = NT.finalizeEvent(template, sk);
		return new Promise(res => {
			const t = setTimeout(() => { okWaits.delete(ev.id); res(false); }, 8000);
			okWaits.set(ev.id, ok => { clearTimeout(t); res(ok); });
			for (const r of relays) r.send(['EVENT', ev]);
		});
	}
	const openRelays = () => relays.filter(r => r.open).length;

	/* ---------------- profile & presence ---------------- */

	const myProfile = () => ({ name: S.name, avatar: S.avatar });
	function sendDM(pk, payload, kind = DM) {
		const content = NT.nip44.encrypt(JSON.stringify(payload), convKey(pk));
		return publish({ kind, created_at: now(), tags: [['p', pk]], content });
	}
	function publishPresence(isOnline = true) {
		if (!sk || !S.name) return Promise.resolve(false);
		const body = { name: S.name, avatar: S.avatar, text: S.statusText || '', activity: S.shareActivity && isOnline ? activity : '', online: isOnline, ts: now() };
		return publish({ kind: APP, created_at: now(), tags: [['d', 'arce-status']], content: JSON.stringify(body) });
	}
	function publishUsername() {
		if (!sk || !S.name) return;
		publish({ kind: APP, created_at: now(), tags: [['d', 'arce-user:' + S.name.toLowerCase()], ['t', 'arce']], content: JSON.stringify(myProfile()) });
	}

	function friendList() { return Object.values(S.friends); }
	function subscribeStatus() {
		const pks = friendList().filter(f => f.state === 'friend').map(f => f.pk);
		unsubscribe('status');
		if (!pks.length) return;
		subscribe('status', [{ kinds: [APP], authors: pks, '#d': ['arce-status'] }], ev => {
			let d;
			try { d = JSON.parse(ev.content); } catch (e) { return; }
			const prev = online[ev.pubkey];
			if (prev && prev.created > ev.created_at) return;
			online[ev.pubkey] = { created: ev.created_at, ts: Number(d.ts) || ev.created_at, online: d.online !== false, text: clean(d.text, 80), activity: clean(d.activity, 60) };
			const f = S.friends[ev.pubkey];
			if (f) { if (d.name) f.name = clean(d.name); if (d.avatar) f.avatar = cleanAvatar(d.avatar); save(); }
			changed();
		});
	}
	const isOnline = pk => { const o = online[pk]; return !!(o && o.online && now() - o.ts < 330); };

	/* ---------------- messages ---------------- */

	function addMsg(cid, m) {
		const list = S.msgs[cid] || (S.msgs[cid] = []);
		if (list.some(x => x.id === m.id)) return false;
		list.push(m);
		list.sort((a, b) => a.ts - b.ts);
		if (list.length > MAX_MSGS) list.splice(0, list.length - MAX_MSGS);
		const r = recOf(cid);
		if (r) r.lastTs = Math.max(r.lastTs || 0, m.ts);
		save();
		return true;
	}
	const unread = cid => { const r = recOf(cid); return r ? (S.msgs[cid] || []).filter(m => m.from === 'them' && m.ts > (r.lastRead || 0)).length : 0; };
	const unreadTotal = () => sk ? friendList().filter(f => f.state === 'friend').reduce((n, f) => n + unread(f.pk), 0) + friendList().filter(f => f.state === 'in').length + Object.keys(S.groups || {}).reduce((n, id) => n + unread('g:' + id), 0) : 0;
	const preview = m => !m ? '' : m.type === 'file' ? (/^image\//.test(m.file.mime) ? 'Photo' : m.file.name) : m.text;

	function onDM(ev) {
		const from = ev.pubkey;
		if (from === me || (S.seen || []).includes(ev.id) || (S.blocked || []).includes(from)) return;
		let p;
		try { p = JSON.parse(NT.nip44.decrypt(ev.content, convKey(from))); } catch (e) { return; }
		remember(ev.id);
		const f = S.friends[from];
		const g = p.g && typeof p.g === 'string' ? (S.groups || {})[p.g] : null;
		const inGroup = g && g.members.some(x => x.pk === from);
		const cid = g ? 'g:' + g.id : from;
		const prof = () => { if (f) { if (p.name) f.name = clean(p.name); if (p.avatar) f.avatar = cleanAvatar(p.avatar); } };
		switch (p.t) {
			case 'req':
				if (!f) {
					S.friends[from] = { pk: from, name: clean(p.name) || 'Someone', avatar: cleanAvatar(p.avatar), state: 'in', added: ev.created_at, lastTs: ev.created_at };
					native('notify', { kind: 'request', pk: from, name: S.friends[from].name, text: 'wants to be your friend' });
				} else if (f.state === 'out' || f.state === 'friend') {
					prof();
					const wasOut = f.state === 'out';
					f.state = 'friend';
					sendDM(from, Object.assign({ t: 'acc' }, myProfile()));
					if (wasOut) { subscribeStatus(); native('notify', { kind: 'accepted', pk: from, name: f.name, text: 'is now your friend' }); }
				}
				break;
			case 'acc':
				if (f && (f.state === 'out' || f.state === 'friend')) {
					prof();
					const was = f.state;
					f.state = 'friend';
					f.lastTs = Math.max(f.lastTs || 0, ev.created_at);
					if (was === 'out') { subscribeStatus(); native('notify', { kind: 'accepted', pk: from, name: f.name, text: 'accepted your friend request' }); }
				}
				break;
			case 'rm':
				if (f) { delete S.friends[from]; delete S.msgs[from]; subscribeStatus(); }
				break;
			case 'prof':
				prof();
				break;
			case 'ginv':
			case 'gupd': {
				// Group invite or update. New groups only come from friends; changes only from the group's admin.
				const ng = cleanGroup(p.g);
				if (!ng) return;
				const have = (S.groups || {})[ng.id];
				if (have ? have.admin !== from : (!f || f.state !== 'friend' || ng.admin !== from)) return;
				S.groups = S.groups || {};
				if (!ng.members.some(x => x.pk === me)) { if (have) { delete S.groups[ng.id]; delete S.msgs['g:' + ng.id]; } break; }
				ng.members = ng.members.filter(x => x.pk !== me);
				if (have) Object.assign(have, { name: ng.name, icon: ng.icon, members: ng.members });
				else {
					S.groups[ng.id] = Object.assign(ng, { created: ev.created_at, lastTs: ev.created_at, lastRead: 0 });
					native('notify', { kind: 'message', pk: 'g:' + ng.id, name: ng.name, text: `${f.name} added you to the group` });
				}
				break;
			}
			case 'gleave':
				if (g && inGroup) { g.members = g.members.filter(x => x.pk !== from); addMsg(cid, { id: 'l' + ev.id.slice(0, 15), from: 'sys', type: 'sys', text: `${nameOf(from, g)} left the group`, ts: ev.created_at }); }
				break;
			case 'react': {
				if (g ? !inGroup : (!f || f.state !== 'friend')) return;
				const m = (S.msgs[cid] || []).find(x => x.id === p.id);
				const e = clean(p.e, 8);
				if (!m || !e) return;
				m.reacts = m.reacts || {};
				const who = new Set(m.reacts[e] || []);
				if (p.on === false) who.delete(from); else who.add(from);
				if (who.size) m.reacts[e] = [...who]; else delete m.reacts[e];
				break;
			}
			case 'msg':
			case 'file': {
				if (p.g) { if (!inGroup) return; }
				else if (!f || f.state !== 'friend') return;
				// Keep the order your friend sent things in (big files finish uploading later than texts sent after them).
				const at = Number(p.at);
				const m = { id: clean(p.id, 32) || ev.id, from: 'them', ts: at && Math.abs(at - ev.created_at) < 86400 ? Math.min(at, ev.created_at) : ev.created_at, type: p.t === 'file' ? 'file' : 'text' };
				if (m.type === 'text') m.text = String(p.text || '').slice(0, 4000);
				else m.file = { name: clean(p.name, 120) || 'file', size: Number(p.size) || 0, mime: clean(p.mime, 80), url: String(p.url || ''), key: String(p.key || ''), k: String(p.k || ''), iv: String(p.iv || ''), enc: p.enc === 'v2' ? 'v2' : '', thumb: /^data:image\/(jpeg|png|webp);base64,/.test(p.thumb || '') ? p.thumb : '' };
				if (m.type === 'file' && !/^https:\/\//.test(m.file.url)) return;
				const re = cleanRe(p.re);
				if (re) m.re = re;
				if (g) m.by = from;
				delete typingUntil[cid];
				queueAck(from, m.id, g && g.id);
				if (addMsg(cid, m) && m.ts > now() - 600) native('notify', { kind: 'message', pk: cid, name: g ? g.name : f.name, text: g ? `${nameOf(from, g)}: ${preview(m)}` : preview(m) });
				break;
			}
			case 'ack': {
				// Your friend's Arce received these messages.
				if (!Array.isArray(p.ids) || (g ? !inGroup : !f)) break;
				let any = false;
				for (const m of S.msgs[cid] || []) {
					if (m.from !== 'me' || m.status === 'delivered' || !p.ids.includes(m.id)) continue;
					if (g) {
						// In a group it's "Delivered" once everyone in it has it.
						m.acked = [...new Set((m.acked || []).concat(from))];
						if (!g.members.every(x => m.acked.includes(x.pk))) { any = true; continue; }
					}
					m.status = 'delivered';
					any = true;
				}
				if (!any) return;
				break;
			}
		}
		save();
		changed();
	}

	function onTyping(ev) {
		const from = ev.pubkey;
		if (ev.created_at < now() - 15) return;
		let p;
		try { p = JSON.parse(NT.nip44.decrypt(ev.content, convKey(from))); if (p.t !== 'typing') return; } catch (e) { return; }
		const g = p.g ? (S.groups || {})[p.g] : null;
		if (g) { if (!g.members.some(x => x.pk === from)) return; typingUntil['g:' + g.id] = Date.now() + 6000; typingName['g:' + g.id] = nameOf(from, g); }
		else { const f = S.friends[from]; if (!f || f.state !== 'friend') return; typingUntil[from] = Date.now() + 6000; }
		changed();
		setTimeout(changed, 6200);
	}

	/* ---------------- delivery receipts & automatic retry ---------------- */

	const ackQueue = {};
	let ackTimer = null;
	function queueAck(pk, id, gid) {
		const key = gid ? pk + ':' + gid : pk;
		(ackQueue[key] = ackQueue[key] || []).push(id);
		clearTimeout(ackTimer);
		ackTimer = setTimeout(() => {
			for (const [k, ids] of Object.entries(ackQueue)) { delete ackQueue[k]; const [to, g] = k.split(':'); sendDM(to, g ? { t: 'ack', ids: ids.slice(-100), g } : { t: 'ack', ids: ids.slice(-100) }); }
		}, 1200);
	}
	const payloadFor = m => {
		const p = m.type === 'text' ? { t: 'msg', id: m.id, text: m.text, at: m.ts } : { t: 'file', id: m.id, at: m.ts, name: m.file.name, size: m.file.size, mime: m.file.mime, url: m.file.url, key: m.file.key, k: m.file.k, iv: m.file.iv, enc: m.file.enc, thumb: m.file.thumb };
		if (m.re) p.re = m.re;
		return p;
	};
	let retryTimer = null, retrying = false;
	function scheduleRetry() { clearTimeout(retryTimer); retryTimer = setTimeout(retryPending, 1500); }
	async function retryPending() {
		// Resend anything that didn't make it while you were offline (last 2 days).
		if (retrying || !sk || !openRelays()) return;
		retrying = true;
		try {
			for (const [pk, list] of Object.entries(S.msgs)) {
				if (!canTalk(pk)) continue;
				for (const m of list) {
					if (m.from !== 'me' || m.ts < now() - 2 * 86400) continue;
					const stuck = m.status === 'failed' || (m.status === 'sending' && now() - m.ts > 20 && (m.type === 'text' || m.file.url));
					if (!stuck || (m.type === 'file' && !m.file.url)) continue;
					m.status = 'sending';
					changed();
					m.status = (await sendTo(pk, payloadFor(m))) ? 'sent' : 'failed';
					save();
					changed();
				}
			}
		} finally { retrying = false; }
	}

	/* ---------------- sync between your devices ----------------
	   Your other devices sign in with the same key (a link code). Bookmarks, settings, the new tab page and your
	   friends list are saved encrypted to yourself on the relays; the newest copy wins. Messages you send from one
	   device show up on the others too. */

	const SYNC_SECTIONS = ['chat', 'bookmarks', 'settings', 'newtab', 'passwords'];
	const hashOf = str => { let h = 5381; for (let i = 0; i < str.length; i++) h = ((h * 33) ^ str.charCodeAt(i)) >>> 0; return h.toString(16) + ':' + str.length; };
	let syncTimer = null, syncReady = false;
	const syncOn = () => !!(S && S.sync && S.sync.on && sk);
	const selfKey = () => convKey(me);

	function chatSyncData() {
		return {
			profile: { name: S.name, avatar: S.avatar, statusText: S.statusText || '', shareActivity: !!S.shareActivity },
			friends: friendList().filter(f => f.state === 'friend' || f.state === 'out').map(f => ({ pk: f.pk, name: f.name, avatar: f.avatar, state: f.state, added: f.added || 0 })),
			groups: Object.values(S.groups || {}).map(g => ({ id: g.id, name: g.name, admin: g.admin, icon: g.icon, members: g.members, created: g.created || 0 })),
			blocked: (S.blocked || []).slice(-200),
		};
	}
	function applyChatSync(d) {
		if (!d || typeof d !== 'object') return;
		if (d.profile) { const n = clean(d.profile.name), had = !!S.name; if (n.length >= 2) S.name = n; if (!had && S.name) setTimeout(() => { publishPresence(true); publishUsername(); }, 300); S.avatar = cleanAvatar(d.profile.avatar); S.statusText = clean(d.profile.statusText, 80); S.shareActivity = !!d.profile.shareActivity; }
		for (const x of Array.isArray(d.friends) ? d.friends : []) {
			if (!isHex64(x.pk || '') || x.pk === me) continue;
			const f = S.friends[x.pk];
			if (!f) S.friends[x.pk] = { pk: x.pk, name: clean(x.name) || 'Arce user', avatar: cleanAvatar(x.avatar), state: x.state === 'friend' ? 'friend' : 'out', added: Number(x.added) || now(), lastTs: Number(x.added) || now() };
			else if (x.state === 'friend' && f.state !== 'friend') f.state = 'friend';
		}
		for (const x of Array.isArray(d.groups) ? d.groups : []) {
			const g = cleanGroup(x);
			if (!g) continue;
			g.members = g.members.filter(m => m.pk !== me);
			const have = (S.groups || {})[g.id];
			if (have) Object.assign(have, { name: g.name, icon: g.icon, members: g.members, admin: g.admin });
			else S.groups[g.id] = Object.assign(g, { created: Number(x.created) || now(), lastTs: Number(x.created) || now(), lastRead: 0 });
		}
		S.blocked = [...new Set((S.blocked || []).concat((Array.isArray(d.blocked) ? d.blocked : []).filter(isHex64)))].slice(-500);
		subscribeStatus();
		changed();
	}
	async function sectionData(sec) {
		if (sec === 'chat') return chatSyncData();
		const r = await native('syncGet', { section: sec });
		return r && r.data !== undefined ? r.data : null;
	}
	// Push anything that changed on this device.
	async function syncLocal(force) {
		if (!syncOn() || (!syncReady && !force)) return;
		for (const sec of SYNC_SECTIONS) {
			let data;
			try { data = await sectionData(sec); } catch (e) { continue; }
			if (data === null || data === undefined) continue;
			const json = JSON.stringify(data);
			if (json.length > 60000) continue;
			const h = hashOf(json), cur = S.sync.sec[sec];
			if (cur && cur.hash === h && !force) continue;
			if (cur && cur.hash === h && force && cur.pushed) continue;
			const ts = Date.now();
			S.sync.sec[sec] = { hash: h, ts, pushed: true };
			save();
			const content = NT.nip44.encrypt(JSON.stringify({ v: 1, ts, data }), selfKey());
			await publish({ kind: APP, created_at: now(), tags: [['d', 'arce-sync:' + sec]], content });
		}
	}
	async function onSyncEvent(ev) {
		if (ev.pubkey !== me) return;
		const d = (ev.tags.find(t => t[0] === 'd') || [])[1] || '';
		const sec = d.replace(/^arce-sync:/, '');
		if (!SYNC_SECTIONS.includes(sec)) return;
		let p;
		try { p = JSON.parse(NT.nip44.decrypt(ev.content, selfKey())); } catch (e) { return; }
		const ts = Number(p.ts) || 0, cur = S.sync.sec[sec];
		if (cur && cur.ts >= ts) return;
		if (sec === 'chat') applyChatSync(p.data);
		else { try { await native('syncSet', { section: sec, data: p.data }); } catch (e) { return; } }
		let after = p.data;
		try { after = await sectionData(sec); } catch (e) {}
		S.sync.sec[sec] = { hash: hashOf(JSON.stringify(after)), ts, pushed: true };
		save();
		changed();
	}
	// Messages you sent from your other devices.
	function onMyDM(ev) {
		if (ev.pubkey !== me || (S.seen || []).includes(ev.id)) return;
		const to = (ev.tags.find(t => t[0] === 'p') || [])[1];
		if (!isHex64(to || '') || to === me) return;
		let p;
		try { p = JSON.parse(NT.nip44.decrypt(ev.content, convKey(to))); } catch (e) { return; }
		remember(ev.id);
		const g = p.g && typeof p.g === 'string' ? (S.groups || {})[p.g] : null;
		const cid = g ? 'g:' + g.id : to;
		switch (p.t) {
			case 'msg':
			case 'file': {
				if (!canTalk(cid)) return;
				const at = Number(p.at);
				const m = { id: clean(p.id, 32) || ev.id, from: 'me', status: 'sent', ts: at && Math.abs(at - ev.created_at) < 86400 ? Math.min(at, ev.created_at) : ev.created_at, type: p.t === 'file' ? 'file' : 'text' };
				if (m.type === 'text') m.text = String(p.text || '').slice(0, 4000);
				else { m.file = { name: clean(p.name, 120) || 'file', size: Number(p.size) || 0, mime: clean(p.mime, 80), url: String(p.url || ''), key: String(p.key || ''), k: String(p.k || ''), iv: String(p.iv || ''), enc: p.enc === 'v2' ? 'v2' : '', thumb: /^data:image\/(jpeg|png|webp);base64,/.test(p.thumb || '') ? p.thumb : '' }; if (!/^https:\/\//.test(m.file.url)) return; }
				const re = cleanRe(p.re);
				if (re) m.re = re;
				if (addMsg(cid, m)) { const r = recOf(cid); if (r) r.lastRead = Math.max(r.lastRead || 0, m.ts); }
				break;
			}
			case 'react': {
				const m = (S.msgs[cid] || []).find(x => x.id === p.id), e = clean(p.e, 8);
				if (!m || !e) return;
				m.reacts = m.reacts || {};
				const who = new Set(m.reacts[e] || []);
				if (p.on === false) who.delete('me'); else who.add('me');
				if (who.size) m.reacts[e] = [...who]; else delete m.reacts[e];
				break;
			}
			case 'ginv':
			case 'gupd': {
				const ng = cleanGroup(p.g);
				if (!ng || ng.admin !== me) return;
				ng.members = ng.members.filter(x => x.pk !== me);
				const have = S.groups[ng.id];
				if (have) Object.assign(have, { name: ng.name, icon: ng.icon, members: ng.members });
				else S.groups[ng.id] = Object.assign(ng, { created: ev.created_at, lastTs: ev.created_at, lastRead: ev.created_at });
				break;
			}
			case 'gleave':
				if (g) { delete S.groups[g.id]; delete S.msgs[cid]; }
				break;
			case 'acc': { const f = S.friends[to]; if (f && f.state !== 'friend') { f.state = 'friend'; subscribeStatus(); } break; }
			case 'rm': if (S.friends[to]) { delete S.friends[to]; delete S.msgs[to]; subscribeStatus(); } break;
			default: return;
		}
		save();
		changed();
	}
	function syncSub(since) {
		if (!syncOn()) return;
		syncReady = false;
		subscribe('sync', [{ kinds: [APP], authors: [me], '#d': SYNC_SECTIONS.map(x => 'arce-sync:' + x) }], ev => { onSyncEvent(ev); }, () => {
			// Pull first, then start sending this device's changes (so a new device doesn't overwrite your other one).
			const s2 = subs.get('sync');
			if (!syncReady && s2 && s2.eose.size >= Math.max(1, openRelays())) { syncReady = true; setTimeout(syncLocal, 800); }
		});
		setTimeout(() => { if (!syncReady) { syncReady = true; syncLocal(); } }, 8000);
		subscribe('dmout', [{ kinds: [DM], authors: [me], since: since || now() - 7 * 86400, limit: 1000 }], onMyDM);
	}
	function startSync(since) {
		syncSub(since);
		clearInterval(syncTimer);
		syncTimer = setInterval(() => syncLocal(), 30000);
	}
	async function linkDevice({ code }) {
		code = String(code || '').trim();
		let hex = '';
		if (/^nsec1/.test(code)) { const d = NT.nip19.decode(code); if (d.type !== 'nsec') throw new Error("That isn't a link code."); hex = NT.bytesToHex(d.data); }
		else if (isHex64(code.toLowerCase())) hex = code.toLowerCase();
		else throw new Error("That isn't a link code. It starts with “nsec1”.");
		if (S.sk === hex) return { ok: true, same: true };
		// This device becomes the same account: friends, groups and settings come down from your other device.
		clearTimeout(saveT);
		const fresh = { v: 1, sk: hex, name: '', avatar: S.avatar || cleanAvatar({}), friends: {}, msgs: {}, groups: {}, sync: { on: true, sec: {} }, relays: S.relays };
		native('save', { data: JSON.stringify(fresh) });
		setTimeout(() => location.reload(), 400);
		return { ok: true };
	}

	/* ---------------- Arce account: sign in on any device with a username and password ----------------
	   Your account key is encrypted with your password (scrypt + AES-GCM) and stored on the relays under your
	   username. Only someone with the password can unlock it. */

	const enc = s => new TextEncoder().encode(s);
	const normUser = u => String(u || '').trim().toLowerCase().replace(/^@/, '');
	const acctTag = u => 'arce-account:' + NT.bytesToHex(NT.sha256(enc('arce-account|' + u)));
	const acctKey = (user, pass, salt) => NT.scryptAsync(enc(pass), new Uint8Array([...salt, ...enc(user)]), { N: 2 ** 16, r: 8, p: 1, dkLen: 32 });
	function ensureRelays() { if (!relays.length) relays = (S.relays && S.relays.length ? S.relays : DEFAULT_RELAYS).map(u => new Relay(u)); }
	async function waitRelays(ms = 6000) { const t = Date.now(); while (!openRelays() && Date.now() - t < ms) await new Promise(r => setTimeout(r, 200)); return openRelays() > 0; }
	async function findAccount(user) {
		ensureRelays();
		if (!(await waitRelays())) throw new Error("Can't reach the Arce network. Check your internet and try again.");
		const found = new Map(), id = 'acct-' + rid();
		await new Promise(res => {
			const done = () => { clearTimeout(t); res(); };
			const t = setTimeout(done, 5000);
			subscribe(id, [{ kinds: [APP], '#d': [acctTag(user)], limit: 20 }], ev => { const p = found.get(ev.pubkey); if (!p || p.created_at < ev.created_at) found.set(ev.pubkey, ev); }, () => { const s = subs.get(id); if (s && s.eose.size >= Math.max(1, openRelays())) setTimeout(done, 300); });
		});
		unsubscribe(id);
		return [...found.values()];
	}
	async function saveAccount(user, password) {
		const salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12));
		const key = await acctKey(user, password, salt);
		const c = NT.gcm(key, iv).encrypt(NT.hexToBytes(S.sk));
		const content = JSON.stringify({ v: 1, n: 16, s: bytesToB64(salt), i: bytesToB64(iv), c: bytesToB64(c) });
		return publish({ kind: APP, created_at: now(), tags: [['d', acctTag(user)]], content });
	}
	const checkPassword = p => String(p || '').length >= 10 ? '' : 'Use a password with at least 10 characters.';
	async function accountCreate({ username, password }) {
		const user = normUser(username);
		if (!/^[a-z0-9_.]{3,20}$/.test(user)) return { error: 'Usernames are 3–20 letters, numbers, dots or underscores.' };
		const bad = checkPassword(password);
		if (bad) return { error: bad };
		if (!S.sk) {
			S.sk = NT.bytesToHex(NT.generateSecretKey());
			S.name = S.name || clean(username);
			save();
			start(S.relays);
		}
		const others = (await findAccount(user)).filter(ev => ev.pubkey !== me);
		if (others.length) return { error: 'That username is taken. Try another one.' };
		if (!(await saveAccount(user, password))) return { error: "Couldn't save your account. Try again in a moment." };
		S.account = { user, since: now() };
		S.sync = S.sync || { sec: {} };
		S.sync.on = true;
		save();
		syncSub();
		setTimeout(() => syncLocal(true), 1000);
		changed();
		return { ok: true, user };
	}
	async function accountSignIn({ username, password }) {
		const user = normUser(username);
		if (!user || !password) return { error: 'Enter your username and password.' };
		const list = await findAccount(user);
		for (const ev of list) {
			let d;
			try { d = JSON.parse(ev.content); } catch (e) { continue; }
			try {
				const key = await acctKey(user, String(password), b64ToBytes(d.s));
				const skb = NT.gcm(key, b64ToBytes(d.i)).decrypt(b64ToBytes(d.c));
				if (NT.getPublicKey(skb) !== ev.pubkey) continue;
				const hex = NT.bytesToHex(skb);
				if (S.sk === hex) { S.account = { user, since: now() }; S.sync.on = true; save(); syncSub(); return { ok: true, same: true }; }
				clearTimeout(saveT);
				const fresh = { v: 1, sk: hex, name: '', avatar: cleanAvatar({}), friends: {}, msgs: {}, groups: {}, sync: { on: true, sec: {} }, account: { user, since: now() }, relays: S.relays };
				native('save', { data: JSON.stringify(fresh) });
				setTimeout(() => location.reload(), 400);
				return { ok: true };
			} catch (e) { /* wrong password for this one */ }
		}
		return { error: list.length ? 'Wrong username or password.' : "There's no Arce account with that username." };
	}

	/* ---------------- templates: share your Arce setup (theme, wallpaper, widgets) ---------------- */

	const TPL_LOOK = { theme: 's', accent: 's', accentCustom: 's', sharpCorners: 'b', uiFont: 's', glass: 'b', tabsTop: 'b', compactTabs: 'b', sidebarWidth: 'n', wallpaperDim: 'n', wallpaperBlur: 'n', wallpaperSidebar: 'b', animations: 'b', sfx: 'b' };
	function cleanTemplate(t, ev) {
		if (!t || typeof t !== 'object' || t.deleted || !/^[0-9a-f]{16}$/.test(t.id || '')) return null;
		const look = {};
		for (const [k, ty] of Object.entries(TPL_LOOK)) {
			const v = t.look && t.look[k];
			if (ty === 's' && typeof v === 'string' && v.length < 40) look[k] = v;
			if (ty === 'b' && typeof v === 'boolean') look[k] = v;
			if (ty === 'n' && typeof v === 'number' && isFinite(v)) look[k] = v;
		}
		const w = t.wallpaper || {};
		const wallpaper = w.kind === 'builtin' && /^[a-z]{2,20}$/.test(w.key || '') ? { kind: 'builtin', key: w.key } : (w.kind === 'image' || w.kind === 'video') && /^https:\/\/\S+$/.test(w.url || '') && /^[a-z0-9]{2,5}$/.test(w.ext || '') ? { kind: w.kind, url: w.url, ext: w.ext, size: Number(w.size) || 0 } : { kind: 'builtin', key: 'midnight' };
		let widgets = null;
		try { if (t.widgets && typeof t.widgets === 'object' && JSON.stringify(t.widgets).length < 12000) widgets = t.widgets; } catch (e) {}
		return { id: t.id, pubkey: ev.pubkey, name: clean(t.name, 40) || 'Untitled', desc: clean(t.desc, 140), author: clean(t.author) || 'Someone', created: ev.created_at, look, wallpaper, widgets, thumb: /^data:image\/(jpeg|webp);base64,/.test(t.thumb || '') && t.thumb.length < 45000 ? t.thumb : '', mine: ev.pubkey === me };
	}
	async function templateList() {
		ensureRelays();
		if (!(await waitRelays())) return { error: "Can't reach the Arce network right now." };
		const found = new Map(), reports = new Map(), id = 'tpl-' + rid(), rid2 = 'tplr-' + rid();
		const wait = (sid, filters, onEv) => new Promise(res => {
			const done = () => { clearTimeout(t); res(); };
			const t = setTimeout(done, 5000);
			subscribe(sid, filters, onEv, () => { const s = subs.get(sid); if (s && s.eose.size >= Math.max(1, openRelays())) setTimeout(done, 300); });
		});
		await Promise.all([
			wait(id, [{ kinds: [APP], '#t': ['arce-template'], limit: 300 }], ev => { const d = (ev.tags.find(x => x[0] === 'd') || [])[1] || ''; const key = ev.pubkey + d; const p = found.get(key); if (!p || p.created_at < ev.created_at) found.set(key, ev); }),
			wait(rid2, [{ kinds: [1984], '#t': ['arce-template-report'], limit: 1000 }], ev => { const a = (ev.tags.find(x => x[0] === 'a') || [])[1]; if (!a) return; const s = reports.get(a) || new Set(); s.add(ev.pubkey); reports.set(a, s); }),
		]);
		unsubscribe(id); unsubscribe(rid2);
		const out = [];
		for (const ev of found.values()) {
			let t;
			try { t = JSON.parse(ev.content); } catch (e) { continue; }
			const c = cleanTemplate(t, ev);
			if (!c) continue;
			const n = (reports.get(`${APP}:${ev.pubkey}:arce-template:${c.id}`) || new Set()).size;
			if (n >= 3 && !c.mine) continue; // hidden after several people report it
			c.reports = n;
			out.push(c);
		}
		return { templates: out.sort((a, b) => b.created - a.created).slice(0, 200) };
	}
	async function templatePublish({ template }) {
		if (!sk) return { error: 'Sign in to your Arce account (or set up Chat) to share templates.' };
		const t = cleanTemplate(Object.assign({}, template, { id: template && template.id || rid() }), { pubkey: me, created_at: now() });
		if (!t) return { error: 'Something is wrong with that template.' };
		const body = { v: 1, id: t.id, name: t.name, desc: t.desc, author: S.name || 'Someone', look: t.look, wallpaper: t.wallpaper, widgets: t.widgets, thumb: t.thumb };
		const ok = await publish({ kind: APP, created_at: now(), tags: [['d', 'arce-template:' + t.id], ['t', 'arce-template']], content: JSON.stringify(body) });
		return ok ? { ok: true, id: t.id } : { error: "Couldn't share it. Check your internet and try again." };
	}
	async function templateDelete({ id }) {
		if (!sk || !/^[0-9a-f]{16}$/.test(id || '')) return { error: 'gone' };
		await publish({ kind: APP, created_at: now(), tags: [['d', 'arce-template:' + id], ['t', 'arce-template']], content: JSON.stringify({ deleted: true }) });
		return { ok: true };
	}
	async function templateReport({ id, pubkey }) {
		if (!/^[0-9a-f]{16}$/.test(id || '') || !isHex64(pubkey || '')) return { error: 'bad' };
		ensureRelays();
		const key = sk || NT.generateSecretKey();
		const ev = NT.finalizeEvent({ kind: 1984, created_at: now(), tags: [['a', `${APP}:${pubkey}:arce-template:${id}`], ['p', pubkey, 'nudity'], ['t', 'arce-template-report']], content: 'Reported from Arce' }, key);
		for (const r of relays) r.send(['EVENT', ev]);
		return { ok: true };
	}

	/* ---------------- start ---------------- */

	function start(relayUrls) {
		sk = NT.hexToBytes(S.sk);
		me = NT.getPublicKey(sk);
		if (!relays.length) relays = (relayUrls && relayUrls.length ? relayUrls : DEFAULT_RELAYS).map(u => new Relay(u));
		const since = Math.min(now() - 7 * 86400, (S.lastOnline || now()) - 86400);
		subscribe('dm', [{ kinds: [DM], '#p': [me], since, limit: 1000 }], onDM);
		subscribe('typing', [{ kinds: [TYPING], '#p': [me], since: now() - 10 }], onTyping);
		subscribeStatus();
		startSync(since);
		setTimeout(() => { if (S.name) { publishPresence(true); publishUsername(); } }, 1200);
		clearInterval(presenceTimer);
		presenceTimer = setInterval(() => { publishPresence(true); S.lastOnline = now(); save(); changed(); }, 120000);
		changed();
	}

	function summary(f) {
		const list = S.msgs[f.pk] || [];
		const last = list[list.length - 1];
		const o = online[f.pk] || {};
		return { pk: f.pk, name: f.name, avatar: f.avatar, state: f.state, online: isOnline(f.pk), statusText: o.text || '', activity: isOnline(f.pk) ? o.activity || '' : '', lastTs: f.lastTs || f.added || 0, preview: last ? (last.from === 'me' ? 'You: ' : '') + preview(last) : '', unread: f.state === 'friend' ? unread(f.pk) : 0, typing: (typingUntil[f.pk] || 0) > Date.now() };
	}

	function groupSummary(g) {
		const cid = 'g:' + g.id, list = S.msgs[cid] || [], last = list[list.length - 1];
		const author = last ? (last.from === 'me' ? 'You: ' : last.by ? nameOf(last.by, g) + ': ' : '') : '';
		const typing = (typingUntil[cid] || 0) > Date.now();
		return { pk: cid, group: true, name: g.name, icon: g.icon, avatar: { c: parseInt(g.id.slice(0, 2), 16) % 12 }, state: 'friend', admin: g.admin === me, members: g.members.map(x => ({ pk: x.pk, name: nameOf(x.pk, g), avatar: (S.friends[x.pk] && S.friends[x.pk].avatar) || x.avatar, online: isOnline(x.pk) })), online: g.members.some(x => isOnline(x.pk)), lastTs: g.lastTs || g.created || 0, preview: last ? author + preview(last) : '', unread: unread(cid), typing, typingName: typing ? typingName[cid] || '' : '' };
	}

	async function search(q) {
		q = clean(q, 80);
		if (!q) return [];
		if (/^npub1/.test(q)) {
			try { const d = NT.nip19.decode(q); if (d.type === 'npub') return d.data === me ? [] : [{ pk: d.data, name: 'Arce user', avatar: cleanAvatar({}), byCode: true }]; } catch (e) { return []; }
		}
		if (isHex64(q.toLowerCase())) return q.toLowerCase() === me ? [] : [{ pk: q.toLowerCase(), name: 'Arce user', avatar: cleanAvatar({}), byCode: true }];
		const found = new Map();
		const id = 'search-' + rid();
		await new Promise(res => {
			const done = () => { clearTimeout(t); res(); };
			const t = setTimeout(done, 4500);
			subscribe(id, [{ kinds: [APP], '#d': ['arce-user:' + q.toLowerCase()], limit: 30 }], ev => {
				let d;
				try { d = JSON.parse(ev.content); } catch (e) { return; }
				const prev = found.get(ev.pubkey);
				if (ev.pubkey !== me && (!prev || prev.created < ev.created_at)) found.set(ev.pubkey, { pk: ev.pubkey, name: clean(d.name) || q, avatar: cleanAvatar(d.avatar), created: ev.created_at });
			}, () => { const s = subs.get(id); if (s && s.eose.size >= Math.max(1, openRelays())) setTimeout(done, 250); });
		});
		unsubscribe(id);
		return [...found.values()].sort((a, b) => b.created - a.created).map(r => Object.assign(r, { code: NT.nip19.npubEncode(r.pk).slice(0, 14) + '…', friend: !!S.friends[r.pk] }));
	}

	async function decryptFile(m) {
		const r = await native('download', { url: m.file.url });
		if (!r || r.error || !r.b64) throw new Error(r && r.error || 'download');
		return NT.gcm(b64ToBytes(m.file.key), b64ToBytes(m.file.iv)).decrypt(b64ToBytes(r.b64));
	}
	const findMsg = (pk, id) => (S.msgs[pk] || []).find(m => m.id === id);

	/* ---------------- commands from the app ---------------- */

	const C = {
		async state() {
			if (!sk) return { ready: false };
			const friends = friendList().map(summary).sort((a, b) => (b.online - a.online) || (b.lastTs - a.lastTs));
			const groups = Object.values(S.groups || {}).map(groupSummary).sort((a, b) => b.lastTs - a.lastTs);
			return { ready: true, me: { pk: me, code: NT.nip19.npubEncode(me), name: S.name, avatar: S.avatar, statusText: S.statusText || '', shareActivity: !!S.shareActivity }, relays: { open: openRelays(), total: relays.length }, friends, groups, unread: unreadTotal() };
		},
		async setup({ name, avatar }) {
			name = clean(name);
			if (name.length < 2) return { error: 'Pick a name with at least 2 letters.' };
			if (!S.sk) S.sk = NT.bytesToHex(NT.generateSecretKey());
			S.name = name;
			S.avatar = cleanAvatar(avatar);
			save();
			if (!sk) start(S.relays);
			return C.state();
		},
		async setProfile({ name, avatar, statusText, shareActivity }) {
			if (name !== undefined) { const n = clean(name); if (n.length < 2) return { error: 'Pick a name with at least 2 letters.' }; S.name = n; }
			if (avatar !== undefined) S.avatar = cleanAvatar(avatar);
			if (statusText !== undefined) S.statusText = clean(statusText, 80);
			if (shareActivity !== undefined) S.shareActivity = !!shareActivity;
			save();
			publishPresence(true);
			if (name !== undefined || avatar !== undefined) { publishUsername(); for (const f of friendList()) if (f.state === 'friend') sendDM(f.pk, Object.assign({ t: 'prof' }, myProfile())); }
			return C.state();
		},
		async search({ q }) { return { results: await search(q) }; },
		async addFriend({ pk, name, avatar }) {
			if (!isHex64(pk || '') || pk === me) return { error: "That isn't a valid friend code." };
			S.blocked = (S.blocked || []).filter(x => x !== pk);
			const f = S.friends[pk];
			if (f && f.state === 'friend') return { error: `${f.name} is already your friend.` };
			if (f && f.state === 'in') return C.accept({ pk });
			S.friends[pk] = { pk, name: clean(name) || 'Arce user', avatar: cleanAvatar(avatar), state: 'out', added: now(), lastTs: now() };
			save();
			const ok = await sendDM(pk, Object.assign({ t: 'req' }, myProfile()));
			changed();
			return { ok: true, sent: ok };
		},
		async accept({ pk }) {
			const f = S.friends[pk];
			if (!f) return { error: 'That request is gone.' };
			f.state = 'friend';
			f.lastTs = now();
			save();
			subscribeStatus();
			await sendDM(pk, Object.assign({ t: 'acc' }, myProfile()));
			changed();
			return { ok: true };
		},
		async decline({ pk }) {
			delete S.friends[pk];
			S.blocked = (S.blocked || []).concat(pk).slice(-500);
			save();
			changed();
			return { ok: true };
		},
		async remove({ pk }) {
			const f = S.friends[pk];
			delete S.friends[pk];
			delete S.msgs[pk];
			save();
			subscribeStatus();
			if (f) sendDM(pk, { t: 'rm' });
			changed();
			return { ok: true };
		},
		async messages({ pk }) {
			const f = recOf(pk);
			if (!f) return { error: 'gone' };
			const list = S.msgs[pk] || [];
			if (list.length) { const last = list[list.length - 1].ts; if ((f.lastRead || 0) < last) { f.lastRead = last; save(); changed(); } }
			const g = groupOf(pk);
			const names = {}, avatars = {};
			if (g) for (const m of list) if (m.by && !names[m.by]) { names[m.by] = nameOf(m.by, g); const fr = S.friends[m.by], mem = g.members.find(x => x.pk === m.by); avatars[m.by] = (fr && fr.state === 'friend' && fr.avatar) || (mem && mem.avatar) || { c: 0 }; }
			return { friend: g ? groupSummary(g) : summary(f), messages: list, names, avatars };
		},
		async markRead({ pk }) {
			const f = recOf(pk), list = S.msgs[pk] || [];
			if (f && list.length) { f.lastRead = list[list.length - 1].ts; save(); changed(); }
			return { ok: true };
		},
		async send({ pk, text, re }) {
			const f = recOf(pk);
			text = String(text || '').trim().slice(0, 4000);
			if (!canTalk(pk) || !text) return { error: 'not sent' };
			const m = { id: rid(), from: 'me', type: 'text', text, ts: now(), status: 'sending' };
			const target = re && findMsg(pk, re);
			if (target) m.re = { id: target.id, text: preview(target).slice(0, 140), name: target.from === 'me' ? S.name : target.by ? nameOf(target.by, groupOf(pk)) : (f.name || '') };
			addMsg(pk, m);
			f.lastRead = m.ts;
			changed();
			const ok = await sendTo(pk, payloadFor(m));
			m.status = ok ? 'sent' : 'failed';
			save();
			changed();
			return { ok, id: m.id };
		},
		async retry({ pk, id }) {
			const m = findMsg(pk, id);
			if (!m || m.status !== 'failed') return { ok: false };
			for (const r of relays) r.kick();
			if (m.type === 'file' && !m.file.url) {
				// The upload itself failed: ask the app to upload the file again.
				const r = await native('reupload', { id: m.id });
				if (r && r.error) { m.error = r.error; changed(); return { error: r.error }; }
				m.status = 'sending';
				delete m.error;
				save();
				changed();
				return { ok: true };
			}
			m.status = 'sending';
			changed();
			const ok = await sendTo(pk, payloadFor(m));
			m.status = ok ? 'sent' : 'failed';
			save();
			changed();
			return { ok };
		},
		async react({ pk, id, e }) {
			const m = findMsg(pk, id);
			e = clean(e, 8);
			if (!m || !e || !canTalk(pk)) return { error: 'gone' };
			m.reacts = m.reacts || {};
			const who = new Set(m.reacts[e] || []);
			const on = !who.has('me');
			if (on) who.add('me'); else who.delete('me');
			if (who.size) m.reacts[e] = [...who]; else delete m.reacts[e];
			save();
			changed();
			sendTo(pk, { t: 'react', id, e, on });
			return { ok: true, reacts: m.reacts };
		},
		async groupCreate({ name, members }) {
			const pks = [...new Set((members || []).filter(pk => S.friends[pk] && S.friends[pk].state === 'friend'))].slice(0, 30);
			if (!pks.length) return { error: 'Pick at least one friend.' };
			const g = { id: rid(), name: clean(name, 40) || pks.map(pk => S.friends[pk].name).slice(0, 3).join(', '), admin: me, icon: '', members: pks.map(pk => ({ pk, name: S.friends[pk].name, avatar: S.friends[pk].avatar })), created: now(), lastTs: now(), lastRead: now() };
			S.groups = S.groups || {};
			S.groups[g.id] = g;
			addMsg('g:' + g.id, { id: 'c' + g.id, from: 'sys', type: 'sys', text: `You made the group “${g.name}”`, ts: now() });
			save();
			changed();
			const wire = groupWire(g);
			await Promise.all(pks.map(pk => sendDM(pk, { t: 'ginv', g: wire })));
			return { ok: true, pk: 'g:' + g.id };
		},
		async groupUpdate({ pk, name, icon, add, removeMember }) {
			const g = groupOf(pk);
			if (!g) return { error: 'gone' };
			if (g.admin !== me) return { error: 'Only the person who made the group can change it.' };
			const before = g.members.map(x => x.pk);
			if (name !== undefined && clean(name, 40)) g.name = clean(name, 40);
			if (icon !== undefined && clean(icon, 8)) g.icon = clean(icon, 8);
			for (const a of add || []) { const f = S.friends[a]; if (f && f.state === 'friend' && !g.members.some(x => x.pk === a) && g.members.length < 30) g.members.push({ pk: a, name: f.name, avatar: f.avatar }); }
			if (removeMember) g.members = g.members.filter(x => x.pk !== removeMember);
			save();
			changed();
			const wire = groupWire(g);
			const told = new Set(before.concat(g.members.map(x => x.pk)));
			const gone = removeMember ? { ...wire, members: wire.members.filter(x => x.pk !== removeMember) } : wire;
			await Promise.all([...told].map(to => sendDM(to, { t: 'gupd', g: gone })));
			return { ok: true };
		},
		async groupLeave({ pk }) {
			const g = groupOf(pk);
			if (!g) return { ok: true };
			const to = g.members.map(x => x.pk);
			delete S.groups[g.id];
			delete S.msgs[pk];
			save();
			changed();
			await Promise.all(to.map(x => sendDM(x, { t: 'gleave', g: g.id })));
			return { ok: true };
		},
		// Files are encrypted and uploaded by the app (any size up to 1 GB, with progress); the engine just tracks the message.
		async fileStart({ pk, name, size, mime, thumb }) {
			const f = recOf(pk);
			if (!canTalk(pk)) return { error: 'not sent' };
			const m = { id: rid(), from: 'me', type: 'file', ts: now(), status: 'sending', file: { name: clean(name, 120) || 'file', size: Number(size) || 0, mime: clean(mime, 80) || 'application/octet-stream', thumb: /^data:image\/jpeg;base64,/.test(thumb || '') && thumb.length < 40000 ? thumb : '', enc: 'v2' } };
			addMsg(pk, m);
			f.lastRead = m.ts;
			changed();
			return { id: m.id };
		},
		async fileDone({ pk, id, url, k, iv }) {
			const m = findMsg(pk, id);
			if (!m || !/^https:\/\//.test(url || '')) return { error: 'gone' };
			Object.assign(m.file, { url, k, iv, enc: 'v2' });
			delete m.error;
			const ok = await sendTo(pk, payloadFor(m));
			m.status = ok ? 'sent' : 'failed';
			save();
			changed();
			return { ok };
		},
		async fileFail({ pk, id, error }) {
			const m = findMsg(pk, id);
			if (!m) return {};
			m.status = 'failed';
			m.error = clean(error, 120) || "Couldn't upload — tap to retry";
			save();
			changed();
			return {};
		},
		async fileInfo({ pk, id }) {
			const m = findMsg(pk, id);
			if (!m || m.type !== 'file') return { error: 'That file is gone.' };
			if (!m.file.url) return m.from === 'me' ? Object.assign({}, m.file, { local: true }) : { error: "This file didn't finish uploading." };
			return m.file;
		},
		async legacyBytes({ pk, id }) {
			// Files sent by Arce 1.9–1.10 (encrypted inside the chat engine).
			const m = findMsg(pk, id);
			if (!m || m.type !== 'file') return { error: 'gone' };
			try { return { b64: bytesToB64(await decryptFile(m)) }; } catch (e) { return { error: 'This file expired or can\'t be downloaded (files last 3 days).' }; }
		},
		async typing({ pk }) {
			if (!canTalk(pk) || Date.now() - (lastTypingSent[pk] || 0) < 3500) return {};
			lastTypingSent[pk] = Date.now();
			sendTo(pk, { t: 'typing' }, TYPING);
			return {};
		},
		async activity({ text }) {
			const t = clean(text, 60);
			if (t === activity) return {};
			activity = t;
			if (S && S.shareActivity) publishPresence(true);
			return {};
		},
		async wake() { for (const r of relays) r.kick(); publishPresence(true); scheduleRetry(); return {}; },
		async goodbye() { if (!sk) return {}; S.lastOnline = now(); native('save', { data: JSON.stringify(S) }); await Promise.race([publishPresence(false), new Promise(r => setTimeout(r, 1500))]); return {}; },
		async unread() { return { unread: unreadTotal() }; },
		async syncState() { return { on: !!(S.sync && S.sync.on), sections: Object.fromEntries(Object.entries((S.sync && S.sync.sec) || {}).map(([k, v]) => [k, v.ts])), devices: (S.sync && S.sync.on) ? 'linked' : '' }; },
		async syncSet({ on }) { S.sync = S.sync || { sec: {} }; S.sync.on = !!on; save(); if (on) { syncSub(); setTimeout(syncLocal, 500); } else unsubscribe('sync'), unsubscribe('dmout'); return C.syncState(); },
		async accountState() { return { user: (S.account && S.account.user) || '', sync: !!(S.sync && S.sync.on) }; },
		async accountPassword({ password }) {
			if (!S.account) return { error: 'No account on this device.' };
			const bad = checkPassword(password);
			if (bad) return { error: bad };
			return (await saveAccount(S.account.user, password)) ? { ok: true } : { error: "Couldn't save. Try again." };
		},
		async accountSignOut() {
			// Removes your account from this device only (your friends and chats stay on your other devices and in your account).
			clearTimeout(saveT);
			native('save', { data: JSON.stringify({ v: 1, relays: S.relays }) });
			setTimeout(() => location.reload(), 300);
			return { ok: true };
		},
		async syncNow() { if (syncOn()) await syncLocal(); return C.syncState(); },
		async linkCode() {
			S.sync = S.sync || { sec: {} };
			S.sync.on = true;
			save();
			syncSub();
			await syncLocal(true);
			return { code: NT.nip19.nsecEncode(sk) };
		},
	};

	window.Chat = {
		async cmd(op, args) {
			await ready;
			const TPL = { templateList, templatePublish, templateDelete, templateReport };
			if (TPL[op]) { try { return await TPL[op](args || {}); } catch (e) { return { error: String(e && e.message || e) }; } }
			if (op === 'accountCreate' || op === 'accountSignIn') { try { return await (op === 'accountCreate' ? accountCreate : accountSignIn)(args || {}); } catch (e) { return { error: String(e && e.message || e) }; } }
			if (op === 'link') { try { return await linkDevice(args || {}); } catch (e) { return { error: String(e && e.message || e) }; } }
			if (!C[op]) return { error: 'unknown ' + op };
			if (!sk && !['state', 'setup'].includes(op)) return { error: 'Set up chat first.' };
			try { return await C[op](args || {}); } catch (e) { console.error(e); return { error: String(e && e.message || e) }; }
		},
	};

	const ready = (async () => {
		let r = {};
		try { r = (await native('load')) || {}; } catch (e) {}
		try { S = r.data ? JSON.parse(r.data) : null; } catch (e) { S = null; }
		if (!S || typeof S !== 'object') S = {};
		S.v = 1;
		S.friends = S.friends || {};
		S.msgs = S.msgs || {};
		S.groups = S.groups || {};
		S.sync = S.sync || { on: false, sec: {} };
		S.sync.sec = S.sync.sec || {};
		S.avatar = cleanAvatar(S.avatar);
		S.relays = r.relays || null;
		if (S.sk && isHex64(S.sk)) start(r.relays); else changed();
	})();
	setInterval(() => { if (sk) changed(); }, 60000);
	window.addEventListener('online', () => { for (const r of relays) r.kick(); });
})();
