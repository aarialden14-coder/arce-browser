// Floats the page's main video (the playing one first, then the biggest), or brings it back.
// mode: 'toggle' | 'enter' | 'exit'. Answers 'on', 'off', 'none' or 'error'.
(async mode => {
	const docs = [document];
	for (const f of document.querySelectorAll('iframe')) { try { if (f.contentDocument) docs.push(f.contentDocument); } catch (e) {} }
	const vids = docs.flatMap(d => [...d.querySelectorAll('video')]);
	const floating = docs.find(d => d.pictureInPictureElement) || vids.find(v => v.webkitPresentationMode === 'picture-in-picture');
	if (floating) {
		if (mode === 'enter') return 'on';
		if (floating.exitPictureInPicture) await floating.exitPictureInPicture().catch(() => {});
		else floating.webkitSetPresentationMode('inline');
		return 'off';
	}
	if (mode === 'exit') return 'off';
	const ready = vids.filter(v => v.readyState > 0 || v.currentSrc);
	if (!ready.length) return 'none';
	const score = v => (v.paused ? 0 : 1e9) + v.clientWidth * v.clientHeight;
	const v = ready.sort((a, b) => score(b) - score(a))[0];
	if (mode === 'enter' && (v.paused || v.ended)) return 'off';
	v.removeAttribute('disablepictureinpicture');
	try { v.disablePictureInPicture = false; } catch (e) {}
	try {
		if (v.requestPictureInPicture) { await v.requestPictureInPicture(); return 'on'; }
	} catch (e) {}
	if (v.webkitSetPresentationMode) { v.webkitSetPresentationMode('picture-in-picture'); return 'on'; }
	return 'error';
})
