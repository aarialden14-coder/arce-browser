// Arce page translation: swaps the page's text for a translation in place, and back.
(() => {
	const cfg = window.__arceTrCfg || {};
	if (window.__arceTr) { window.__arceTr.run(cfg); return; }

	const SKIP = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'CODE', 'PRE', 'KBD', 'SAMP', 'VAR', 'TEXTAREA', 'INPUT', 'SELECT', 'OPTION', 'SVG', 'MATH', 'TEMPLATE', 'IFRAME', 'CANVAS', 'ARCE-READER', 'ARCE-TRANSLATE']);
	const BATCH_ITEMS = 50, BATCH_CHARS = 3500, MAX_INFLIGHT = 3;
	const post = m => { try { webkit.messageHandlers.arcePage.postMessage(m); } catch (e) {} };

	const T = window.__arceTr = { on: false, to: '', from: '', seq: 0 };
	const info = new Map();        // text node -> { orig, lead, trail, tr: { [lang]: text } }
	const queue = [], inflight = new Map();
	let applying = false, failed = false, pill = null, pillRoot = null, hidden = false, observer = null, rescanTimer = null;

	function langName(code) {
		try { return new Intl.DisplayNames([navigator.language || 'en'], { type: 'language' }).of(code) || code; } catch (e) { return code; }
	}

	function skipNode(el) {
		for (let p = el; p && p !== document.documentElement; p = p.parentElement) {
			if (SKIP.has(p.tagName.toUpperCase())) return true;
			if (p.isContentEditable) return true;
			if (p.getAttribute && (p.getAttribute('translate') === 'no' || (p.classList && p.classList.contains('notranslate')))) return true;
		}
		return false;
	}

	// Find text that still needs translating.
	function collect(root) {
		const found = [];
		if (!root) return found;
		const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
			acceptNode(n) {
				const v = n.nodeValue;
				if (!v || v.trim().length < 2 || !/\p{L}/u.test(v)) return NodeFilter.FILTER_REJECT;
				return skipNode(n.parentElement) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT;
			},
		});
		for (let n = walker.nextNode(); n; n = walker.nextNode()) {
			let d = info.get(n);
			if (d && (n.nodeValue === d.orig || n.nodeValue === d.tr[T.to])) {
				if (d.tr[T.to] !== undefined) { if (n.nodeValue !== d.tr[T.to]) set(n, d.lead + d.tr[T.to] + d.trail); continue; }
				if (d.waiting) continue;
			} else {
				// New text, or the site changed it since.
				const v = n.nodeValue, m = v.match(/^(\s*)([\s\S]*?)(\s*)$/);
				d = { orig: v, lead: m[1], core: m[2], trail: m[3], tr: {} };
				info.set(n, d);
			}
			d.waiting = true;
			found.push(n);
		}
		return found;
	}

	function set(n, v) { applying = true; n.nodeValue = v; applying = false; }

	function enqueue(nodes) {
		let batch = [], chars = 0;
		const flush = () => { if (batch.length) queue.push({ nodes: batch, to: T.to }); batch = []; chars = 0; };
		for (const n of nodes) {
			const c = info.get(n).core;
			if (batch.length >= BATCH_ITEMS || chars + c.length > BATCH_CHARS) flush();
			batch.push(n);
			chars += c.length;
		}
		flush();
		pump();
	}

	function pump() {
		while (inflight.size < MAX_INFLIGHT && queue.length) {
			const job = queue.shift();
			if (job.to !== T.to || !T.on) { job.nodes.forEach(n => { const d = info.get(n); if (d) d.waiting = false; }); continue; }
			const id = ++T.seq;
			inflight.set(id, job);
			post({ type: 'trReq', id, to: job.to, texts: job.nodes.map(n => info.get(n).core.slice(0, 5000)) });
		}
		updatePill();
	}

	T.done = (id, results, from, error) => {
		const job = inflight.get(id);
		if (!job) return;
		inflight.delete(id);
		if (error || !Array.isArray(results) || results.length !== job.nodes.length) {
			job.nodes.forEach(n => { const d = info.get(n); if (d) d.waiting = false; });
			failed = true;
			queue.length = 0;
			updatePill();
			return;
		}
		if (from && !T.from) T.from = String(from).toLowerCase();
		job.nodes.forEach((n, i) => {
			const d = info.get(n);
			if (!d) return;
			d.waiting = false;
			if (typeof results[i] !== 'string') return;
			d.tr[job.to] = results[i];
			if (T.on && job.to === T.to && n.isConnected && n.nodeValue === d.orig) set(n, d.lead + results[i] + d.trail);
		});
		pump();
	};

	function translate(to) {
		T.to = to;
		T.on = true;
		failed = false;
		hidden = false;
		enqueue(collect(document.body));
		watch();
		post({ type: 'trState', on: true });
		updatePill();
	}

	function original() {
		T.on = false;
		queue.length = 0;
		for (const [n, d] of info) if (n.isConnected && n.nodeValue !== d.orig) set(n, d.orig);
		post({ type: 'trState', on: false });
		updatePill();
	}

	function watch() {
		if (observer) return;
		observer = new MutationObserver(muts => {
			if (applying || !T.on) return;
			if (muts.every(m => m.target === pill || (pill && pill.contains(m.target)))) return;
			clearTimeout(rescanTimer);
			rescanTimer = setTimeout(() => { if (T.on && !failed) enqueue(collect(document.body)); }, 500);
		});
		observer.observe(document.body, { childList: true, subtree: true, characterData: true });
	}

	// Small bar in the corner: what happened, and a way back.
	function updatePill() {
		if (!pill) {
			pill = document.createElement('arce-translate');
			pillRoot = pill.attachShadow({ mode: 'closed' });
			pillRoot.addEventListener('click', e => {
				const b = e.target.closest('button');
				if (!b) return;
				if (b.dataset.a === 'orig') original();
				else if (b.dataset.a === 'tr' || b.dataset.a === 'retry') translate(T.to);
				else if (b.dataset.a === 'hide') { hidden = true; updatePill(); }
			});
			document.documentElement.appendChild(pill);
		}
		if (hidden) { pillRoot.innerHTML = ''; return; }
		const busy = T.on && (inflight.size || queue.length);
		const to = langName(T.to), from = T.from && T.from !== 'auto' ? langName(T.from) : '';
		let text, btn;
		if (failed) { text = "Couldn't translate this page. Check your connection."; btn = '<button data-a="retry">Try again</button>'; }
		else if (!T.on) { text = 'Showing the original'; btn = `<button data-a="tr">Translate to ${to}</button>`; }
		else if (busy) { text = `Translating to ${to}…`; btn = '<button data-a="orig">Show original</button>'; }
		else { text = from ? `Translated from ${from}` : `Translated to ${to}`; btn = '<button data-a="orig">Show original</button>'; }
		pillRoot.innerHTML = `<style>
:host { all: initial; }
.p { position: fixed; right: 16px; bottom: 16px; z-index: 2147483646; display: flex; align-items: center; gap: 4px; padding: 5px 5px 5px 14px; border-radius: 12px; background: rgba(22,22,26,.94); color: #ececf0; font: 500 13px system-ui, -apple-system, "Segoe UI", sans-serif; box-shadow: 0 8px 30px rgba(0,0,0,.35), inset 0 0 0 1px rgba(255,255,255,.08); backdrop-filter: blur(12px); animation: in .18s ease; }
@keyframes in { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: none; } }
.t { margin-right: 6px; white-space: nowrap; }
.spin { width: 11px; height: 11px; border-radius: 50%; border: 2px solid rgba(255,255,255,.2); border-top-color: #fff; animation: s .7s linear infinite; margin-right: 4px; }
@keyframes s { to { transform: rotate(360deg); } }
button { all: unset; cursor: pointer; height: 28px; padding: 0 10px; border-radius: 8px; display: inline-flex; align-items: center; font: inherit; color: #fff; background: rgba(255,255,255,.1); }
button:hover { background: rgba(255,255,255,.17); }
button.x { padding: 0; width: 28px; justify-content: center; background: none; color: #9a9aa3; }
button.x:hover { background: rgba(255,255,255,.1); color: #fff; }
</style><div class="p">${busy ? '<span class="spin"></span>' : ''}<span class="t">${text}</span>${btn}<button class="x" data-a="hide" title="Hide"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div>`;
	}

	T.run = c => {
		const to = c.to || T.to || 'en';
		if (c.action === 'original' || (c.action !== 'translate' && T.on && to === T.to)) original();
		else translate(to);
	};
	T.run(cfg);
})();
