// A short message at the bottom of the page (used when the sidebar is too narrow for it).
(text => {
	const old = document.querySelector('arce-toast');
	if (old) old.remove();
	const h = document.createElement('arce-toast');
	const r = h.attachShadow({ mode: 'closed' });
	r.innerHTML = '<style>:host{all:initial}.t{position:fixed;left:50%;bottom:22px;transform:translateX(-50%);z-index:2147483647;max-width:min(460px,80vw);padding:9px 15px;border-radius:10px;background:rgba(24,24,28,.95);color:#ececf0;font:500 13px system-ui,-apple-system,"Segoe UI",sans-serif;box-shadow:0 10px 30px rgba(0,0,0,.4),inset 0 0 0 1px rgba(255,255,255,.08);pointer-events:none;animation:i .18s ease}@keyframes i{from{opacity:0;transform:translate(-50%,8px)}}</style><div class="t"></div>';
	r.querySelector('.t').textContent = text;
	document.documentElement.appendChild(h);
	setTimeout(() => h.remove(), 2400);
})
