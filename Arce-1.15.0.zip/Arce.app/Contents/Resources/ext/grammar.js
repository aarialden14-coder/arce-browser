// Arce Grammar — Grammarly-style spelling, grammar, punctuation and word-choice checks on every site.
// Underlines problems as you type; click one (or the badge) to fix it.
(() => {
	if (window.__arceGrammar) return;
	window.__arceGrammar = true;
	if (/^docs\.google\.com$/.test(location.hostname)) return; // Google Docs draws text on a canvas; it has its own checker

	const ask = msg => { try { return window.webkit.messageHandlers.arceWrite.postMessage(msg); } catch (e) { return Promise.resolve(null); } };
	const COLORS = { spelling: '#ff4d5e', grammar: '#ffb020', style: '#5b9dff' };
	const kindOf = m => m.type === 'misspelling' ? 'spelling' : (m.type === 'style' || m.type === 'locale-violation' || m.cat === 'STYLE' || m.cat === 'REDUNDANCY' || m.cat === 'PLAIN_ENGLISH' || m.cat === 'TYPOGRAPHY') ? 'style' : 'grammar';
	const LABEL = { spelling: 'Spelling', grammar: 'Grammar', style: 'Clarity' };
	const ignored = new Set();

	let field = null, matches = [], lastText = '', timer = null, checking = false, map = null, rafPending = false;

	/* ---------- which fields ---------- */
	function editableRoot(t) {
		if (!t || t.nodeType !== 1) return null;
		if (t.tagName === 'TEXTAREA') return t;
		if (t.tagName === 'INPUT') return ['text', ''].includes(t.type) ? t : null;
		if (!t.isContentEditable) return null;
		let r = t;
		while (r.parentElement && r.parentElement.isContentEditable) r = r.parentElement;
		return r;
	}
	function allowed(el) {
		if (!el) return false;
		if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
			if (el.readOnly || el.disabled || el.spellcheck === false) return false;
			if (/cc-|one-time|user|email|pass|search|url|tel/.test(el.autocomplete || '') || /search|code|url|email|user|login/i.test(el.name + ' ' + el.id)) return false;
			if (el.tagName === 'INPUT' && el.offsetWidth < 260) return false;
			return true;
		}
		if (el.closest('.monaco-editor, .cm-editor, .CodeMirror, .ace_editor, [data-gramm="false"], [data-arce-write="off"]')) return false;
		const sc = el.closest('[spellcheck]');
		return !(sc && sc.getAttribute('spellcheck') === 'false');
	}

	/* ---------- text <-> DOM ---------- */
	const BLOCK = /^(DIV|P|LI|H[1-6]|BLOCKQUOTE|PRE|TR|SECTION|ARTICLE|UL|OL)$/;
	function readText(el) {
		if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') return { text: el.value, segs: null };
		const segs = [];
		let text = '';
		const walk = n => {
			if (n.nodeType === 3) { if (n.textContent) { segs.push({ node: n, start: text.length }); text += n.textContent; } return; }
			if (n.nodeType !== 1) return;
			if (n !== el && n.getAttribute('contenteditable') === 'false') { text += ' '; return; } // mentions, emoji, embeds
			if (n.tagName === 'BR') { text += '\n'; return; }
			const block = BLOCK.test(n.tagName) && n !== el;
			if (block && text && !text.endsWith('\n')) text += '\n';
			for (const c of n.childNodes) walk(c);
			if (block && text && !text.endsWith('\n')) text += '\n';
		};
		walk(el);
		return { text, segs };
	}
	function domPoint(segs, off) {
		for (let i = segs.length - 1; i >= 0; i--) {
			const s = segs[i];
			if (off >= s.start) return { node: s.node, offset: Math.min(off - s.start, s.node.textContent.length) };
		}
		return null;
	}
	function rangeFor(m) {
		if (!map || !map.segs) return null;
		const a = domPoint(map.segs, m.offset), b = domPoint(map.segs, m.offset + m.length);
		if (!a || !b) return null;
		const r = document.createRange();
		try { r.setStart(a.node, a.offset); r.setEnd(b.node, b.offset); } catch (e) { return null; }
		return r;
	}
	let mirror = null;
	function fieldRects(el, m) {
		// Measure where characters sit inside a textarea/input with an invisible copy of it.
		if (!mirror) { mirror = document.createElement('div'); mirror.setAttribute('aria-hidden', 'true'); }
		const cs = getComputedStyle(el);
		const props = ['boxSizing', 'width', 'height', 'paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft', 'borderTopWidth', 'borderRightWidth', 'borderBottomWidth', 'borderLeftWidth', 'fontFamily', 'fontSize', 'fontWeight', 'fontStyle', 'letterSpacing', 'lineHeight', 'textTransform', 'wordSpacing', 'textIndent', 'tabSize'];
		const st = mirror.style;
		st.cssText = 'position:fixed;visibility:hidden;overflow:hidden;top:0;left:-9999px;border-style:solid;border-color:transparent;';
		for (const p of props) st[p] = cs[p];
		st.whiteSpace = el.tagName === 'INPUT' ? 'pre' : 'pre-wrap';
		st.wordWrap = 'break-word';
		mirror.textContent = '';
		const v = el.value;
		mirror.appendChild(document.createTextNode(v.slice(0, m.offset)));
		const span = document.createElement('span');
		span.textContent = v.slice(m.offset, m.offset + m.length) || '​';
		mirror.appendChild(span);
		mirror.appendChild(document.createTextNode(v.slice(m.offset + m.length) || '.'));
		document.documentElement.appendChild(mirror);
		const box = el.getBoundingClientRect(), mb = mirror.getBoundingClientRect();
		const rects = [...span.getClientRects()].map(r => ({ left: box.left + (r.left - mb.left) - el.scrollLeft, top: box.top + (r.top - mb.top) - el.scrollTop, width: r.width, height: r.height }));
		mirror.remove();
		return rects.filter(r => r.top + r.height > box.top && r.top < box.bottom && r.left < box.right && r.left + r.width > box.left);
	}
	function rectsFor(m) {
		if (field.tagName === 'TEXTAREA' || field.tagName === 'INPUT') return fieldRects(field, m);
		const r = rangeFor(m);
		if (!r) return [];
		const box = field.getBoundingClientRect();
		return [...r.getClientRects()].filter(x => x.width > 0 && x.top + x.height > box.top - 2 && x.top < box.bottom + 2);
	}

	/* ---------- overlay UI (in a shadow root so sites can't restyle it) ---------- */
	const host = document.createElement('arce-write');
	host.style.cssText = 'all:initial;position:fixed;left:0;top:0;width:0;height:0;z-index:2147483646;';
	const root = host.attachShadow({ mode: 'closed' });
	root.innerHTML = `<style>
		.u { position: absolute; height: 2px; border-radius: 2px; pointer-events: none; opacity: .9; }
		.badge { position: absolute; height: 22px; min-width: 22px; padding: 0 6px; border-radius: 11px; display: flex; align-items: center; justify-content: center; gap: 4px; font: 600 11.5px/1 -apple-system, "Segoe UI", system-ui, sans-serif; color: #fff; background: #3ecf8e; box-shadow: 0 2px 8px rgba(0,0,0,.35); cursor: pointer; user-select: none; transition: transform .15s; }
		.badge:hover { transform: scale(1.08); }
		.badge.bad { background: #ff4d5e; } .badge.style { background: #5b9dff; } .badge.wait { background: #5f5f6a; }
		.card { position: absolute; width: 300px; background: #1b1b21; color: #ececf1; border: 1px solid rgba(255,255,255,.1); border-radius: 12px; padding: 12px; font: 13px/1.45 -apple-system, "Segoe UI", system-ui, sans-serif; box-shadow: 0 14px 44px rgba(0,0,0,.55); animation: in .14s ease-out; max-height: 360px; overflow: auto; }
		@keyframes in { from { opacity: 0; transform: translateY(4px); } }
		.k { font-size: 11px; font-weight: 700; letter-spacing: .4px; text-transform: uppercase; display: flex; align-items: center; gap: 6px; }
		.k i { width: 8px; height: 8px; border-radius: 4px; display: inline-block; }
		.msg { color: #a9a9b5; margin: 6px 0 10px; }
		.reps { display: flex; flex-wrap: wrap; gap: 6px; }
		button { font: inherit; border: 0; border-radius: 8px; padding: 6px 10px; cursor: pointer; }
		.rep { background: #3ecf8e; color: #0b0b0e; font-weight: 600; }
		.rep.del { background: #ff4d5e; color: #fff; }
		.ghost { background: transparent; color: #8f8f9b; padding: 6px 6px; }
		.ghost:hover { color: #ececf1; }
		.row { display: flex; justify-content: space-between; align-items: center; margin-top: 10px; }
		.item { padding: 9px 0; border-top: 1px solid rgba(255,255,255,.07); cursor: pointer; }
		.item:first-of-type { border-top: 0; }
		.item b { font-weight: 600; } .item s { color: #8f8f9b; }
		.head { display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px; font-weight: 700; }
		.fixall { background: #3ecf8e; color: #0b0b0e; font-weight: 600; }
		.ok { color: #a9a9b5; padding: 4px 0; }
	</style><div id="lines"></div><div id="badge" class="badge" style="display:none"></div><div id="pop"></div>`;
	const $ = id => root.getElementById(id);
	const attach = () => { if (!host.isConnected) (document.body || document.documentElement).appendChild(host); };
	const esc = s => String(s).replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

	function anchorHost() {
		// If the page has a filter (like Dark Everything), fixed elements are placed relative to the page, so cancel that out.
		const de = document.documentElement;
		if (getComputedStyle(de).filter !== 'none' || getComputedStyle(de).transform !== 'none') { const r = de.getBoundingClientRect(); host.style.left = -r.left + 'px'; host.style.top = -r.top + 'px'; }
		else if (host.style.left !== '0px') { host.style.left = '0px'; host.style.top = '0px'; }
	}
	function paint() {
		rafPending = false;
		anchorHost();
		const lines = $('lines');
		if (!field || !field.isConnected) { lines.innerHTML = ''; $('badge').style.display = 'none'; return; }
		attach();
		let h = '';
		for (const m of matches) {
			for (const r of rectsFor(m)) h += `<div class="u" style="left:${r.left}px;top:${r.top + r.height - 1}px;width:${r.width}px;background:${COLORS[kindOf(m)]}"></div>`;
		}
		lines.innerHTML = h;
		const box = field.getBoundingClientRect();
		const b = $('badge');
		if (box.width < 120 || box.height < 14 || box.bottom < 0 || box.top > innerHeight) { b.style.display = 'none'; return; }
		b.style.display = 'flex';
		b.style.left = Math.min(innerWidth - 30, box.right - 30) + 'px';
		b.style.top = Math.min(innerHeight - 28, box.bottom - 28) + 'px';
		const n = matches.length;
		b.className = 'badge' + (checking && !n ? ' wait' : n ? (matches.every(m => kindOf(m) === 'style') ? ' style' : ' bad') : '');
		b.textContent = checking && !n ? '…' : n ? String(n) : '✓';
		b.title = n ? `${n} suggestion${n === 1 ? '' : 's'} — click to review` : 'Arce Grammar: looks good';
	}
	const schedulePaint = () => { if (!rafPending) { rafPending = true; requestAnimationFrame(paint); } };

	function closePop() { $('pop').innerHTML = ''; }
	function place(card, x, y) {
		const w = 300;
		card.style.left = Math.max(8, Math.min(innerWidth - w - 8, x)) + 'px';
		const h = card.offsetHeight || 160;
		card.style.top = (y + h + 8 > innerHeight ? Math.max(8, y - h - 30) : y + 6) + 'px';
	}
	function showMatch(m, at) {
		const k = kindOf(m);
		const word = currentText().slice(m.offset, m.offset + m.length);
		const reps = (m.reps || []).slice(0, 4);
		$('pop').innerHTML = `<div class="card"><div class="k" style="color:${COLORS[k]}"><i style="background:${COLORS[k]}"></i>${esc(m.short || LABEL[k])}</div><div class="msg">${esc(m.message)}</div>
			<div class="reps">${reps.map((r, i) => `<button class="rep ${r === '' ? 'del' : ''}" data-i="${i}">${r === '' ? 'Remove' : esc(r)}</button>`).join('') || '<span class="ok">No suggestion.</span>'}</div>
			<div class="row"><button class="ghost" id="ign">Ignore</button>${k === 'spelling' ? '<button class="ghost" id="dict">Add to dictionary</button>' : ''}</div></div>`;
		const card = root.querySelector('.card');
		place(card, at.left, at.bottom);
		card.addEventListener('mousedown', e => e.preventDefault());
		card.querySelectorAll('[data-i]').forEach(b => b.onclick = () => { apply(m, reps[+b.dataset.i]); closePop(); });
		$('ign').onclick = () => { ignored.add(word.toLowerCase() + '|' + m.rule); matches = matches.filter(x => x !== m); closePop(); schedulePaint(); };
		if ($('dict')) $('dict').onclick = () => { ask({ cmd: 'addWord', word }); ignored.add(word.toLowerCase() + '|*'); matches = matches.filter(x => currentText().slice(x.offset, x.offset + x.length).toLowerCase() !== word.toLowerCase()); closePop(); schedulePaint(); };
	}
	function showAll() {
		const b = $('badge').getBoundingClientRect();
		const text = currentText();
		const n = matches.length;
		$('pop').innerHTML = `<div class="card"><div class="head"><span>${n ? `${n} suggestion${n === 1 ? '' : 's'}` : 'All good ✓'}</span>${matches.some(m => m.reps && m.reps.length) ? '<button class="fixall" id="fa">Fix all</button>' : ''}</div>
			${n ? matches.map((m, i) => `<div class="item" data-m="${i}"><div class="k" style="color:${COLORS[kindOf(m)]}"><i style="background:${COLORS[kindOf(m)]}"></i>${esc(LABEL[kindOf(m)])}</div><div><s>${esc(text.slice(m.offset, m.offset + m.length) || '·')}</s>${m.reps && m.reps.length ? ` → <b>${esc(m.reps[0] || '(remove)')}</b>` : ''}</div><div class="msg" style="margin:2px 0 0">${esc(m.message)}</div></div>`).join('') : '<div class="ok">No spelling, grammar or punctuation problems found.</div>'}</div>`;
		const card = root.querySelector('.card');
		card.addEventListener('mousedown', e => e.preventDefault());
		place(card, b.right - 300, b.bottom);
		if (b.bottom + card.offsetHeight > innerHeight) card.style.top = Math.max(8, b.top - card.offsetHeight - 8) + 'px';
		if ($('fa')) $('fa').onclick = () => { fixAll(); closePop(); };
		card.querySelectorAll('[data-m]').forEach(el => el.onclick = () => { const m = matches[+el.dataset.m]; if (m.reps && m.reps.length) apply(m, m.reps[0]); closePop(); });
	}

	/* ---------- editing ---------- */
	const currentText = () => field ? readText(field).text : '';
	function selectMatch(m) {
		field.focus();
		if (field.tagName === 'TEXTAREA' || field.tagName === 'INPUT') { field.setSelectionRange(m.offset, m.offset + m.length); return true; }
		map = readText(field);
		const r = rangeFor(m);
		if (!r) return false;
		const sel = getSelection();
		sel.removeAllRanges();
		sel.addRange(r);
		return true;
	}
	function typeInto(rep) {
		// Editors that keep their own copy of the text (Discord, Notion…) listen for typing events; others take insertText.
		const sel = getSelection();
		const target = (sel.anchorNode && sel.anchorNode.nodeType === 3 ? sel.anchorNode.parentElement : sel.anchorNode) || field;
		const ev = new InputEvent('beforeinput', { inputType: rep === '' ? 'deleteContentBackward' : 'insertText', data: rep === '' ? null : rep, bubbles: true, cancelable: true, composed: true });
		if (!target.dispatchEvent(ev)) return true;
		return rep === '' ? document.execCommand('delete') : document.execCommand('insertText', false, rep);
	}
	async function apply(m, rep) {
		if (!field || rep === undefined) return;
		const text = currentText();
		if (text.slice(m.offset, m.offset + m.length) !== m.orig) { check(true); return; }
		if (!selectMatch(m)) return;
		const plain = field.tagName === 'TEXTAREA' || field.tagName === 'INPUT';
		if (!plain) await new Promise(r => setTimeout(r, 0)); // let the editor notice the new selection first
		const ok = plain ? (rep === '' ? document.execCommand('delete') : document.execCommand('insertText', false, rep)) : typeInto(rep);
		if (!ok && (field.tagName === 'TEXTAREA' || field.tagName === 'INPUT')) {
			const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(field), 'value').set;
			setter.call(field, text.slice(0, m.offset) + rep + text.slice(m.offset + m.length));
			field.dispatchEvent(new Event('input', { bubbles: true }));
		}
		const delta = rep.length - m.length;
		matches = matches.filter(x => x !== m).map(x => x.offset > m.offset ? Object.assign({}, x, { offset: x.offset + delta }) : x);
		lastText = currentText();
		map = readText(field);
		schedulePaint();
		clearTimeout(timer);
		timer = setTimeout(() => check(false), 1200);
	}
	async function fixAll() {
		const list = matches.filter(m => m.reps && m.reps.length).sort((a, b) => b.offset - a.offset);
		for (const m of list) { await apply(m, m.reps[0]); await new Promise(r => setTimeout(r, 30)); }
	}

	/* ---------- checking ---------- */
	async function check(force) {
		if (!field || !field.isConnected) return;
		map = readText(field);
		const text = map.text;
		if (!force && text === lastText) return;
		lastText = text;
		if (text.trim().split(/\s+/).length < 2 || text.length > 12000) { matches = []; schedulePaint(); return; }
		checking = true;
		schedulePaint();
		const res = await ask({ cmd: 'check', text, style: text.length > 140 });
		checking = false;
		if (!field || currentText() !== text) { schedulePaint(); return; }
		if (!res || res.error) { matches = []; schedulePaint(); return; }
		matches = (res.matches || []).map(m => Object.assign(m, { orig: text.slice(m.offset, m.offset + m.length) })).filter(m => {
			const w = m.orig.toLowerCase();
			if (ignored.has(w + '|' + m.rule) || ignored.has(w + '|*')) return false;
			if (/^[@#:]|^https?:|[\/\\]/.test(m.orig)) return false; // mentions, emoji codes, links
			if (m.type === 'misspelling' && /^[A-Z0-9]{2,}$/.test(m.orig)) return false; // GG, FPS, LOL
			return true;
		});
		schedulePaint();
	}

	document.addEventListener('focusin', e => {
		const el = editableRoot(e.target);
		if (el === field) return;
		if (!el || !allowed(el)) { if (field && !host.contains(e.target)) { field = null; matches = []; watcher.disconnect(); closePop(); schedulePaint(); } return; }
		field = el;
		matches = [];
		lastText = '';
		closePop();
		watcher.disconnect();
		if (el.isContentEditable) watcher.observe(el, { characterData: true, childList: true, subtree: true });
		check(false);
	}, true);
	// Editors like Discord's never fire 'input', so also watch the text itself.
	const watcher = new MutationObserver(() => onEdit());
	document.addEventListener('input', e => {
		if (!field || !(e.target === field || field.contains(e.target))) return;
		onEdit();
	}, true);
	function onEdit() {
		if (!field) return;
		const now = currentText();
		if (now === lastText) return;
		// Drop underlines that the edit touched right away; recheck after a short pause.
		const text = now;
		if (matches.length) {
			let i = 0;
			while (i < text.length && i < lastText.length && text[i] === lastText[i]) i++;
			const delta = text.length - lastText.length;
			matches = matches.filter(m => m.offset + m.length < i || m.offset >= i - delta).map(m => m.offset >= i ? Object.assign({}, m, { offset: m.offset + delta }) : m).filter(m => text.slice(m.offset, m.offset + m.length) === m.orig);
		}
		lastText = text;
		map = readText(field);
		schedulePaint();
		clearTimeout(timer);
		timer = setTimeout(() => { lastText = ''; check(false); }, 1400);
	}
	const caretOffset = () => {
		if (field.tagName === 'TEXTAREA' || field.tagName === 'INPUT') return field.selectionStart;
		const sel = getSelection();
		if (!sel.rangeCount || !map || !map.segs) return -1;
		const seg = map.segs.find(s => s.node === sel.focusNode);
		return seg ? seg.start + sel.focusOffset : -1;
	};
	document.addEventListener('click', e => {
		if (host.contains(e.target) || e.composedPath().includes(host)) return;
		if (!field || !(e.target === field || field.contains(e.target))) { closePop(); return; }
		setTimeout(() => {
			const off = caretOffset();
			const m = matches.find(x => off >= x.offset && off <= x.offset + x.length);
			if (!m) { closePop(); return; }
			const r = rectsFor(m)[0];
			if (r) showMatch(m, { left: r.left, bottom: r.top + r.height });
		}, 0);
	}, true);
	$('badge').addEventListener('mousedown', e => { e.preventDefault(); e.stopPropagation(); if (root.querySelector('.card .head')) closePop(); else showAll(); });
	document.addEventListener('keydown', e => { if (e.key === 'Escape') closePop(); }, true);
	addEventListener('scroll', schedulePaint, true);
	addEventListener('resize', schedulePaint);
	setInterval(() => { if (field) schedulePaint(); }, 1000);
})();
