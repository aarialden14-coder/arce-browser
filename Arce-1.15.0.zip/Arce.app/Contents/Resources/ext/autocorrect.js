// Arce Autocorrect — fixes common typos the moment you finish a word, on every site.
// Backspace right after a fix puts your word back (and Arce won't touch it again).
(() => {
	if (window.__arceAutocorrect) return;
	window.__arceAutocorrect = true;
	if (/^docs\.google\.com$/.test(location.hostname) && /^\/(document|spreadsheets|presentation)\//.test(location.pathname)) return;

	const FIX = {
		// contractions
		dont: "don't", cant: "can't", wont: "won't", isnt: "isn't", doesnt: "doesn't", didnt: "didn't", wasnt: "wasn't", werent: "weren't", havent: "haven't", hasnt: "hasn't", hadnt: "hadn't",
		couldnt: "couldn't", shouldnt: "shouldn't", wouldnt: "wouldn't", mustnt: "mustn't", arent: "aren't", aint: "ain't", im: "I'm", ive: "I've", youre: "you're", youve: "you've", youll: "you'll",
		theyre: "they're", theyve: "they've", theyll: "they'll", thats: "that's", whats: "what's", wheres: "where's", whos: "who's", hows: "how's", heres: "here's", theres: "there's", shes: "she's",
		weve: "we've", wouldve: "would've", couldve: "could've", shouldve: "should've", mightve: "might've", lets: null, its: null, well: null, ill: null, id: null, hed: null, were: null, shell: null,
		// typos
		teh: 'the', hte: 'the', tje: 'the', thw: 'the', adn: 'and', nad: 'and', anf: 'and', taht: 'that', tath: 'that', thta: 'that', thier: 'their', tehir: 'their', wiht: 'with', wtih: 'with', whit: null,
		waht: 'what', whta: 'what', wnat: 'want', wnats: 'wants', jsut: 'just', juts: 'just', knwo: 'know', konw: 'know', kwno: 'know', liek: 'like', msot: 'most', mroe: 'more', nto: 'not', yuo: 'you', yoru: 'your',
		peopel: 'people', poeple: 'people', pepole: 'people', sitll: 'still', soem: 'some', somthing: 'something', somehting: 'something', soemthing: 'something', thign: 'thing', thigns: 'things', thnig: 'thing',
		tihs: 'this', thsi: 'this', htis: 'this', tehy: 'they', theyr: "they're", woudl: 'would', coudl: 'could', shoudl: 'should', sohuld: 'should', ahve: 'have', hvae: 'have', becuase: 'because', becasue: 'because',
		beacuse: 'because', becaus: 'because', beacause: 'because', bc: null, aslo: 'also', alos: 'also', abotu: 'about', baout: 'about', agian: 'again', agin: 'again', allready: 'already', alredy: 'already',
		alwasy: 'always', alwyas: 'always', amke: 'make', mkae: 'make', anohter: 'another', anwser: 'answer', asnwer: 'answer', awsome: 'awesome', awsom: 'awesome', befroe: 'before', cna: 'can', coem: 'come',
		diffrent: 'different', differnt: 'different', dosent: "doesn't", dosnt: "doesn't", eveyr: 'every', evrey: 'every', everthing: 'everything', everyting: 'everything', evrything: 'everything', exapmle: 'example',
		frmo: 'from', fomr: 'from', goign: 'going', giong: 'going', gonig: 'going', hepl: 'help', hwo: 'how', iwll: 'I will', lenght: 'length', mabye: 'maybe', maybee: 'maybe', nevr: 'never', nwo: 'now', onyl: 'only',
		otehr: 'other', ohter: 'other', problme: 'problem', porblem: 'problem', qucik: 'quick', rigth: 'right', rihgt: 'right', saem: 'same', tahnks: 'thanks', thansk: 'thanks', thnaks: 'thanks', thnx: null,
		tehre: 'there', togehter: 'together', tonihgt: 'tonight', tryign: 'trying', wehn: 'when', whcih: 'which', whihc: 'which', wich: 'which', wrok: 'work', yaer: 'year', yera: 'year', realy: 'really', relaly: 'really',
		recieve: 'receive', recieved: 'received', reciept: 'receipt', beleive: 'believe', belive: 'believe', definately: 'definitely', definatly: 'definitely', defintely: 'definitely', definetly: 'definitely',
		seperate: 'separate', seperately: 'separately', occured: 'occurred', occuring: 'occurring', untill: 'until', alot: 'a lot', tommorow: 'tomorrow', tomorow: 'tomorrow', tommorrow: 'tomorrow', wierd: 'weird',
		freind: 'friend', freinds: 'friends', frist: 'first', truely: 'truly', goverment: 'government', enviroment: 'environment', accross: 'across', arguement: 'argument', begining: 'beginning', calender: 'calendar',
		commited: 'committed', concious: 'conscious', existance: 'existence', foriegn: 'foreign', happend: 'happened', immediatly: 'immediately', independant: 'independent', knowlege: 'knowledge',
		neccessary: 'necessary', necesary: 'necessary', noticable: 'noticeable', occassion: 'occasion', posession: 'possession', prefered: 'preferred', publically: 'publicly', recomend: 'recommend', reccomend: 'recommend',
		refered: 'referred', relevent: 'relevant', remeber: 'remember', rember: 'remember', similiar: 'similar', succesful: 'successful', sucessful: 'successful', suprise: 'surprise', suprised: 'surprised',
		writting: 'writing', acheive: 'achieve', accomodate: 'accommodate', adress: 'address', agressive: 'aggressive', apparantly: 'apparently', basicly: 'basically', buisness: 'business', comming: 'coming',
		completly: 'completely', dissapoint: 'disappoint', dissapointed: 'disappointed', embarass: 'embarrass', embarassing: 'embarrassing', excercise: 'exercise', finaly: 'finally', fourty: 'forty', grammer: 'grammar',
		interupt: 'interrupt', lisence: 'license', mispell: 'misspell', naturaly: 'naturally', oppurtunity: 'opportunity', peice: 'piece', persistant: 'persistent', posible: 'possible', probaly: 'probably', probally: 'probably',
		pronounciation: 'pronunciation', sincerly: 'sincerely', speach: 'speech', strenght: 'strength', usualy: 'usually', useing: 'using', visable: 'visible', wether: null, whereever: 'wherever', youself: 'yourself',
		yourslef: 'yourself', myslef: 'myself', ofcourse: 'of course', infront: 'in front', aswell: 'as well', eachother: 'each other', nobady: 'nobody', everyome: 'everyone', evryone: 'everyone', everone: 'everyone',
		thougth: 'thought', thoguht: 'thought', throught: 'through', thru: null, gaem: 'game', gmae: 'game', gmaes: 'games', palyer: 'player', palying: 'playing', plaing: 'playing', pratice: 'practice', practise: null,
		minecarft: 'Minecraft', fortnight: null, robolx: 'Roblox', rbolox: 'Roblox', youtbue: 'YouTube', yotube: 'YouTube', discrod: 'Discord', dicsord: 'Discord', twtich: 'Twitch',
	};
	const BOUNDARY = new Set([' ', '.', ',', '!', '?', ';', ':', ')', ' ']);
	const ignored = new Set();
	let last = null, busy = false;

	const editableOk = el => {
		if (!el) return false;
		if (el.tagName === 'TEXTAREA') return !el.readOnly && el.spellcheck !== false;
		if (el.tagName === 'INPUT') return !el.readOnly && ['text', ''].includes(el.type) && !/off|cc-|one-time|user|email|pass/.test(el.autocomplete || '') && el.spellcheck !== false;
		if (!el.isContentEditable) return false;
		if (el.closest('.monaco-editor, .cm-editor, .CodeMirror, .ace_editor, [data-gramm="false"], [data-arce-write="off"]')) return false;
		const sc = el.closest('[spellcheck]');
		return !(sc && sc.getAttribute('spellcheck') === 'false');
	};
	const caseLike = (word, fix) => {
		if (/^[A-Z]/.test(fix)) return fix; // proper names and "I"
		if (word === word.toUpperCase() && word.length > 1) return fix.toUpperCase();
		if (/^[A-Z]/.test(word)) return fix[0].toUpperCase() + fix.slice(1);
		return fix;
	};
	const fixFor = word => {
		if (word === 'i') return 'I';
		const low = word.toLowerCase();
		if (ignored.has(low)) return null;
		if (/^i'(m|ll|ve|d)$/.test(word)) return 'I' + word.slice(1);
		const f = FIX[low];
		return f ? caseLike(word, f) : null;
	};

	// Editors that keep their own copy of the text (Discord, Lexical…) cancel normal typing; they get typing events instead.
	const managed = el => el.isContentEditable && !!el.closest('[data-slate-editor], [data-lexical-editor]');
	function synth(target, inputType, data) {
		target.dispatchEvent(new InputEvent('beforeinput', { inputType, data, bubbles: true, cancelable: true, composed: true }));
	}
	function retype(el, len, text) {
		// Delete `len` characters before the caret, then type `text` — all as events the editor handles itself.
		const sel = getSelection();
		const target = (sel.anchorNode && sel.anchorNode.nodeType === 3 ? sel.anchorNode.parentElement : sel.anchorNode) || el;
		for (let i = 0; i < len; i++) synth(target, 'deleteContentBackward', null);
		synth(target, 'insertText', text);
		return true;
	}
	function replaceBefore(el, len, text) {
		// Replace the last `len` characters before the caret with `text` (plain fields and normal rich editors).
		if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
			const end = el.selectionStart;
			el.setSelectionRange(end - len, end);
			if (!document.execCommand('insertText', false, text)) {
				const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value').set;
				const v = el.value;
				setter.call(el, v.slice(0, end - len) + text + v.slice(end));
				el.setSelectionRange(end - len + text.length, end - len + text.length);
				el.dispatchEvent(new Event('input', { bubbles: true }));
			}
			return true;
		}
		if (managed(el)) return retype(el, len, text);
		const sel = getSelection();
		if (!sel.rangeCount || !sel.isCollapsed) return false;
		const node = sel.focusNode, off = sel.focusOffset;
		if (!node || node.nodeType !== 3 || off < len) return false;
		const r = document.createRange();
		r.setStart(node, off - len);
		r.setEnd(node, off);
		sel.removeAllRanges();
		sel.addRange(r);
		return document.execCommand('insertText', false, text);
	}
	function textBeforeCaret(el) {
		if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
			if (el.selectionStart !== el.selectionEnd) return null;
			return el.value.slice(Math.max(0, el.selectionStart - 60), el.selectionStart);
		}
		const sel = getSelection();
		if (!sel.rangeCount || !sel.isCollapsed || !sel.focusNode || sel.focusNode.nodeType !== 3) return null;
		return sel.focusNode.textContent.slice(Math.max(0, sel.focusOffset - 60), sel.focusOffset);
	}

	// Fix the word right after the space/punctuation lands. Plain fields and Gmail update before 'input';
	// editors like Discord's handle typing themselves, so for them we also look on the next frames.
	let pending = null;
	function tryFix() {
		const p = pending;
		if (!p) return true;
		const before = textBeforeCaret(p.el);
		const sp = c => c === '\u00a0' ? ' ' : c;
		if (!before || sp(before[before.length - 1]) !== sp(p.ch)) return false;
		pending = null;
		const word = wordBefore(before.slice(0, -1));
		if (!word) return true;
		const fix = fixFor(word);
		if (!fix || fix === word) return true;
		busy = true;
		const ok = replaceBefore(p.el, word.length + 1, fix + p.ch);
		busy = false;
		if (ok) last = { el: p.el, word, fix: fix + p.ch, at: Date.now() };
		return true;
	}
	const rootOf = t => t && t.isContentEditable ? (t.closest('[contenteditable=""], [contenteditable="true"], [contenteditable="plaintext-only"]') || t) : t;
	const wordBefore = text => { const m = text.match(/(^|[^\p{L}\p{N}'@#:_\/.-])([\p{L}']{1,24})$/u); return m ? m[2] : null; };
	document.addEventListener('beforeinput', e => {
		if (busy || !e.isTrusted || e.inputType !== 'insertText' || !e.data || e.data.length !== 1 || !BOUNDARY.has(e.data)) return;
		const el = rootOf(e.target);
		if (!editableOk(el)) return;
		if (managed(el)) {
			// Fix now, before the space lands: swap the word and type the space ourselves.
			const before = textBeforeCaret(el);
			const word = before && wordBefore(before);
			const fix = word && fixFor(word);
			if (!fix || fix === word) return;
			e.preventDefault();
			e.stopImmediatePropagation();
			busy = true;
			retype(el, word.length, fix + e.data);
			busy = false;
			last = { el, word, fix: fix + e.data, at: Date.now() };
			return;
		}
		pending = { el, ch: e.data };
		let tries = 0;
		const later = () => { if (pending && pending.el === el && !tryFix() && ++tries < 4) requestAnimationFrame(later); };
		requestAnimationFrame(later);
	}, true);
	document.addEventListener('input', e => {
		if (busy || !pending || e.inputType !== 'insertText') return;
		if (rootOf(e.target) === pending.el) tryFix();
	}, true);

	document.addEventListener('keydown', e => {
		if (e.key !== 'Backspace' || !last || e.metaKey || e.ctrlKey || e.altKey) { if (e.key !== 'Shift') last = null; return; }
		const l = last;
		last = null;
		if (Date.now() - l.at > 8000 || document.activeElement !== l.el && !l.el.contains(document.activeElement)) return;
		const before = textBeforeCaret(l.el);
		if (!before || before.replace(/\u00a0/g, ' ').slice(-l.fix.length) !== l.fix.replace(/\u00a0/g, ' ')) return;
		e.preventDefault();
		ignored.add(l.word.toLowerCase());
		busy = true;
		replaceBefore(l.el, l.fix.length, l.word);
		busy = false;
	}, true);
})();
