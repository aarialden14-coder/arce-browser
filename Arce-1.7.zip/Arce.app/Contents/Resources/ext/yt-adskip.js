// 1) Remove ads from YouTube's own data before the player ever sees them.
const AD_KEYS = ['adPlacements', 'adSlots', 'playerAds', 'adBreakHeartbeatParams', 'adBreakParams'];
const strip = o => {
	if (!o || typeof o !== 'object') return o;
	for (const k of AD_KEYS) if (k in o) { try { delete o[k]; } catch (e) {} }
	if (o.playerResponse && typeof o.playerResponse === 'object') strip(o.playerResponse);
	if (o.response && typeof o.response === 'object') strip(o.response);
	return o;
};
const hasAds = o => o && typeof o === 'object' && (AD_KEYS.some(k => k in o) || (o.playerResponse && AD_KEYS.some(k => k in o.playerResponse)));
const nativeParse = JSON.parse;
JSON.parse = function () {
	const r = nativeParse.apply(this, arguments);
	try { if (hasAds(r)) strip(r); else if (Array.isArray(r)) r.forEach(x => { if (hasAds(x)) strip(x); }); } catch (e) {}
	return r;
};
try { JSON.parse.toString = () => nativeParse.toString(); } catch (e) {}
const nativeJson = Response.prototype.json;
Response.prototype.json = function () {
	return nativeJson.apply(this, arguments).then(r => { try { if (hasAds(r)) strip(r); else if (Array.isArray(r)) r.forEach(x => { if (hasAds(x)) strip(x); }); } catch (e) {} return r; });
};
for (const name of ['ytInitialPlayerResponse', 'playerResponse']) {
	let value = window[name];
	try {
		Object.defineProperty(window, name, { configurable: true, get: () => value, set: v => { value = hasAds(v) ? strip(v) : v; } });
		if (value) strip(value);
	} catch (e) {}
}

const add = css => { const s = document.createElement('style'); s.textContent = css; (document.head || document.documentElement).appendChild(s); };
add('ytd-ad-slot-renderer, ytd-in-feed-ad-layout-renderer, ytd-promoted-sparkles-web-renderer, ytd-display-ad-renderer, ytd-companion-slot-renderer, ytd-action-companion-ad-renderer, ytd-banner-promo-renderer, ytd-statement-banner-renderer, ytd-promoted-video-renderer, ytd-player-legacy-desktop-watch-ads-renderer, ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-ads"], #player-ads, #masthead-ad, ytd-merch-shelf-renderer, .ytp-ad-overlay-container, .ytp-ad-message-container, .ytp-featured-product { display: none !important; }');
add('.ad-showing video, .ad-interrupting video { opacity: 0 !important; } .ad-showing .ytp-ad-player-overlay, .ad-showing .ytp-ad-player-overlay-layout, .ad-showing .ytp-ad-text, .ad-showing .ytp-ad-preview-container { opacity: 0 !important; } .ad-showing::after { content: "Skipping ad…"; position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; color: #fff; font: 600 15px -apple-system, Roboto, sans-serif; background: #000; z-index: 40; pointer-events: none; }');
add('ytd-rich-item-renderer:has(ytd-ad-slot-renderer), ytd-rich-section-renderer:has(ytd-statement-banner-renderer) { display: none !important; }');

add('ytd-enforcement-message-view-model, tp-yt-paper-dialog:has(ytd-enforcement-message-view-model) { display: none !important; }');

// If YouTube shows its "ad blockers aren't allowed" box, close it and keep the video going.
const unblock = () => {
	const box = document.querySelector('ytd-enforcement-message-view-model');
	if (!box) return;
	const dialog = box.closest('tp-yt-paper-dialog');
	if (dialog) dialog.remove();
	document.querySelectorAll('tp-yt-iron-overlay-backdrop').forEach(b => b.remove());
	const v = document.querySelector('#movie_player video');
	if (v && v.paused) v.play().catch(() => {});
};

let saved = null;
setInterval(() => {
	const player = document.querySelector('#movie_player, .html5-video-player');
	const video = player && player.querySelector('video');
	if (!video) return;
	const ad = player.classList.contains('ad-showing') || player.classList.contains('ad-interrupting');
	if (ad) {
		const skip = player.querySelector('.ytp-skip-ad-button, .ytp-ad-skip-button, .ytp-ad-skip-button-modern, .ytp-ad-skip-button-slot button, .videoAdUiSkipButton');
		if (skip) skip.click();
		if (!saved) saved = { muted: video.muted, rate: video.playbackRate === 16 ? 1 : video.playbackRate };
		// Fast-forward and mute instead of seeking, so the real video (sometimes stitched into the same stream) is never skipped.
		video.muted = true;
		video.playbackRate = 16;
	} else if (saved) {
		video.muted = saved.muted;
		video.playbackRate = saved.rate;
		saved = null;
	}
	unblock();
}, 200);
