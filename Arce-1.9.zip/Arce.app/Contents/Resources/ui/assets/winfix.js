// Arce for Windows: swap Mac shortcut symbols and wording for Windows ones.
(() => {
	if (window.arcePlatform !== 'win') return;
	const special = [['⌃⌘S', 'Ctrl+Shift+B'], ['⇧⌥⌘G', 'Ctrl+Shift+G'], ['⌥⌘G', 'Ctrl+Shift+G'], ['⌥⌘J', 'Ctrl+J'], ['⌘[', 'Alt+←'], ['⌘]', 'Alt+→'], ['⌘Y', 'Ctrl+H']];
	const words = [[/Show in Finder/g, 'Show in Folder'], [/in Finder/g, 'in File Explorer'], [/on this Mac/g, 'on this PC'], [/on your Mac/g, 'on your PC'], [/your Mac/g, 'your PC'], [/saved in your Keychain/g, 'saved encrypted on this PC'], [/macOS will ask you to confirm/g, 'Pick Arce under Web browser in Windows Settings'], [/Menu bar/g, 'Tray']];
	const fix = s => {
		if (!s || !/[⌘⌥⇧⌃]|Finder|Mac|Keychain|macOS|Menu bar/.test(s)) return s;
		for (const [a, b] of special) s = s.split(a).join(b);
		s = s.replace(/⇧⌘/g, 'Ctrl+Shift+').replace(/⌥⌘/g, 'Ctrl+Alt+').replace(/⌘/g, 'Ctrl+').replace(/⌥/g, 'Alt+').replace(/⇧/g, 'Shift+').replace(/⌃/g, 'Ctrl+');
		for (const [a, b] of words) s = s.replace(a, b);
		return s;
	};
	const walk = root => {
		if (root.nodeType === 3) { const v = fix(root.nodeValue); if (v !== root.nodeValue) root.nodeValue = v; return; }
		if (root.nodeType !== 1) return;
		for (const attr of ['title', 'placeholder', 'aria-label', 'data-tip']) { const v = root.getAttribute(attr); if (v) { const f = fix(v); if (f !== v) root.setAttribute(attr, f); } }
		for (const c of root.childNodes) walk(c);
	};
	const start = () => {
		walk(document.body);
		new MutationObserver(list => { for (const m of list) { if (m.type === 'attributes') walk(m.target); else if (m.type === 'characterData') walk(m.target); else m.addedNodes.forEach(walk); } }).observe(document.body, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ['title', 'placeholder'] });
	};
	if (document.body) start(); else document.addEventListener('DOMContentLoaded', start);
})();
