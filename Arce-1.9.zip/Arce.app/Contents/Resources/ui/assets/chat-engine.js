// Arce Chat engine — runs in a hidden page. Friends, end-to-end encrypted messages and files over public Nostr relays.
(() => {
	const native = (cmd, args = {}) => window.webkit.messageHandlers.chatd.postMessage({ cmd, args });
	const NT = window.NT;
	const now = () => Math.floor(Date.now() / 1000);
	const rid = () => NT.bytesToHex(crypto.getRandomValues(new Uint8Array(8)));
	const DEFAULT_RELAYS = ['wss://relay.damus.io', 'wss://nos.lol', 'wss://relay.primal.net', 'wss://nostr.mom', 'wss://relay.nostr.net'];
	const DM = 4, TYPING = 20004, APP = 30078;
	const MAX_FILE = 25e6, MAX_MSGS = 400;

	let S = null, sk = null, me = '', relays = [];
	const subs = new Map(), okWaits = new Map(), convKeys = {}, online = {}, typingUntil = {}, imgCache = new Map();
	let activity = '', presenceTimer = null, lastTypingSent = {};

	/* ---------------- helpers ---------------- */

	const clean = (s, n = 24) => String(s || '').replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, n);
	const cleanAvatar = a => ({ e: clean(a && a.e, 8) || '😎', c: Math.max(0, Math.min(11, parseInt(a && a.c) || 0)) });
	const b64ToBytes = b64 => { const s = atob(b64); const out = new Uint8Array(s.length); for (let i = 0; i < s.length; i++) out[i] = s.charCodeAt(i); return out; };
	const bytesToB64 = bytes => { let s = ''; for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000)); return btoa(s); };
	const convKey = pk => convKeys[pk] || (convKeys[pk] = NT.nip44.getConversationKey(sk, pk));
	const isHex64 = s => /^[0-9a-f]{64}$/.test(s);

	let saveT = null;
	const save = () => { clearTimeout(saveT); saveT = setTimeout(() => native('save', { data: JSON.stringify(S) }), 500); };
	let emitT = null;
	const changed = () => { clearTimeout(emitT); emitT = setTimeout(() => native('event', { unread: unreadTotal(), ready: !!sk }), 120); };

	function remember(id) {
		if (!S.seen) S.seen = [];
		S.seen.push(id);
		if (S.seen.length > 3000) S.seen.splice(0, S.seen.length - 3000);
	}

	/* ---------------- relays ---------------- */

	class Relay {
		constructor(url) { this.url = url; this.ws = null; this.open = false; this.queue = []; this.backoff = 1500; this.connect(); }
		connect() {
			try { this.ws = new WebSocket(this.url); } catch (e) { this.retry(); return; }
			this.ws.onopen = () => {
				this.open = true;
				this.backoff = 1500;
				for (const [id, s] of subs) this.raw(['REQ', id, ...s.filters]);
				for (const m of this.queue.splice(0)) this.raw(m);
				changed();
			};
			this.ws.onclose = () => { this.open = false; this.retry(); changed(); };
			this.ws.onerror = () => {};
			this.ws.onmessage = e => { let m; try { m = JSON.parse(e.data); } catch (err) { return; } onRelayMessage(this, m); };
		}
		retry() { clearTimeout(this.rt); this.rt = setTimeout(() => this.connect(), this.backoff); this.backoff = Math.min(this.backoff * 2, 60000); }
		raw(m) { try { this.ws.send(JSON.stringify(m)); } catch (e) {} }
		send(m) { if (this.open && this.ws && this.ws.readyState === 1) this.raw(m); else if (m[0] === 'EVENT') { this.queue.push(m); if (this.queue.length > 200) this.queue.shift(); } }
		kick() { if (!this.open) { clearTimeout(this.rt); this.backoff = 1500; try { this.ws && this.ws.close(); } catch (e) {} this.connect(); } }
	}

	function onRelayMessage(relay, m) {
		if (m[0] === 'EVENT') {
			const s = subs.get(m[1]), ev = m[2];
			if (!s || !ev || typeof ev.id !== 'string' || s.seen.has(ev.id)) return;
			if (!NT.verifyEvent(ev)) return;
			s.seen.add(ev.id);
			if (s.seen.size > 5000) s.seen.clear();
			try { s.onEvent(ev); } catch (e) { console.warn(e); }
		} else if (m[0] === 'EOSE') {
			const s = subs.get(m[1]);
			if (s) { s.eose.add(relay.url); if (s.onEose) s.onEose(); }
		} else if (m[0] === 'OK') {
			const w = okWaits.get(m[1]);
			if (w && m[2]) { okWaits.delete(m[1]); w(true); }
		}
	}

	function subscribe(id, filters, onEvent, onEose) {
		subs.set(id, { filters, onEvent, onEose, seen: new Set(), eose: new Set() });
		for (const r of relays) if (r.open) r.raw(['REQ', id, ...filters]);
	}
	function unsubscribe(id) {
		if (!subs.has(id)) return;
		subs.delete(id);
		for (const r of relays) if (r.open) r.raw(['CLOSE', id]);
	}
	function publish(template) {
		const ev = NT.finalizeEvent(template, sk);
		return new Promise(res => {
			const t = setTimeout(() => { okWaits.delete(ev.id); res(false); }, 8000);
			okWaits.set(ev.id, ok => { clearTimeout(t); res(ok); });
			for (const r of relays) r.send(['EVENT', ev]);
		});
	}
	const openRelays = () => relays.filter(r => r.open).length;

	/* ---------------- profile & presence ---------------- */

	const myProfile = () => ({ name: S.name, avatar: S.avatar });
	function sendDM(pk, payload, kind = DM) {
		const content = NT.nip44.encrypt(JSON.stringify(payload), convKey(pk));
		return publish({ kind, created_at: now(), tags: [['p', pk]], content });
	}
	function publishPresence(isOnline = true) {
		if (!sk) return Promise.resolve(false);
		const body = { name: S.name, avatar: S.avatar, text: S.statusText || '', activity: S.shareActivity && isOnline ? activity : '', online: isOnline, ts: now() };
		return publish({ kind: APP, created_at: now(), tags: [['d', 'arce-status']], content: JSON.stringify(body) });
	}
	function publishUsername() {
		if (!sk || !S.name) return;
		publish({ kind: APP, created_at: now(), tags: [['d', 'arce-user:' + S.name.toLowerCase()], ['t', 'arce']], content: JSON.stringify(myProfile()) });
	}

	function friendList() { return Object.values(S.friends); }
	function subscribeStatus() {
		const pks = friendList().filter(f => f.state === 'friend').map(f => f.pk);
		unsubscribe('status');
		if (!pks.length) return;
		subscribe('status', [{ kinds: [APP], authors: pks, '#d': ['arce-status'] }], ev => {
			let d;
			try { d = JSON.parse(ev.content); } catch (e) { return; }
			const prev = online[ev.pubkey];
			if (prev && prev.created > ev.created_at) return;
			online[ev.pubkey] = { created: ev.created_at, ts: Number(d.ts) || ev.created_at, online: d.online !== false, text: clean(d.text, 80), activity: clean(d.activity, 60) };
			const f = S.friends[ev.pubkey];
			if (f) { if (d.name) f.name = clean(d.name); if (d.avatar) f.avatar = cleanAvatar(d.avatar); save(); }
			changed();
		});
	}
	const isOnline = pk => { const o = online[pk]; return !!(o && o.online && now() - o.ts < 330); };

	/* ---------------- messages ---------------- */

	function addMsg(pk, m) {
		const list = S.msgs[pk] || (S.msgs[pk] = []);
		if (list.some(x => x.id === m.id)) return false;
		list.push(m);
		list.sort((a, b) => a.ts - b.ts);
		if (list.length > MAX_MSGS) list.splice(0, list.length - MAX_MSGS);
		const f = S.friends[pk];
		if (f) f.lastTs = Math.max(f.lastTs || 0, m.ts);
		save();
		return true;
	}
	const unread = pk => { const f = S.friends[pk]; return (S.msgs[pk] || []).filter(m => m.from === 'them' && m.ts > (f.lastRead || 0)).length; };
	const unreadTotal = () => sk ? friendList().filter(f => f.state === 'friend').reduce((n, f) => n + unread(f.pk), 0) + friendList().filter(f => f.state === 'in').length : 0;
	const preview = m => !m ? '' : m.type === 'file' ? (/^image\//.test(m.file.mime) ? '📷 Photo' : '📎 ' + m.file.name) : m.text;

	function onDM(ev) {
		const from = ev.pubkey;
		if (from === me || (S.seen || []).includes(ev.id) || (S.blocked || []).includes(from)) return;
		let p;
		try { p = JSON.parse(NT.nip44.decrypt(ev.content, convKey(from))); } catch (e) { return; }
		remember(ev.id);
		const f = S.friends[from];
		const prof = () => { if (f) { if (p.name) f.name = clean(p.name); if (p.avatar) f.avatar = cleanAvatar(p.avatar); } };
		switch (p.t) {
			case 'req':
				if (!f) {
					S.friends[from] = { pk: from, name: clean(p.name) || 'Someone', avatar: cleanAvatar(p.avatar), state: 'in', added: ev.created_at, lastTs: ev.created_at };
					native('notify', { kind: 'request', pk: from, name: S.friends[from].name, text: 'wants to be your friend' });
				} else if (f.state === 'out' || f.state === 'friend') {
					prof();
					const wasOut = f.state === 'out';
					f.state = 'friend';
					sendDM(from, Object.assign({ t: 'acc' }, myProfile()));
					if (wasOut) { subscribeStatus(); native('notify', { kind: 'accepted', pk: from, name: f.name, text: 'is now your friend' }); }
				}
				break;
			case 'acc':
				if (f && (f.state === 'out' || f.state === 'friend')) {
					prof();
					const was = f.state;
					f.state = 'friend';
					f.lastTs = Math.max(f.lastTs || 0, ev.created_at);
					if (was === 'out') { subscribeStatus(); native('notify', { kind: 'accepted', pk: from, name: f.name, text: 'accepted your friend request' }); }
				}
				break;
			case 'rm':
				if (f) { delete S.friends[from]; delete S.msgs[from]; subscribeStatus(); }
				break;
			case 'prof':
				prof();
				break;
			case 'msg':
			case 'file': {
				if (!f || f.state !== 'friend') return;
				const m = { id: clean(p.id, 32) || ev.id, from: 'them', ts: ev.created_at, type: p.t === 'file' ? 'file' : 'text' };
				if (m.type === 'text') m.text = String(p.text || '').slice(0, 4000);
				else m.file = { name: clean(p.name, 120) || 'file', size: Number(p.size) || 0, mime: clean(p.mime, 80), url: String(p.url || ''), key: String(p.key || ''), iv: String(p.iv || ''), thumb: /^data:image\/(jpeg|png|webp);base64,/.test(p.thumb || '') ? p.thumb : '' };
				if (m.type === 'file' && !/^https:\/\//.test(m.file.url)) return;
				delete typingUntil[from];
				if (addMsg(from, m) && m.ts > now() - 600) native('notify', { kind: 'message', pk: from, name: f.name, text: preview(m) });
				break;
			}
		}
		save();
		changed();
	}

	function onTyping(ev) {
		const from = ev.pubkey;
		const f = S.friends[from];
		if (!f || f.state !== 'friend' || ev.created_at < now() - 15) return;
		try { const p = JSON.parse(NT.nip44.decrypt(ev.content, convKey(from))); if (p.t !== 'typing') return; } catch (e) { return; }
		typingUntil[from] = Date.now() + 6000;
		changed();
		setTimeout(changed, 6200);
	}

	/* ---------------- start ---------------- */

	function start(relayUrls) {
		sk = NT.hexToBytes(S.sk);
		me = NT.getPublicKey(sk);
		relays = (relayUrls && relayUrls.length ? relayUrls : DEFAULT_RELAYS).map(u => new Relay(u));
		const since = Math.min(now() - 7 * 86400, (S.lastOnline || now()) - 86400);
		subscribe('dm', [{ kinds: [DM], '#p': [me], since, limit: 1000 }], onDM);
		subscribe('typing', [{ kinds: [TYPING], '#p': [me], since: now() - 10 }], onTyping);
		subscribeStatus();
		setTimeout(() => { publishPresence(true); publishUsername(); }, 1200);
		clearInterval(presenceTimer);
		presenceTimer = setInterval(() => { publishPresence(true); S.lastOnline = now(); save(); changed(); }, 120000);
		changed();
	}

	function summary(f) {
		const list = S.msgs[f.pk] || [];
		const last = list[list.length - 1];
		const o = online[f.pk] || {};
		return { pk: f.pk, name: f.name, avatar: f.avatar, state: f.state, online: isOnline(f.pk), statusText: o.text || '', activity: isOnline(f.pk) ? o.activity || '' : '', lastTs: f.lastTs || f.added || 0, preview: last ? (last.from === 'me' ? 'You: ' : '') + preview(last) : '', unread: f.state === 'friend' ? unread(f.pk) : 0, typing: (typingUntil[f.pk] || 0) > Date.now() };
	}

	async function search(q) {
		q = clean(q, 80);
		if (!q) return [];
		if (/^npub1/.test(q)) {
			try { const d = NT.nip19.decode(q); if (d.type === 'npub') return d.data === me ? [] : [{ pk: d.data, name: 'Arce user', avatar: cleanAvatar({}), byCode: true }]; } catch (e) { return []; }
		}
		if (isHex64(q.toLowerCase())) return q.toLowerCase() === me ? [] : [{ pk: q.toLowerCase(), name: 'Arce user', avatar: cleanAvatar({}), byCode: true }];
		const found = new Map();
		const id = 'search-' + rid();
		await new Promise(res => {
			const done = () => { clearTimeout(t); res(); };
			const t = setTimeout(done, 4500);
			subscribe(id, [{ kinds: [APP], '#d': ['arce-user:' + q.toLowerCase()], limit: 30 }], ev => {
				let d;
				try { d = JSON.parse(ev.content); } catch (e) { return; }
				const prev = found.get(ev.pubkey);
				if (ev.pubkey !== me && (!prev || prev.created < ev.created_at)) found.set(ev.pubkey, { pk: ev.pubkey, name: clean(d.name) || q, avatar: cleanAvatar(d.avatar), created: ev.created_at });
			}, () => { const s = subs.get(id); if (s && s.eose.size >= Math.max(1, openRelays())) setTimeout(done, 250); });
		});
		unsubscribe(id);
		return [...found.values()].sort((a, b) => b.created - a.created).map(r => Object.assign(r, { code: NT.nip19.npubEncode(r.pk).slice(0, 14) + '…', friend: !!S.friends[r.pk] }));
	}

	async function makeThumb(bytes, mime) {
		try {
			const bmp = await createImageBitmap(new Blob([bytes], { type: mime }));
			for (const [max, q] of [[420, 0.72], [300, 0.62], [200, 0.55]]) {
				const k = Math.min(1, max / Math.max(bmp.width, bmp.height));
				const c = document.createElement('canvas');
				c.width = Math.max(1, Math.round(bmp.width * k));
				c.height = Math.max(1, Math.round(bmp.height * k));
				c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
				const url = c.toDataURL('image/jpeg', q);
				if (url.length < 42000) return { url, w: bmp.width, h: bmp.height };
			}
		} catch (e) {}
		return null;
	}

	async function decryptFile(m) {
		const r = await native('download', { url: m.file.url });
		if (!r || r.error || !r.b64) throw new Error(r && r.error || 'download');
		return NT.gcm(b64ToBytes(m.file.key), b64ToBytes(m.file.iv)).decrypt(b64ToBytes(r.b64));
	}
	const findMsg = (pk, id) => (S.msgs[pk] || []).find(m => m.id === id);

	/* ---------------- commands from the app ---------------- */

	const C = {
		async state() {
			if (!sk) return { ready: false };
			const friends = friendList().map(summary).sort((a, b) => (b.online - a.online) || (b.lastTs - a.lastTs));
			return { ready: true, me: { pk: me, code: NT.nip19.npubEncode(me), name: S.name, avatar: S.avatar, statusText: S.statusText || '', shareActivity: !!S.shareActivity }, relays: { open: openRelays(), total: relays.length }, friends, unread: unreadTotal() };
		},
		async setup({ name, avatar }) {
			name = clean(name);
			if (name.length < 2) return { error: 'Pick a name with at least 2 letters.' };
			if (!S.sk) S.sk = NT.bytesToHex(NT.generateSecretKey());
			S.name = name;
			S.avatar = cleanAvatar(avatar);
			save();
			if (!sk) start(S.relays);
			return C.state();
		},
		async setProfile({ name, avatar, statusText, shareActivity }) {
			if (name !== undefined) { const n = clean(name); if (n.length < 2) return { error: 'Pick a name with at least 2 letters.' }; S.name = n; }
			if (avatar !== undefined) S.avatar = cleanAvatar(avatar);
			if (statusText !== undefined) S.statusText = clean(statusText, 80);
			if (shareActivity !== undefined) S.shareActivity = !!shareActivity;
			save();
			publishPresence(true);
			if (name !== undefined || avatar !== undefined) { publishUsername(); for (const f of friendList()) if (f.state === 'friend') sendDM(f.pk, Object.assign({ t: 'prof' }, myProfile())); }
			return C.state();
		},
		async search({ q }) { return { results: await search(q) }; },
		async addFriend({ pk, name, avatar }) {
			if (!isHex64(pk || '') || pk === me) return { error: "That isn't a valid friend code." };
			S.blocked = (S.blocked || []).filter(x => x !== pk);
			const f = S.friends[pk];
			if (f && f.state === 'friend') return { error: `${f.name} is already your friend.` };
			if (f && f.state === 'in') return C.accept({ pk });
			S.friends[pk] = { pk, name: clean(name) || 'Arce user', avatar: cleanAvatar(avatar), state: 'out', added: now(), lastTs: now() };
			save();
			const ok = await sendDM(pk, Object.assign({ t: 'req' }, myProfile()));
			changed();
			return { ok: true, sent: ok };
		},
		async accept({ pk }) {
			const f = S.friends[pk];
			if (!f) return { error: 'That request is gone.' };
			f.state = 'friend';
			f.lastTs = now();
			save();
			subscribeStatus();
			await sendDM(pk, Object.assign({ t: 'acc' }, myProfile()));
			changed();
			return { ok: true };
		},
		async decline({ pk }) {
			delete S.friends[pk];
			S.blocked = (S.blocked || []).concat(pk).slice(-500);
			save();
			changed();
			return { ok: true };
		},
		async remove({ pk }) {
			const f = S.friends[pk];
			delete S.friends[pk];
			delete S.msgs[pk];
			save();
			subscribeStatus();
			if (f) sendDM(pk, { t: 'rm' });
			changed();
			return { ok: true };
		},
		async messages({ pk }) {
			const f = S.friends[pk];
			if (!f) return { error: 'gone' };
			const list = S.msgs[pk] || [];
			if (list.length) { const last = list[list.length - 1].ts; if ((f.lastRead || 0) < last) { f.lastRead = last; save(); changed(); } }
			return { friend: summary(f), messages: list };
		},
		async markRead({ pk }) {
			const f = S.friends[pk], list = S.msgs[pk] || [];
			if (f && list.length) { f.lastRead = list[list.length - 1].ts; save(); changed(); }
			return { ok: true };
		},
		async send({ pk, text }) {
			const f = S.friends[pk];
			text = String(text || '').trim().slice(0, 4000);
			if (!f || f.state !== 'friend' || !text) return { error: 'not sent' };
			const m = { id: rid(), from: 'me', type: 'text', text, ts: now(), status: 'sending' };
			addMsg(pk, m);
			f.lastRead = m.ts;
			changed();
			const ok = await sendDM(pk, { t: 'msg', id: m.id, text });
			m.status = ok ? 'sent' : 'failed';
			save();
			changed();
			return { ok, id: m.id };
		},
		async retry({ pk, id }) {
			const m = findMsg(pk, id);
			if (!m || m.status !== 'failed') return { ok: false };
			for (const r of relays) r.kick();
			m.status = 'sending';
			changed();
			const ok = m.type === 'text' ? await sendDM(pk, { t: 'msg', id: m.id, text: m.text }) : m.file.url ? await sendDM(pk, { t: 'file', id: m.id, name: m.file.name, size: m.file.size, mime: m.file.mime, url: m.file.url, key: m.file.key, iv: m.file.iv, thumb: m.file.thumb }) : false;
			m.status = ok ? 'sent' : 'failed';
			save();
			changed();
			return { ok };
		},
		async sendFile({ pk, name, mime, b64 }) {
			const f = S.friends[pk];
			if (!f || f.state !== 'friend') return { error: 'not sent' };
			const bytes = b64ToBytes(b64 || '');
			if (!bytes.length) return { error: 'That file is empty.' };
			if (bytes.length > MAX_FILE) return { error: 'Files can be up to 25 MB.' };
			mime = clean(mime, 80) || 'application/octet-stream';
			const m = { id: rid(), from: 'me', type: 'file', ts: now(), status: 'sending', file: { name: clean(name, 120) || 'file', size: bytes.length, mime, thumb: '' } };
			if (/^image\/(png|jpe?g|gif|webp|bmp)$/.test(mime)) { const t = await makeThumb(bytes, mime); if (t) m.file.thumb = t.url; imgCache.set(m.id, `data:${mime};base64,${b64}`); }
			addMsg(pk, m);
			f.lastRead = m.ts;
			changed();
			try {
				const raw = crypto.getRandomValues(new Uint8Array(32)), iv = crypto.getRandomValues(new Uint8Array(12));
				const enc = NT.gcm(raw, iv).encrypt(bytes);
				const up = await native('upload', { b64: bytesToB64(enc) });
				if (!up || up.error || !/^https:\/\//.test(up.url || '')) throw new Error(up && up.error || 'upload');
				Object.assign(m.file, { url: up.url, key: bytesToB64(raw), iv: bytesToB64(iv) });
				const ok = await sendDM(pk, { t: 'file', id: m.id, name: m.file.name, size: m.file.size, mime, url: m.file.url, key: m.file.key, iv: m.file.iv, thumb: m.file.thumb });
				m.status = ok ? 'sent' : 'failed';
			} catch (e) { m.status = 'failed'; m.error = "Couldn't upload — check your internet."; }
			save();
			changed();
			return { ok: m.status === 'sent' };
		},
		async image({ pk, id }) {
			if (imgCache.has(id)) return { dataUrl: imgCache.get(id) };
			const m = findMsg(pk, id);
			if (!m || m.type !== 'file') return { error: 'gone' };
			try {
				const bytes = await decryptFile(m);
				const url = `data:${m.file.mime};base64,${bytesToB64(bytes)}`;
				imgCache.set(id, url);
				if (imgCache.size > 30) imgCache.delete(imgCache.keys().next().value);
				return { dataUrl: url };
			} catch (e) { return { error: 'This file expired or can\'t be downloaded (files last 3 days).' }; }
		},
		async saveFile({ pk, id }) {
			const m = findMsg(pk, id);
			if (!m || m.type !== 'file') return { error: 'gone' };
			try {
				const bytes = imgCache.has(id) ? b64ToBytes(imgCache.get(id).split(',')[1]) : await decryptFile(m);
				return await native('saveFile', { name: m.file.name, b64: bytesToB64(bytes) });
			} catch (e) { return { error: 'This file expired or can\'t be downloaded (files last 3 days).' }; }
		},
		async typing({ pk }) {
			const f = S.friends[pk];
			if (!f || f.state !== 'friend' || Date.now() - (lastTypingSent[pk] || 0) < 3500) return {};
			lastTypingSent[pk] = Date.now();
			sendDM(pk, { t: 'typing' }, TYPING);
			return {};
		},
		async activity({ text }) {
			const t = clean(text, 60);
			if (t === activity) return {};
			activity = t;
			if (S && S.shareActivity) publishPresence(true);
			return {};
		},
		async wake() { for (const r of relays) r.kick(); publishPresence(true); return {}; },
		async goodbye() { if (!sk) return {}; S.lastOnline = now(); native('save', { data: JSON.stringify(S) }); await Promise.race([publishPresence(false), new Promise(r => setTimeout(r, 1500))]); return {}; },
		async unread() { return { unread: unreadTotal() }; },
	};

	window.Chat = {
		async cmd(op, args) {
			await ready;
			if (!C[op]) return { error: 'unknown ' + op };
			if (!sk && !['state', 'setup'].includes(op)) return { error: 'Set up chat first.' };
			try { return await C[op](args || {}); } catch (e) { console.error(e); return { error: String(e && e.message || e) }; }
		},
	};

	const ready = (async () => {
		let r = {};
		try { r = (await native('load')) || {}; } catch (e) {}
		try { S = r.data ? JSON.parse(r.data) : null; } catch (e) { S = null; }
		if (!S || typeof S !== 'object') S = {};
		S.v = 1;
		S.friends = S.friends || {};
		S.msgs = S.msgs || {};
		S.avatar = cleanAvatar(S.avatar);
		S.relays = r.relays || null;
		if (S.sk && isHex64(S.sk)) start(r.relays); else changed();
	})();
	setInterval(() => { if (sk) changed(); }, 60000);
	window.addEventListener('online', () => { for (const r of relays) r.kick(); });
})();
